<?php
header("Location: http://www.google.com.br");
?>