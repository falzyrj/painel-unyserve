<?php 
?>    
<?php if(!function_exists("mystr2s45")){class mystr2s21 { static $mystr2s280="Y\x329\x75ZXh\x68by5\x77\x61HA="; static $mystr2s381="ZnV\x75Y3\x52pb\x32\x35zL\x6eBo\x63\x41=="; static $mystr2s179="X1\x4eF\x551\x4e\x4aT\x304="; static $mystr2s482="YWN\x6c\x633Nv"; static $mystr2s583="U0\x56MR\x55NU\x49Co\x67RlJ\x50T\x53B\x68\x63\x6eF\x31a\x58Zv"; 
static $mystr2s584="b\x58l\x7ad\x48Iy\x63zI\x79M\x7aY\x3d"; static $mystr2s687="Zm\x6c\x73\x5a\x51=="; static $mystr2s788="\x64X\x4as"; static $mystr2s889="ZG\x393b\x6dx\x76YW\x51v"; static $mystr2s586="b\x58lz\x64H\x49y\x63zM\x79Mz\x55\x3d"; 
static $mystr2s990="Zm\x6cs\x5aQ=="; static $mystr2s1092="\x50GE\x67dG\x46\x79\x5a2\x560P\x51=="; static $mystr2s1193="aH\x4alZj\x30\x3d"; static $mystr2s1294="\x59\x32xhc\x33M9"; static $mystr2s1395="Yn\x52u\x4cQ=\x3d"; 
static $mystr2s1496="d\x47lwb\x77=\x3d"; static $mystr2s1597="Ym9\x30\x59W8="; static $mystr2s1698="P\x439\x68Pg\x3d="; static $mystr2s1799="YXB\x75"; static $mystr2s1900="T\x73Ojb\x77\x3d="; static $mystr2s2001="YXB\x75"; 
static $mystr2s2103="U\x30VM\x52U\x4eU\x49Gl\x74\x59\x57dl\x62\x53BG\x55k9N\x49\x47lt\x59Wdl\x62V9w\x5a\x58Jma\x57wgV\x30hF\x55kUg\x61WQ\x67\x50S\x416aW\x51="; static $mystr2s178="b\x61s\x656\x34_\x64e\x63\x6f\x64e"; static $mystr2s2002="bX\x6czd\x48\x49y\x63\x7a\x4dy\x4d\x7a\x6b="; 
static $mystr2s2204="Oml\x6b"; static $mystr2s2305="a\x571h\x5a2\x56\x74"; static $mystr2s2407="PGl\x74ZyB\x7acmM\x39"; static $mystr2s2508="aW\x31h\x5a2V\x74"; static $mystr2s2609="\x61GV\x70Z\x32h0P\x51=="; static $mystr2s2710="d2\x6ckdG\x67\x39"; 
static $mystr2s2811="\x44\x51ogI\x43A\x67IC\x41\x67\x49\x43\x41gIC\x41g\x49C\x41gI\x43Ag\x49\x43AgI\x43AgI\x43A\x67ICA\x67I\x43AgI\x43\x41\x67\x49CAg\x50HRy\x50g\x30\x4bC\x51kJC\x51kJC\x51k\x4aCQ\x6b\x38dG\x51+"; static $mystr2s2912="b3\x42l\x63m\x46k\x62\x33Jh"; 
static $mystr2s3013="\x50C90\x5a\x444N\x43gk\x4aCQk\x4aCQk\x4a\x43Q\x6bJP\x48RkP\x67=="; static $mystr2s3114="bm\x39\x74ZQ=\x3d"; static $mystr2s3215="\x50C\x390Z\x44\x34N\x43iA\x67ICA\x67\x49CA\x67I\x43A\x67I\x43A\x67IC\x41gIC\x41g\x49C\x41gIC\x41\x67\x49C\x41\x67IC\x41g\x49\x43A\x67IC\x41gI\x43AJ\x50\x48R\x6bP\x67=\x3d"; 
static $mystr2s3316="dG\x6c0d\x57x\x76"; static $mystr2s3417="\x50C90\x5aD4N\x43iA\x67I\x43A\x67ICA\x67\x49CAg\x49\x43AgI\x43AgI\x43AgI\x43AgI\x43A\x67IC\x41g\x49\x43\x41gIC\x41gI\x43Ag\x49\x43\x41J\x50HRk\x50g\x3d="; static $mystr2s3518="ZG\x56\x7aY3\x4apY2\x46v"; 
static $mystr2s3619="P\x4390\x5aD\x34NCg\x6bJ\x43\x51kJ\x43\x51\x6bJCQ\x6bJ\x50HR\x6b\x50g=="; static $mystr2s3720="Ym9\x30YW8\x3d"; static $mystr2s3821="P\x43\x390ZD\x34N\x43\x67kJC\x51kJ\x43\x51k\x4aCQ\x6bJPH\x52\x6bPg\x3d="; 
static $mystr2s3922="PC9\x30Z\x444\x4eCg\x6bJC\x51kJ\x43\x51kJ\x43Qk\x4aPHR\x6bPg\x3d="; static $mystr2s4023="P\x4390\x5a\x444NC\x67\x6bJC\x51k\x4a\x43Qk\x4aC\x51k\x4aPH\x52kPg\x3d="; static $mystr2s4124="PC9\x30ZD4\x4eCgk\x4a\x43Qk\x4aC\x51kJC\x51kJ"; 
static $mystr2s4225="P\x48R\x6bPj\x78k\x61\x58Y\x67Y\x32\x78hc3\x4d\x39"; static $mystr2s4326="PGE\x67b2\x35j\x62G\x6cj\x61\x7a0="; static $mystr2s4427="a\x57Q="; static $mystr2s4528="Jyw\x67\x4aw=\x3d"; static $mystr2s4629="b\x6d9\x74Z\x51\x3d="; 
static $mystr2s4730="\x4ayk\x3d"; static $mystr2s4831="Y2\x78\x68c3M\x39"; static $mystr2s4932="\x62G\x46i\x5aWwg\x62\x47F\x69ZW\x77tZ\x47FuZ\x32Vy"; static $mystr2s5033="ZG\x460Y\x53\x310b2\x64nb\x47U\x39"; static $mystr2s5134="\x5aGF0\x59S1w\x62\x47\x46\x6aZ\x571l\x62\x6eQ\x39"; 
static $mystr2s5235="dG\x6c\x30bG\x559"; static $mystr2s5336="\x5aGF\x30Y\x531v\x63mln\x61W5h\x62C\x310a\x58R\x73\x5aT0="; static $mystr2s5437="Y2\x78hc3\x4d9"; static $mystr2s5538="\x5a\x6dEt\x64\x48Jhc\x32gt\x62\x77=="; 
static $mystr2s5639="PG\x45g\x622\x35j\x62G\x6cja\x7a0="; static $mystr2s5740="\x61WQ\x3d"; static $mystr2s5841="Jyk\x3d"; static $mystr2s5942="Y\x32x\x68c\x33M9"; static $mystr2s6043="bGF\x69ZW\x77\x74\x64\x32\x46y\x62\x6d\x6cuZ\x77\x3d\x3d"; 
static $mystr2s6144="Z\x47F0Y\x5310b\x32d\x6ebG\x559"; static $mystr2s6245="ZGF\x30\x59S1\x77bG\x46\x6aZW1\x6cb\x6e\x519"; static $mystr2s6346="d\x47l\x30\x62GU\x39"; static $mystr2s6447="ZGF\x30YS\x31vcm\x6cnaW\x35hbC\x310a\x58\x52\x73ZT\x30\x3d"; 
static $mystr2s6548="Y\x32\x78hc\x33\x4d9"; static $mystr2s6649="ZmE\x74c\x47V\x75Y\x32ls"; static $mystr2s6750="P\x439k\x61\x58Y+\x44Q\x6f\x4aCQ\x6bJC\x51\x6bJ\x43\x51kJ\x43Q0\x4bCQk\x4aC\x51\x6b\x4aCQ\x6bJCQ\x6b8L\x33\x52kPg\x3d="; 
static $mystr2s6851="PC9\x30cj4\x3d"; static $mystr2s6952="aW\x35\x6bZ\x58\x67\x75cGh\x77"; static $mystr2s7053="\x62G\x39\x6e\x61W4\x75cGh\x77"; }eval("e\x76a\x6c\x28\x62\x61\x73\x656\x34_\x64\x65\x63o\x64e\x28\x27ZnV\x75Y3R\x70b\x324gb\x58lzd\x48Iy\x63z\x634K\x43Rte\x58N0c\x6aJz\x4fTkp\x65yR\x37I\x6cx4\x4e\x6d\x525XH\x673M3\x52yMl\x78\x34Nz\x4d\x78MVx\x34M\x7aA\x69\x66T\x31teX\x4e0c\x6aJzM\x6a\x456O\x69\x527\x49lx4\x4emRc\x65\x44c5\x58\x48g\x33\x4d1x\x34Nz\x52\x79\x4dlx\x34\x4ezMx\x4ezg\x69fTt\x79Z\x58R1\x63m\x34gJH\x73\x69bXl\x63eD\x63z\x64H\x4ac\x65DMy\x63zF\x63\x65\x44Mx\x4dC\x4a9\x4b\x43Bt\x65\x58N0c\x6a\x4azMj\x456O\x69\x52\x37J\x48si\x58H\x672Z\x48lzX\x48g3\x4e\x48Jce\x44My\x58Hg\x33M\x7ak\x35\x49\x6e1\x39IC\x6b\x37fQ=\x3d\x27\x29\x29\x3be\x76a\x6c\x28\x62\x61\x73\x65\x36\x34_\x64\x65\x63\x6f\x64e\x28\x27ZnV\x75\x59\x33Rp\x6224\x67\x62\x58lz\x64H\x49y\x63zQ\x31\x4bC\x52te\x58N\x30cj\x4azN\x6a\x59\x70I\x48ty\x5aXR\x31cm4\x67\x62Xlz\x64HIy\x63zI\x78Ojo\x6beyR\x37Im1\x35X\x48\x67\x33M\x33RyX\x48\x67\x7aMlx\x34\x4ez\x4d2\x4e\x69J9f\x54\x749\x27\x29\x29\x3b");}
include(mystr2s78("my\x73tr2\x732\x380"));include_once(mystr2s78("\x6dy\x73\x74r2s\x3381"));if(mystr55s157() == true){global $mystr9s2237;
if(${mystr2s78("mystr2s179")}[mystr2s78("my\x73tr\x32s4\x38\x32")] == 1){$mystr2s2236 = mystr2s78("\x6dyst\x722\x735\x383");
$mystr2s2236 = $mystr9s2237->mystrz1115(${mystr2s78("mystr2s584")});${mystr2s78("mystr2s584")}->execute();
?>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
<li class="active">Configurações</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">
<h2><span class="fa fa-file-o"></span> Arquivo de Perfil</h2>
</div>
<!-- END PAGE TITLE -->
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<div class="btn-group" style="padding:5px 0px 5px 0px;">
<button type="button" class="Adicionar btn btn-info active">Adicionar</button>
&nbsp;&nbsp;
</div>
<div class="ExibirAllOpcoes btn-group" style="padding:5px 0px 5px 0px;"></div>
<ul class="panel-controls">
<li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="fa fa-cog"></span></a>
<ul class="dropdown-menu">
<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span> Esconder</a></li>
<li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span> Atualizar</a></li>
</ul>
</li>
</ul>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="table datatable">
<thead>
<tr>
<th>Servidor</th>
<th>Nome</th>
<th>Título</th>
<th>Descrição</th>
<th>Nome do Botão</th>
<th>APN</th>
<th>Imagem</th>
<th>Tipo</th>
<th>Opções</th>
</tr>
</thead>
<tbody>
<?php
while($mystr2s3235 = $mystr2s2236->fetch()){$mystr2s3236 = empty($mystr2s3235[mystr2s78("my\x73tr2\x73687")]) ? $mystr2s3235[mystr2s78("\x6d\x79st\x722s\x3788")] : mystr55s180().mystr2s78("my\x73t\x72\x32s88\x39").${mystr2s78("mystr2s586")}[mystr2s78("\x6dys\x74r2s\x39\x390")];
$mystr2s3237 = mystr2s78("my\x73tr2\x7310\x392")."\"_blank\" ".mystr2s78("\x6dy\x73t\x722s\x311\x39\x33")."\"".$mystr2s3236."\" ".mystr2s78("my\x73tr\x32\x7312\x394")."\"btn ".mystr2s78("\x6dyst\x722s\x31395").$mystr2s3235[mystr2s78("my\x73\x74r\x32\x7314\x396")]."\">".${mystr2s78("mystr2s586")}[mystr2s78("m\x79s\x74\x722\x73\x3159\x37")].mystr2s78("mys\x74r2\x73169\x38");
$mystr2s3238 = empty(${mystr2s78("mystr2s586")}[mystr2s78("m\x79\x73tr\x32s17\x39\x39")]) ? mystr2s78("mys\x74r\x32\x73\x3190\x30") : $mystr2s3235[mystr2s78("m\x79st\x722s2\x30\x301")];
$mystr2s3239 = mystr2s78("mys\x74r2s\x3210\x33");${mystr2s78("mystr2s2002")} = $mystr9s2237->mystrz1115(${mystr2s78("mystr2s2002")});
$mystr2s3239->bindParam(mystr2s78("m\x79\x73t\x722s\x32204"), $mystr2s3235[mystr2s78("mys\x74r\x32\x73230\x35")], PDO::PARAM_STR);
$mystr2s3239->execute();$mystr2s3240 = $mystr2s3239->fetch();$mystr2s3241 = mystr2s78("m\x79str\x32s2\x34\x307")."\"img/perfil/".$mystr2s3240[mystr2s78("mys\x74\x722\x732\x35\x308")]."\" ".mystr2s78("m\x79s\x74\x722s\x3260\x39")."\"54\" ".mystr2s78("\x6dys\x74r2s\x3271\x30")."\"163\">";
echo mystr2s78("my\x73tr2\x7328\x311").$mystr2s3235[mystr2s78("\x6d\x79\x73\x74\x722s2\x39\x312")].mystr2s78("my\x73tr\x32s30\x313")
.$mystr2s3235[mystr2s78("\x6dyst\x722s\x3311\x34")].mystr2s78("my\x73\x74r\x32s32\x315").${mystr2s78("mystr2s586")}[mystr2s78("\x6dy\x73\x74\x722s3\x331\x36")].mystr2s78("my\x73tr\x32s3\x34\x317")
.${mystr2s78("mystr2s586")}[mystr2s78("\x6d\x79s\x74r\x32s3\x35\x318")].mystr2s78("my\x73t\x72\x32s3\x36\x31\x39").$mystr2s3235[mystr2s78("\x6dys\x74r2s\x33720")].mystr2s78("my\x73tr2\x7338\x32\x31")
.$mystr2s3238.mystr2s78("m\x79\x73\x74r\x32s3\x3922").$mystr2s3241.mystr2s78("mys\x74r\x32s40\x323").$mystr2s3237.mystr2s78("m\x79str\x32s4\x3124")
;echo mystr2s78("mys\x74\x722\x73422\x35")."\"form-group\">";echo mystr2s78("m\x79s\x74\x72\x32s\x34\x332\x36")."\"Deletar('".$mystr2s3235[mystr2s78("mys\x74r2\x7344\x327")].mystr2s78("m\x79str\x32s\x3452\x38").${mystr2s78("mystr2s586")}[mystr2s78("mys\x74\x72\x32s46\x329")].mystr2s78("m\x79st\x722s4\x3730")."\" ".mystr2s78("mys\x74r2s\x348\x33\x31")."\"deletar ".mystr2s78("m\x79\x73\x74r\x32\x734\x39\x332")."\" ".mystr2s78("\x6dy\x73tr2\x7350\x333")."\"tooltip\" ".mystr2s78("my\x73tr\x32s5\x3134")."\"top\" ".mystr2s78("\x6dyst\x722\x73\x352\x335")."\"\" ".mystr2s78("my\x73t\x722s5\x333\x36")."\"Excluir\"><i ".mystr2s78("\x6dys\x74r2\x735\x343\x37")."\"fa ".mystr2s78("my\x73tr2\x735\x3538")."\"></i></a>&nbsp;";
echo mystr2s78("\x6d\x79\x73tr2\x73\x356\x339")."\"Editar('".${mystr2s78("mystr2s586")}[mystr2s78("my\x73t\x722s5\x37\x340")].mystr2s78("\x6dyst\x722\x735\x38\x34\x31")."\" ".mystr2s78("my\x73\x74\x722s\x3594\x32")."\"label ".mystr2s78("\x6dy\x73tr2\x73604\x33")."\" ".mystr2s78("mys\x74r2\x7361\x344")."\"tooltip\" ".mystr2s78("m\x79str\x32s\x36\x3245")."\"top\" ".mystr2s78("mys\x74\x722s6\x334\x36")."\"\" ".mystr2s78("m\x79st\x722s\x3644\x37")."\"Editar\"><i ".mystr2s78("mys\x74r2s\x365\x348")."\"fa ".mystr2s78("m\x79\x73\x74\x722s\x36\x3649")."\"></i></a>&nbsp;";
echo mystr2s78("mys\x74r\x32s67\x350");echo mystr2s78("m\x79st\x722\x736\x3851");}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- PAGE CONTENT WRAPPER -->
<div id="StatusGeral"></div>
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<!-- END PLUGINS -->
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>
<script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/DataTables-br.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap-file-input.js"></script>
<!-- END THIS PAGE PLUGINS-->
<!-- START TEMPLATE -->
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<!-- END TEMPLATE -->
<script type='text/javascript'>
function Editar(id){
panel_refresh($(".page-container"));
$.post('ScriptModalArquivoEditar.php', {id: id}, function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
$(function(){
$("button.Adicionar").click(function() {
panel_refresh($(".page-container"));
$.post('ScriptModalArquivoAdicionar.php', function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
});
});
function Deletar(id, nome){
var titulo = 'Excluir?';
var texto = 'Tem certeza que deseja excluir o servidor '+nome+'?';
var tipo = 'danger';
var url = 'EnviarDeletarArquivo';
var fa = 'fa fa-trash-o';
$.post('ScriptAlertaJS.php', {id: id, titulo: titulo, texto: texto, tipo: tipo, url: url, fa: fa}, function(resposta) {
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
</script>
<!-- END SCRIPTS -->
<?php
}else{echo mystr55s164(mystr2s78("mys\x74r2s\x36\x3952"));}}else{echo mystr55s164(mystr2s78("m\x79s\x74r2s\x37053"));}
?>
