<?php 

?>
<?php if(!function_exists("mystr57s100")){class mystr57s21 { static $mystr57s280="Y29\x75\x5aXh\x68by5\x77\x61H\x41="; static $mystr57s178="ba\x73\x6564\x5fde\x63\x6f\x64e"; static $mystr57s381="ZnV\x75Y3R\x70\x62\x325zL\x6e\x42ocA\x3d="; static $mystr57s179="X1\x4eFU\x31\x4e\x4aT0\x34\x3d"; 
static $mystr57s482="\x59W\x4el\x633N\x76"; static $mystr57s583="U0\x56MR\x55\x4eUIC\x6fg\x52lJ\x50\x54\x53Bpb\x57Fn\x5aW1\x66\x63\x47\x56yZ\x6d\x6cs"; static $mystr57s686="\x50Glt\x5ayBz\x63\x6dM9"; static $mystr57s788="aW\x31\x68Z2\x56t"; 
static $mystr57s889="\x61GV\x70Z\x32h\x30PQ\x3d="; static $mystr57s990="d2\x6ckdG\x679"; static $mystr57s1091="\x49\x438+"; static $mystr57s1192="DQ\x6fg\x49C\x41\x67\x49CAg\x49CAg\x49\x43Ag\x49CAg\x49\x43AgI\x43A\x67\x49CAg\x49CAg\x49\x43AgI\x43\x41gIC\x41g\x49C\x41\x67PH\x52\x79\x50g0\x4bI\x43Ag\x49CA\x67I\x43AgI\x43A\x67IC\x41gIC\x41gIC\x41gI\x43\x41g\x49\x43A\x67I\x43AgI\x43\x41g\x49CAg\x49\x43\x41\x67IAk\x38dG\x51+"; 
static $mystr57s585="b\x58l\x7ad\x48\x49\x31N3\x4dzM\x6a\x4d2"; static $mystr57s1293="PC\x39\x30ZD4\x4eCg\x6bJCQ\x6bJC\x51kJC\x51\x6bJ"; static $mystr57s1394="\x50H\x52k\x50jxk\x61X\x59gY\x32x\x68c3\x4d9"; static $mystr57s1495="PGE\x67b2\x35\x6abGl\x6aaz0\x3d"; 
static $mystr57s1596="a\x57Q="; static $mystr57s1697="Jyk\x3d"; static $mystr57s1798="Y\x32x\x68c\x33M9"; static $mystr57s1899="bGF\x69ZWw\x74ZGF\x75Z2V\x79"; static $mystr57s2000="Z\x47\x460Y\x53\x31\x30b2d\x6ebGU\x39"; 
static $mystr57s2101="ZGF\x30Y\x531\x77b\x47Fj\x5aW1\x6cb\x6e\x519"; static $mystr57s2202="d\x47l0\x62\x47U\x39"; static $mystr57s2303="ZGF\x30YS1\x76cml\x6eaW\x35h\x62C\x310\x61\x58\x52s\x5aT0="; static $mystr57s2404="Y\x32\x78h\x633M9"; 
static $mystr57s2505="ZmE\x74dH\x4a\x68\x632\x67\x74\x62\x77=\x3d"; static $mystr57s2606="PC\x39kaX\x59+DQ\x6fJ\x43QkJ\x43\x51kJ\x43Qk\x4aC\x510\x4b\x43Qk\x4aCQ\x6bJCQ\x6bJ\x43\x51k\x38\x4c3R\x6bPg=\x3d"; static $mystr57s2707="\x50\x4390\x63j4\x3d"; 
static $mystr57s2808="an\x4dv\x5a\x47Vt\x6219\x6cZGl\x30X3\x42lc\x6dZp\x62\x435w\x61\x48A="; static $mystr57s2909="\x61W5\x6bZXg\x75cGh\x77"; static $mystr57s3010="bG\x39naW\x34uc\x47\x68w"; }eval("\x65v\x61\x6c\x28b\x61s\x65\x36\x34\x5f\x64\x65c\x6f\x64e\x28\x27Z\x6eVu\x59\x33Rp\x6224g\x62Xlz\x64HI1\x4e\x33Mx\x4fDgo\x4aG\x315\x633\x52yNT\x64zM\x6aA5K\x58s\x6beyJ\x74eV\x784Nz\x4e\x30X\x48g\x33MjU\x33XH\x673Mz\x49yXH\x67z\x4d\x43J9\x50W\x315c\x33RyN\x54d\x7a\x4d\x6aE\x36\x4fiR\x37\x49\x6d15X\x48g3\x4d3\x52yNV\x784M\x7adce\x44czX\x48gz\x4dTd\x63eDM\x34In\x307cm\x56\x30dX\x4auIC\x527\x49\x6c\x784Nm\x52\x35c\x31x4N\x7aRyX\x48gz\x4eTd\x7aM\x6c\x784M\x7aJ\x63e\x44M\x77I\x6e0o\x49G1\x35c\x33RyN\x54\x64\x7aMjE\x36\x4fiR7\x4aHsi\x62V\x784Nz\x6czX\x48g3\x4eFx4\x4ezJ\x63e\x44M1N\x31\x78\x34Nz\x4dyMF\x784Mz\x6bifX\x30gKT\x749\x27\x29\x29\x3b\x65v\x61\x6c\x28b\x61\x73e\x364\x5f\x64e\x63\x6fd\x65\x28\x27Z\x6eVuY\x33Rpb\x324g\x62Xl\x7ad\x48I1\x4e\x33\x4dx\x4d\x44A\x6f\x4aG15\x633\x52y\x4e\x54d\x7aMTI\x78K\x53B7\x63m\x56\x30d\x58\x4au\x49\x4715c\x33R\x79NTd\x7aMjE\x36Oi\x527J\x48s\x69XH\x672\x5aHl\x7aXHg\x33N\x46x\x34\x4ezI1\x4e\x31x4N\x7aMxM\x6c\x78\x34MzE\x69fX0\x37f\x51=\x3d\x27\x29\x29\x3b");}
include(mystr57s188("\x6dyst\x72\x357s\x328\x30"));include_once(mystr57s188("my\x73\x74r57\x73381"));if(mystr55s157() == true){
global $mystr9s2237;if(${mystr57s188("mystr57s179")}[mystr57s188("\x6dy\x73tr\x357s4\x38\x32")] == 1){$mystr57s2235 = mystr57s188("my\x73tr\x357\x73\x3583");
$mystr57s2235 = $mystr9s2237->mystrz1115($mystr57s2235);$mystr57s2235->execute();
?>
<link rel="stylesheet" type="text/css" href="css/cropper/cropper.min.css"/>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
<li class="active">Configurações</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">
<h2><span class="fa fa-picture-o"></span> Imagem de Perfil</h2>
</div>
<!-- END PAGE TITLE -->
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<div class="btn-group" style="padding:5px 0px 5px 0px;">
<button type="button" class="Adicionar btn btn-info active" data-toggle="modal" data-target="#modal_change_photo">Adicionar</button>
&nbsp;&nbsp;
</div>
<div class="ExibirAllOpcoes btn-group" style="padding:5px 0px 5px 0px;"></div>
<ul class="panel-controls">
<li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="fa fa-cog"></span></a>
<ul class="dropdown-menu">
<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span> Esconder</a></li>
<li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span> Atualizar</a></li>
</ul>
</li>
</ul>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="table datatable">
<thead>
<tr>
<th>Imagem</th>
<th>Opções</th>
</tr>
</thead>
<tbody>
<?php
while($mystr57s3235 = $mystr57s2235->fetch()){$mystr57s3236 = mystr57s188("\x6dy\x73t\x725\x37\x736\x386")."\"img/perfil/".$mystr57s3235[mystr57s188("my\x73tr\x35\x37s7\x388")]."\" ".mystr57s188("\x6dyst\x7257\x73889")."\"107\" ".mystr57s188("my\x73\x74r\x35\x37s\x39\x39\x30")."\"326\" ".mystr57s188("\x6dy\x73\x74\x7257s\x31091");
echo mystr57s188("my\x73tr\x357s1\x319\x32").${mystr57s188("mystr57s585")}.mystr57s188("\x6d\x79st\x7257\x73129\x33");echo mystr57s188("mys\x74r\x35\x37s13\x39\x34")."\"form-group\">";
echo mystr57s188("m\x79st\x7257s\x31\x3495")."\"Deletar('".$mystr57s3235[mystr57s188("mys\x74r57\x7315\x396")].mystr57s188("m\x79\x73t\x7257\x7316\x39\x37")."\" ".mystr57s188("mys\x74r5\x37\x7317\x39\x38")."\"label ".mystr57s188("m\x79str\x357s\x31899")."\" ".mystr57s188("mys\x74\x725\x37\x73200\x30")."\"tooltip\" ".mystr57s188("m\x79s\x74\x725\x37s\x3210\x31")."\"top\" ".mystr57s188("mys\x74r5\x37s22\x302")."\"\" ".mystr57s188("m\x79str\x357s\x32303")."\"Excluir\"><i ".mystr57s188("mys\x74r\x35\x37\x7324\x304")."\"fa ".mystr57s188("my\x73tr\x357s2\x35\x30\x35")."\"></i></a>&nbsp;";
echo mystr57s188("\x6dyst\x7257\x732\x3606");echo mystr57s188("my\x73\x74r\x357s\x32\x3707");}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- PAGE CONTENT WRAPPER -->
<div class="modal animated fadeIn" id="modal_change_photo" tabindex="-1" role="dialog" aria-labelledby="smallModalHead" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Fechar</span></button>
<h4 class="modal-title" id="smallModalHead">Adicionar Imagem de Perfil</h4>
</div>
<form id="cp_crop" method="post" action="javascript:MDouglasMS();">
<div class="modal-body">
<div class="text-center" id="cp_target">Formatos permitidos: jpg, png e gif.</div>
<input type="hidden" name="cp_img_path" id="cp_img_path"/>
<input type="hidden" name="ic_x" id="ic_x"/>
<input type="hidden" name="ic_y" id="ic_y"/>
<input type="hidden" name="ic_w" id="ic_w"/>
<input type="hidden" name="ic_h" id="ic_h"/>
</div>
</form>
<form id="cp_upload" method="post" enctype="multipart/form-data" action="upload_perfil.php">
<div class="modal-body form-horizontal form-group-separated">
<div class="form-group">
<label class="col-md-4 control-label">Nova Imagem</label>
<div class="col-md-4">
<input type="file" class="fileinput btn-info" name="file" id="cp_photo" data-filename-placement="inside" title="Selecionar Imagem"/>
</div>
</div>
</div>
</form>
<div class="modal-footer">
<button type="button" class="btn btn-success disabled" id="cp_accept">Aceitar</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
</div>
</div>
</div>
</div>
<div id="StatusGeral"></div>
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-migrate.min.js"></script>
<!-- END PLUGINS -->
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap-file-input.js"></script>
<script type="text/javascript" src="js/plugins/form/jquery.form.js"></script>
<script type="text/javascript" src="js/plugins/cropper/cropper.min.js"></script>
<script type='text/javascript' src='js/plugins/validationengine/languages/jquery.validationEngine-br.js'></script>
<script type='text/javascript' src='js/plugins/validationengine/jquery.validationEngine.js'></script>
<script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>
<script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/DataTables-br.js"></script>
<!-- END THIS PAGE PLUGINS-->
<!-- START TEMPLATE -->
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<?php include_once(mystr57s188("\x6dy\x73\x74r57\x7328\x308")); ?>
<!-- END TEMPLATE -->
<script type='text/javascript'>
function Deletar(id){
var titulo = 'Excluir?';
var texto = 'Tem certeza que deseja excluir esta imagem?';
var tipo = 'danger';
var url = 'EnviarDeletarImagemPerfil';
var fa = 'fa fa-trash-o';
$.post('ScriptAlertaJS.php', {id: id, titulo: titulo, texto: texto, tipo: tipo, url: url, fa: fa}, function(resposta) {
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
</script>
<!-- END SCRIPTS -->
<?php
}else{echo mystr55s164(mystr57s188("my\x73tr\x357s\x32\x39\x309"));}}else{echo mystr55s164(mystr57s188("\x6d\x79s\x74r\x357\x733\x30\x310"));
}
?>
