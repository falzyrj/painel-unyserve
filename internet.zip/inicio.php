<?php
include("conexao.php");
include("conexao2.php");
include('funcoes.php');
include_once("functions.php");
@$iduser = @$_SESSION['id'];
if(ProtegePag() == true){
global $banco;
?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
                <!-- END BREADCRUMB -->  
                <ul class="breadcrumb">
                    <li class="active"></span>&#160;Olá&#160;<strong><?php echo $_SESSION['nome']?></strong>&#160;Bem-vindo(a) Ao Painel de Controle</li>
                </ul>
                <!-- PAGE TITLE -->
          <div class="page-title">  
            <?php
function getAccounts(){
    global $banco;
    $CadUser = $_SESSION['id'];
    $acesso = 3;
    $SQLUser = "SELECT * FROM login WHERE id_cad = :id_cad AND acesso = :acesso";
    $SQLUser = $banco->prepare($SQLUser);
    $SQLUser->bindParam(':id_cad', $CadUser, PDO::PARAM_INT);
    $SQLUser->bindParam(':acesso', $acesso, PDO::PARAM_INT);
    $SQLUser->execute();
    $totalUsers = 0;
    while($LnUser = $SQLUser->fetch()){
        $totalUsers = $totalUsers + 1;
    }
    return $totalUsers;
}

	function getOns(){
        
    }
$result = "";
//Seleciona os servidores
$SQLServer = "SELECT * FROM servidor";
$SQLServer = $banco->prepare($SQLServer);
$SQLServer->execute();

$ArrayServer = array();
while($LnServer = $SQLServer->fetch()){
    if(!in_array($LnServer['server'], $ArrayServer)) {
    $ArrayServer[] = $LnServer['server'];
        $connection = ssh2_connect($LnServer['server'], $LnServer['porta']);
        ssh2_auth_password($connection, $LnServer['user'], $LnServer['senha']);
        $stream = ssh2_exec($connection, 'ps aux | grep priv | grep Ss');
        stream_set_blocking($stream, true);
        $stream_out = ssh2_fetch_stream($stream, SSH2_STREAM_STDIO);
        $result .= stream_get_contents($stream_out);
    }
}
//Usuário
$CadUser = $_SESSION['id'];
$acesso = 3;
$acessoT = 4;

$SQLUser = "SELECT * FROM login WHERE id_cad = :id_cad AND acesso = :acesso OR id_cad = :id_cad AND acesso = :acessoT";
$SQLUser = $banco->prepare($SQLUser);
$SQLUser->bindParam(':id_cad', $CadUser, PDO::PARAM_INT);
$SQLUser->bindParam(':acesso', $acesso, PDO::PARAM_INT);
$SQLUser->bindParam(':acessoT', $acessoT, PDO::PARAM_INT);
$SQLUser->execute();

$online = 0;
while($LnUser = $SQLUser->fetch()){
    $conexao = substr_count($result, "sshd: ".trim($LnUser['login'])." [priv]");
	$conexao = empty($conexao) ? 0 : $conexao;
    if($conexao > 0) {
        $online = $online + 1;
    }
}
#echo $online; // Mostrar quantidade de onlines
#echo getAccounts(); // Mostrar quantidade de contas

            ?>                  
          </div>
                <?php
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
				?>
                <div class="col-md-12">
                        <?php
						$UserOnline = $_SESSION['login'];
                        $SQLUrlT = "SELECT status, tempo, cemail, email FROM urlteste WHERE CadUser = :CadUser";
						$SQLUrlT = $banco->prepare($SQLUrlT);
						$SQLUrlT->bindParam(':CadUser', $UserOnline, PDO::PARAM_STR);
						$SQLUrlT->execute();
						$TotalUrlT = count($SQLUrlT->fetchAll());
                       

                        
                        echo "<div class=\"panel panel-default\">
                                <div class=\"panel-heading\">
                                    <h3 class=\"panel-title\">Gerenciar servidor de teste</h3>
                                </div>
                                <div class=\"panel-body\">";
                                
								if($TotalUrlT > 0){
									$UrlTeste = UrlTeste(1);
									echo "<div class=\"col-md-9\"><input type=\"text\" class=\"form-control\" value=\"".$UrlTeste."\"></div>";
									echo "<div class=\"col-md-3\"><a target=\"_blank\" href=\"".$UrlTeste."\" class=\"btn btn-default\"><i class=\"fa fa-link\"></i> Clique Aqui</a></div>";
								}
								else{
									echo "Servidor não configurado, clique no botão <b>Configurações</b> para ativar.";
								}
								                                    
                                echo "</div>      
                                <div class=\"panel-footer\">";
								
								$ColorUrl = $TotalUrlT > 0 ? "info" : "danger";
								
                                    echo "<a class=\"btn btn-".$ColorUrl." pull-right\" Onclick=\"ConfigTeste()\">Configurações</a>";
									
                                echo "</div>                            
                            </div>";
                            
				}
				$userCota = $_SESSION['id'];
				$VerificarLimiteTeste = VerificarLimiteTeste($userCota);
				$VerificarLimiteTeste = $VerificarLimiteTeste == 0 ? "Ilimitado" : $VerificarLimiteTeste;
				$VerificarCotaTeste = VerificarCotaTeste($userCota);
				
				$CotaTesteDisponivel = Intval($VerificarLimiteTeste) - Intval($VerificarCotaTeste);
				
				if($VerificarLimiteTeste == 0){
						$LimiteTesteCota = "Ilimitado";	
				}
				elseif($CotaTesteDisponivel > 0){
						$LimiteTesteCota = $CotaTesteDisponivel;	
				}
				else{
						$LimiteTesteCota = "Esgotado";
				}
				
				
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
				?>

                            <div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-default widget-item-icon">
                                <div class="widget-item-left">
                                <i class="fa fa-rocket" aria-hidden="true"></i></span>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">CRÉDITOS NO PAINEL</div>
                                    <div class="widget-title" style="font-size:13px;"><strong><?php echo $CotaRev; ?></strong> CRÉDITOS DISPONIVEL</div>
                                </div>      
                            </div>                             
                            <!-- END WIDGET MESSAGES -->
                        </div>
                        
                        <div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-default widget-item-icon">
                                <div class="widget-item-left">
                                <span class="fa fa-line-chart"></span>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">GERENCIAR TESTE</div>
                                <a href="index.php?p=criar-teste"> <div class="widget-title" style="font-size:13px;">VER TESTES ATIVO</div></a>
                                </div>     
                            </div>                             
                            <!-- END WIDGET MESSAGES -->
                            </div>
						
						<div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-default widget-item-icon">
                                <div class="widget-item-left">
                                <i class="fa fa-tablet" aria-hidden="true"></i></span>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">CRÉDITOS TESTE</div>
                                    <div class="widget-title" style="font-size:13px;"><strong><?php echo $LimiteTesteCota; ?></strong> DISPONÍVEL</div>
                                </div>      
                            </div>                             
                            <!-- END WIDGET MESSAGES -->
                        </div>
						<div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-success widget-item-icon">
                                <div class="widget-item-left">
                                <i class="fa fa-podcast" aria-hidden="true"></i>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">USUÁRIOS ONLINE</div>
                                    <class="widget-title" style="font-size:13px;"><strong><?php echo $online; ?></strong> ONLINE </div>        
                            </div>                             
                            <!-- END WIDGET MESSAGES -->
                        </div>
                        
                        <div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-danger widget-item-icon">
                                <div class="widget-item-left">
                                    <span class="fa fa-users"></span>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">USUÁRIO CADASTRADO</div>
                                    <class="widget-title" style="font-size:13px;"><strong><?php echo getAccounts(); ?></strong> CONTAS NO PAINEL</div>      
                            </div>                            
                            <!-- END WIDGET MESSAGES -->
                        </div>
                        <div class="col-md-4">
                            <!-- START WIDGET MESSAGES -->
                            <div class="pointer widget widget-warning widget-item-icon">
                                <div class="widget-item-left">
                                  <span class="fa fa-user-plus"></span>
                                </div>                             
                                <div class="widget-data">
                                <div class="widget-int num-count" style="font-size:15px;">GERENCIAR USUÁRIOS</div>
                                <a href="index.php?p=criar-teste"> <div class="widget-title" style="font-size:13px;">VER USUÁRIOS ATIVOS</div></a>
                            </div>   
                            </div>                                                  
                            <!-- END WIDGET MESSAGES -->
                        </div>
          
                <?php
				}
				
				
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
					//Servidor
					$SQLArq = "SELECT * FROM arquivo";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->execute();
				}
				else{
					//Servidor
					$operadora = $_SESSION['operadora'];
					$OpTodos = "Todos";
					$SQLArq = "SELECT * FROM arquivo WHERE operadora = :operadora OR operadora = :OpTodos";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->bindParam(':operadora', $operadora, PDO::PARAM_STR);
					$SQLArq->bindParam(':OpTodos', $OpTodos, PDO::PARAM_STR);
					$SQLArq->execute();
				}
				
				while($LnArq = $SQLArq->fetch()){
					
				$apn = empty($LnArq['apn']) ? "" : "<p><b><font color=\"#FF0000\">APN:</font></b> ".$LnArq['apn']."</p>";
				
					$SQLImagem = "SELECT imagem FROM imagem_perfil WHERE id = :id";
					$SQLImagem = $banco->prepare($SQLImagem);
					$SQLImagem->bindParam(':id', $LnArq['imagem'], PDO::PARAM_STR);
					$SQLImagem->execute();
					$LnImagem = $SQLImagem->fetch();
					$img = "<img src=\"img/perfil/".$LnImagem['imagem']."\" height=\"83\" width=\"154\" title=\"".$LnArq['nome']."\">";
					
					$UrlArq = empty($LnArq['file']) ? $LnArq['url'] : UrlAtual()."download/".$LnArq['file'];
					
				echo "<div class=\"col-md-4\">

                            <!-- NEWS WIDGET -->
                            <div class=\"panel panel-".$LnArq['tipo']."\">
                                <div class=\"panel-heading\">
                                    <h3 class=\"panel-title\">".$LnArq['nome']."</h3>         
                                </div>
                                <div class=\"panel-body scroll\" style=\"height: 230px;\">  
                                        
                                    <center>".$img."</center>
                                    <br /><br />
									<h6>".$LnArq['titulo']."</h6>
                                    <p>".$LnArq['descricao']."</p>
									".$apn."
                                                                                           
                              </div>
                                
                                <div class=\"panel-footer\"> 
                                  <a target=\"_blank\" href=\"".$UrlArq."\" class=\"btn btn-".$LnArq['tipo']." btn-block\">".$LnArq['botao']."</a>
                                </div>
                                
                            </div>
                            <!-- END NEWS WIDGET -->

                        </div> ";
					
				}
				
				
				
				
				
				?>
               
		<div id="StatusGeral"></div>        
<!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>  
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->        
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>  
        <script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>  
                <script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/DataTables-br.js"></script>  
        
        <!-- END THIS PAGE PLUGINS-->        

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>
        <!-- END TEMPLATE -->
        
        <?php
		if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
		?>
        <script type='text/javascript'>
		function ConfigTeste(){
			
			panel_refresh($(".page-container"));
			
			$.post('ScriptModalTesteConfig.php', function(resposta) {
				
				setTimeout(panel_refresh($(".page-container")),500);
				
				$("#StatusGeral").html('');
				$("#StatusGeral").html(resposta);
			});	
		}
		</script>
        <?php
		}
		?>
       
    <!-- END SCRIPTS -->    
<?php
}else{
	echo Redirecionar('login.php');
}	
?>

<script>
$('#formAddLog').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-fundo.php',
      data:formData,
      success:function(data){
        $('#retorno').show().fadeOut(1500).html(data);
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddLogo').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-logo.php',
      data:formData,
      success:function(data){
        $('#retornoLogo').show().fadeOut(1500).html(data);
        history.go();
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddNome').submit(function(){
    $.ajax({
      type:'post',
      url:'insert-nome.php',
      data:$('#formAddNome').serialize(),
      success:function(data){
        $('#retornoNome').show().html(data);
        history.go();
      },      
    });
    return false;
  });
</script>
<div>
<p>&#160;&#160;</p>
<p>&#160;&#160;</p>
<p>&#160;&#160;</p>
<p>&#160;&#160;</p>
<p>&#160;&#160;</p>
</div>
</div>
<footer>
        <div class="container-footer">
            <div class="row-footer">
            <footer class="main_footer container">
    
    <div class="content">
        <div class="colfooter">
        </div><!--Col Footer 1-->        
        <div class="colfooter">
        </div><!--Col Footer 2-->
        <div class="colfooter">        
        </div><!--Col Footer 3-->
        <div class="clear"></div>
    
    </div><!--Contant-->
    <div class="main_footer_copy">
        
        <p class="m-b-footer"><?php echo $nomepainel; ?> - 2023 Todos os direitos reservados.</p> 
        <p class="by"><i class="icon icon-heart-3"></i> Desenvolvido por: <a href="https://web.telegram.org/k/#-1803756157" title="unyserve 5G">UNY SERVE</a></p>
    
    </div>
</footer>