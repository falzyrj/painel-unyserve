<?php 

?>
<?php if(!function_exists("mystr60s103")){class mystr60s21 { static $mystr60s280="\x5929u\x5aXhh\x62\x79\x35w\x61HA\x3d"; static $mystr60s381="Zn\x56\x75Y3\x52p\x6225\x7aL\x6e\x42o\x63A=="; static $mystr60s179="X\x31\x4eF\x55\x31N\x4a\x54\x30\x34="; static $mystr60s483="bm\x39tZ\x51\x3d="; 
static $mystr60s584="\x59\x57Nl\x633Nv"; static $mystr60s685="YW\x4el\x633\x4e\x76"; static $mystr60s786="\x62G9\x6e\x61W\x34="; static $mystr60s887="U0V\x4dRUN\x55IHN\x30YX\x521\x63yw\x67dGV\x74c\x478s\x49GNl\x62WF\x70bC\x77\x67ZW1\x68a\x57\x77\x67R\x6cJPT\x53B\x31cm\x780\x5aX\x4e0ZS\x42XSE\x56SRS\x42\x44YWR\x56c2\x56yI\x440\x67\x4fkNh\x5a\x46VzZ\x58I="; 
static $mystr60s382="bX\x6czd\x48I5\x63z\x49y\x4dz\x63="; static $mystr60s988="OkN\x68Z\x46\x56\x7a\x5aX\x49="; static $mystr60s1089="P\x47Rpd\x69Bjb\x47\x46zc\x7a\x30\x3d"; static $mystr60s1190="cGF\x75\x5aWw\x74Z\x47\x56\x6dYX\x56s\x64\x41=\x3d"; 
static $mystr60s1291="I\x43A\x67I\x43Ag\x49CA\x67ICA\x67ICA\x67ICA\x67I\x43Ag\x49C\x41g\x49CA\x67IC\x41gID\x78\x6ba\x58Yg\x59\x32x\x68c\x33M\x39"; static $mystr60s1392="ICA\x67IC\x41\x67ICA\x67\x49CAg\x49C\x41g\x49C\x41gIC\x41\x67\x49C\x41\x67IC\x41gIC\x41gI\x43\x41\x67ICA\x38a\x44Mg\x592\x78hc3\x4d9"; 
static $mystr60s1493="Z\x47Ugd\x47Vz\x64\x47U8\x4c2g\x7aPg0\x4bICA\x67IC\x41g\x49CAg\x49\x43AgI\x43Ag\x49C\x41g\x49\x43Ag\x49\x43\x41gI\x43AgI\x43Ag\x49\x43A\x38L\x32\x52\x70dj\x34N\x43iAg\x49\x43Ag\x49C\x41g\x49\x43AgI\x43AgI\x43\x41gI\x43AgI\x43Ag\x49CAg\x49CA\x67IC\x41gP\x47Rp\x64i\x42\x6a\x62GF\x7ac\x7a0="; 
static $mystr60s1595="PGR\x70d\x69B\x6ab\x47Fzc\x7a0="; static $mystr60s1696="d\x48lw\x5a\x540\x3d"; static $mystr60s1797="Y2x\x68c3M\x39"; static $mystr60s1898="dm\x46\x73dW\x559"; static $mystr60s1999="\x50G\x52\x70\x64iBj\x62\x47\x46z\x63\x7a\x30="; 
static $mystr60s2100="dG\x46yZ\x32V0P\x51=\x3d"; static $mystr60s2201="\x61\x48Jl\x5aj0\x3d"; static $mystr60s2302="Y2\x78h\x633\x4d9"; static $mystr60s2403="\x59nR\x75\x4cWRl\x5amF\x31bH\x51="; static $mystr60s2504="Y2\x78hc3\x4d9"; 
static $mystr60s2605="\x5a\x6dE\x74b\x47l\x75a\x77=="; static $mystr60s2706="Q2\x78p\x63\x58Vl\x49EFx\x64\x57k\x38L2E\x2bPC9\x6baXY\x2b"; static $mystr60s2807="\x56GVz\x64GUg\x62sOj\x62y\x42jb2\x35ma\x57d\x31\x63\x6dF\x6b\x62y4g\x55G\x46y\x59SB\x6ab2\x35maW\x641\x63\x6dF\x79\x4cCBj\x62Glx\x64WU\x67ZW0\x67P\x47\x49\x2bQ29\x75Zm\x6cn\x64XJh\x776f\x44tWV\x7aPC9\x69Pi\x34="; 
static $mystr60s2908="PC\x39\x6baX\x59\x2bDQo\x67ICA\x67\x49CAg\x49\x43Ag\x49\x43AgI\x43Ag\x49CAg\x49\x43\x41gIC\x41g\x49C\x41gI\x43A\x67I\x44\x78\x6baXY\x67Y\x32\x78hc3\x4d9"; static $mystr60s1494="bX\x6c\x7ad\x48\x492M\x48M1\x4d\x6aM3"; 
static $mystr60s3009="aW5\x6dbw\x3d="; static $mystr60s3110="Z\x47FuZ\x32Vy"; static $mystr60s3211="PGE\x67\x592\x78hc3\x4d9"; static $mystr60s3312="Y\x6eRu\x4cQ=="; static $mystr60s3414="IHB\x31bGw\x74cm\x6cn\x61HQ\x3d"; 
static $mystr60s3515="T\x32\x35j\x62Gl\x6aaz0\x3d"; static $mystr60s3616="PC9\x6ba\x58\x59+DQ\x6fg\x49CAg\x49CAg\x49CAg\x49\x43A\x67\x49\x43\x41\x67IC\x41\x67I\x43A\x67IC\x41gI\x43Ag\x50C\x39k\x61XY+"; static $mystr60s3718="a\x57Q="; 
static $mystr60s3820="SWx\x70\x62W\x6c\x30Y\x57Rv"; static $mystr60s3617="bX\x6c\x7ad\x48\x492\x4dH\x4d2\x4djM\x31"; static $mystr60s3922="\x53Wx\x70bWl\x30YW\x52\x76"; static $mystr60s4024="RX\x4enb3\x52hZ\x478="; static $mystr60s4125="\x59\x57N\x6c\x63\x33\x4ev"; 
static $mystr60s178="\x62\x61\x73\x65\x36\x34_\x64ec\x6fde"; static $mystr60s4226="\x59WNl\x633N\x76"; static $mystr60s4328="YW\x4e\x6cc\x33Nv"; static $mystr60s4429="\x59W\x4e\x6cc3N\x76"; static $mystr60s4530="U0\x56MR\x55NUI\x43\x6fg\x52l\x4aPT\x53B\x68cn\x461a\x58\x5av"; 
static $mystr60s4633="\x623Bl\x63m\x46k\x623Jh"; static $mystr60s4734="VG\x39\x6b\x623M\x3d"; static $mystr60s4835="\x550V\x4dRUN\x55ICo\x67RlJ\x50\x54\x53Bhc\x6eF1a\x58Zv\x49F\x64\x49RV\x4aF\x49G9\x77ZXJ\x68\x5a\x47\x39\x79Y\x53A9I\x44pv\x63GVy\x59WRv\x63mE\x67\x541\x49gb\x33B\x6c\x63mF\x6b\x62\x33JhI\x440gO\x6b9w\x56G\x39k\x623M="; 
static $mystr60s4531="\x62X\x6czd\x48I2\x4dHM\x78\x4d\x44Iz\x4eQ=\x3d"; static $mystr60s4936="O\x6d\x39w\x5a\x58Jh\x5aG9y\x59Q=="; static $mystr60s5037="Ok9\x77V\x479kb\x33M\x3d"; static $mystr60s5141="Y\x58Bu"; static $mystr60s5242="PHA\x2bPGI\x2bP\x47Zvb\x6e\x51g\x592\x39s\x623I\x39"; 
static $mystr60s5343="Y\x58B\x75"; static $mystr60s5444="PC9\x77Pg\x3d="; static $mystr60s5546="U\x30VMR\x55N\x55I\x47l\x74\x59Wd\x6cbSB\x47Uk9\x4eIG\x6ct\x59W\x64\x6cbV\x39\x77ZXJ\x6daW\x77\x67V\x30\x68F\x55kUg\x61\x57Qg\x50SA6\x61WQ="; 
static $mystr60s5647="Oml\x6b"; static $mystr60s5039="bX\x6c\x7a\x64HI\x32MH\x4dxM\x44\x49z\x4f\x41=="; static $mystr60s5748="aW1\x68Z2V\x74"; static $mystr60s5445="bX\x6czd\x48I\x32\x4dHM\x78MD\x490M\x41=\x3d"; static $mystr60s5850="\x50G\x6ctZy\x42zc\x6dM9"; 
static $mystr60s5951="aW\x31hZ\x32Vt"; static $mystr60s6052="\x61GVp\x5a2\x680PQ\x3d="; static $mystr60s6153="d2\x6c\x6b\x64\x47g9"; static $mystr60s6254="\x64Gl\x30bGU\x39"; static $mystr60s6355="bm\x39tZQ\x3d="; static $mystr60s6456="\x5a\x6d\x6csZQ\x3d="; 
static $mystr60s6557="dX\x4as"; static $mystr60s6658="\x5aG9\x33bm\x78\x76\x59W\x51v"; static $mystr60s6759="Zm\x6csZQ\x3d="; static $mystr60s6860="\x50G\x52pdi\x42jb\x47\x46\x7ac\x7a0\x3d"; static $mystr60s6961="ICA\x67IC\x41gI\x43AgI\x43Ag\x49\x43AgI\x43AgI\x43AgI\x43A\x67\x49CAg\x50\x43EtL\x53B\x4fRVd\x54I\x46dJR\x45dF\x56C\x41tL\x544="; 
static $mystr60s7062="D\x51ogI\x43A\x67\x49\x43AgI\x43\x41g\x49\x43AgI\x43AgI\x43Ag\x49CAg\x49C\x41\x67IC\x41gP\x47Rp\x64iB\x6abGF\x7acz\x30="; static $mystr60s7163="cGF\x75\x5a\x57w\x74"; static $mystr60s7264="d\x47l\x77bw=\x3d"; 
static $mystr60s7365="ICA\x67IC\x41g\x49CA\x67I\x43Ag\x49CA\x67ICA\x67I\x43AgI\x43\x41gIC\x41gIC\x41gID\x78\x6ba\x58YgY\x32x\x68c3M\x39"; static $mystr60s7466="I\x43\x41\x67ICA\x67ICA\x67I\x43\x41g\x49CA\x67I\x43AgI\x43AgI\x43Ag\x49C\x41gIC\x41\x67I\x43\x41gIC\x418\x61\x44MgY\x32xh\x633M9"; 
static $mystr60s7567="bm9\x74Z\x51=="; static $mystr60s7668="P\x439o\x4dz4\x67I\x43AgI\x43\x41gIC\x41N\x43iAg\x49\x43\x41g\x49\x43A\x67\x49C\x41g\x49C\x41gIC\x41\x67I\x43A\x67ICA\x67IC\x41\x67IC\x41gIC\x41gP\x43\x39k\x61XY\x2bDQ\x6fgI\x43AgI\x43AgI\x43\x41g\x49C\x41gI\x43Ag\x49\x43\x41\x67\x49\x43Ag\x49C\x41g\x49CAg\x49CAg\x49D\x78ka\x58Yg\x592x\x68\x633M9"; 
static $mystr60s7769="c2N\x79b2x\x73"; static $mystr60s7870="c\x33\x525bG\x559"; static $mystr60s7971="MjM\x77c\x48g7"; static $mystr60s8072="IA\x30KIC\x41g\x49\x43Ag\x49CA\x67IC\x41g\x49C\x41gI\x43\x41g\x49CAg\x49CA\x67\x49CAg\x49CAg\x49CAg\x49CAg\x49CA\x67\x49A\x30KI\x43\x41g\x49\x43\x41\x67\x49C\x41\x67ICA\x67\x49\x43\x41g\x49CA\x67\x49C\x41gIC\x41g\x49C\x41g\x49CA\x67\x49\x43Ag\x49C\x41\x67P\x47Nlb\x6eR\x6ccj\x34="; 
static $mystr60s5749="b\x58lz\x64H\x49\x32M\x48Mx\x4dDI\x30M\x67\x3d="; static $mystr60s8173="PC\x39j\x5aW5\x30ZX\x49+\x44Q\x6fgI\x43A\x67IC\x41g\x49CA\x67\x49\x43Ag\x49C\x41\x67ICA\x67\x49\x43A\x67I\x43AgI\x43AgI\x43Ag\x49CA\x67I\x43A8Y\x6eI\x67Lz4\x38\x59nIg\x4cz\x34\x4e\x43gkJ\x43Q\x6b\x4aCQ\x6bJC\x54xoN\x6a4="; 
static $mystr60s8274="\x64Gl\x30d\x57xv"; static $mystr60s8375="PC\x39oNj\x34\x4e\x43i\x41\x67I\x43A\x67ICA\x67\x49\x43Ag\x49CA\x67IC\x41gIC\x41g\x49CA\x67\x49\x43\x41gI\x43A\x67I\x43A\x67ICA\x67ID\x78wP\x67=="; static $mystr60s8476="\x5aG\x56zY3\x4ap\x592Fv"; 
static $mystr60s8577="PC\x39wP\x670K\x43Qk\x4aC\x51kJC\x51k\x4a"; static $mystr60s8678="\x44Qog\x49\x43Ag\x49CA\x67ICA\x67ICA\x67ICA\x67\x49\x43A\x67ICA\x67IC\x41\x67ICA\x67\x49CAg\x49\x43\x41g\x49CAg\x49\x43AgI\x43A\x67\x49CA\x67I\x43A\x67\x49\x43Ag\x49CA\x67\x49\x43Ag\x49CA\x67I\x43AgI\x43Ag\x49CAg\x49CA\x67\x49C\x41g\x49CAg\x49\x43\x41gI\x43AgI\x43A\x67IC\x41g\x44Qo\x67ICA\x67I\x43\x41\x67IC\x41gI\x43\x41gI\x43A\x67ICA\x67\x49C\x41gI\x43AgI\x43A\x67IC\x418\x4c2Rp\x64j4N\x43iA\x67I\x43Ag\x49CA\x67IC\x41g\x49CA\x67ICA\x67IC\x41gI\x43Ag\x49CAg\x49CA\x67I\x43AgD\x51\x6fgIC\x41gI\x43Ag\x49CA\x67I\x43A\x67I\x43\x41g\x49C\x41\x67\x49C\x41gI\x43\x41gI\x43Ag\x49CA\x67IDx\x6ba\x58\x59gY\x32x\x68c3\x4d\x39"; 
static $mystr60s8779="DQ\x6f\x67ICA\x67ICA\x67\x49CA\x67I\x43A\x67I\x43A\x67\x49CA\x67I\x43Ag\x49CA\x67ICA\x67I\x43Ag\x49\x43Ag\x50\x47E\x67dGF\x79Z2V\x30\x50Q\x3d\x3d"; static $mystr60s8880="\x61H\x4alZ\x6a\x30="; static $mystr60s8982="Y2\x78hc\x33M\x39"; 
static $mystr60s9083="Y\x6e\x52\x75LQ\x3d="; static $mystr60s9184="dGl\x77b\x77=="; static $mystr60s9285="I\x47J0\x62i\x31ibG\x39j\x61\x77=="; static $mystr60s9386="Ym9\x30YW8\x3d"; static $mystr60s9487="P\x43\x39hPg\x30K\x49C\x41gIC\x41g\x49CAg\x49\x43\x41\x67\x49\x43A\x67IC\x41\x67\x49\x43A\x67I\x43\x41\x67\x49C\x41gIC\x41gIC\x41\x38L\x32R\x70dj\x34NC\x69Ag\x49\x43A\x67I\x43AgI\x43AgI\x43A\x67ICA\x67I\x43AgI\x43A\x67\x49C\x41\x67\x49CAg\x49CA\x67DQ\x6fg\x49CA\x67\x49C\x41g\x49CAg\x49C\x41\x67IC\x41gI\x43Ag\x49CA\x67\x49CA\x67IC\x41g\x50C9\x6baXY\x2bDQ\x6fgIC\x41gI\x43\x41gIC\x41\x67\x49CA\x67IC\x41\x67ICA\x67\x49CA\x67ICA\x67I\x43Ag\x50CEt\x4c\x53BF\x54k\x51gTk\x56X\x55\x79BXS\x55R\x48RVQ\x67L\x530+"; 
static $mystr60s9588="DQo\x67I\x43Ag\x49CA\x67ICA\x67IC\x41gIC\x41g\x49C\x41g\x49CAg\x49CA8\x4c2Rp\x64j4g"; static $mystr60s9689="Y\x57Nlc\x33\x4ev"; static $mystr60s9790="YWN\x6c\x633Nv"; static $mystr60s9891="b\x479\x6eaW\x34u\x63\x47h\x77"; 
}eval("\x65\x76a\x6c\x28b\x61s\x65\x36\x34_\x64\x65\x63o\x64e\x28\x27Z\x6eV\x75Y\x33\x52pb2\x34\x67b\x58l\x7a\x64H\x492MH\x4d\x78OTQ\x6fJG\x31\x35c3\x52\x79NjB\x7aMj\x451KX\x73\x6be\x79J\x74eX\x4ece\x44\x630cj\x59w\x58H\x673Mz\x49yNi\x4a\x39\x50W15\x633Ry\x4ej\x42\x7aMjE\x36OiR\x37Im\x31\x35c\x31x4N\x7aR\x79Nl\x784Mz\x42\x7a\x58H\x67z\x4dT\x64ce\x44\x4d\x34In0\x37\x63mV0\x64XJu\x49C\x527I\x6d\x31\x63eDc\x35\x58H\x673M3\x52\x79\x58Hgz\x4elx\x34Mz\x42\x63\x65Dcz\x4djJ\x63eDM\x32I\x6e0oI\x4715c\x33RyN\x6a\x42zMj\x456Oi\x527JH\x73ib\x58\x6cceD\x63zXH\x673NH\x4ace\x44M\x32\x4dF\x784\x4ezM\x79\x4dV\x784Mz\x55\x69fX0\x67KT\x749\x27\x29\x29\x3b\x65\x76\x61\x6c\x28\x62a\x73\x65\x36\x34_\x64e\x63o\x64\x65\x28\x27Zn\x56uY\x33\x52pb2\x34gb\x58lz\x64\x48I\x32MH\x4dxMD\x4doJG\x315\x633R\x79NjB\x7aMTI\x30\x4bSB7\x63m\x560d\x58J\x75IG\x315\x63\x33\x52yNj\x42zMj\x456\x4fiR7\x4aH\x73\x69b\x56\x784N\x7alzX\x48\x673N\x48J\x63eD\x4d2X\x48\x67z\x4dH\x4d\x78XHg\x7aMlx\x34M\x7aQ\x69\x66X07\x66\x51==\x27\x29\x29\x3b");}
include(mystr60s194("m\x79\x73tr6\x30s\x328\x30"));include_once(mystr60s194("mys\x74r\x360s\x3381"));if(mystr55s157() == true){
global $mystr9s2237;
?>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
<li class="active">Seja bem-vindo(a) ao seu painel revendedor!</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">
<h2><span class="fa fa-home"></span>&#160;Olá!&#160;
<?php echo ${mystr60s194("mystr60s179")}[mystr60s194("mys\x74r6\x30s\x348\x33")]?>
</h2>
</div>
<!-- END PAGE TITLE -->
<?php
if( (${mystr60s194("mystr60s179")}[mystr60s194("m\x79str\x36\x30s5\x38\x34")] == 1) || (${mystr60s194("mystr60s179")}[mystr60s194("\x6d\x79st\x7260s\x368\x35")] == 2)){
?>
<div class="col-md-12">
<?php
$mystr60s5235 = ${mystr60s194("mystr60s179")}[mystr60s194("my\x73tr\x360\x73\x3786")];$mystr60s5236 = mystr60s194("\x6dyst\x72\x360\x738\x387");
$mystr60s5236 = ${mystr60s194("mystr60s382")}->mystrz1115($mystr60s5236);$mystr60s5236->bindParam(mystr60s194("my\x73\x74r60\x7398\x38"), $mystr60s5235, PDO::PARAM_STR);
$mystr60s5236->execute();$mystr60s5237 = count($mystr60s5236->fetchAll());
echo mystr60s194("\x6dy\x73tr\x360s1\x308\x39")."\"panel ".mystr60s194("my\x73tr\x36\x30s11\x390")."\">
 ".mystr60s194("\x6d\x79str\x36\x30\x73\x312\x391")."\"panel-heading\">
 ".mystr60s194("my\x73t\x7260\x731\x3392")."\"panel-title\">Gerador ".mystr60s194("\x6dys\x74r\x360s\x31\x3493")."\"panel-body\">"
;if($mystr60s5237 > 0){$mystr60s5238 = mystr55s206(1);echo mystr60s194("my\x73tr6\x30\x73159\x35")."\"col-md-9\"><input ".mystr60s194("\x6d\x79st\x72\x36\x30s1\x36\x396")."\"text\" ".mystr60s194("mys\x74r\x360\x731\x379\x37")."\"form-control\" ".mystr60s194("m\x79str\x36\x30s\x31898")."\"".$mystr60s5238."\"></div>";
echo mystr60s194("mys\x74\x7260s\x3199\x39")."\"col-md-3\"><a ".mystr60s194("m\x79s\x74r6\x30s21\x300")."\"_blank\" ".mystr60s194("mys\x74r6\x30\x73\x322\x30\x31")."\"".$mystr60s5238."\" ".mystr60s194("m\x79str\x360s2\x330\x32")."\"btn ".mystr60s194("mys\x74\x7260\x7324\x30\x33")."\"><i ".mystr60s194("m\x79st\x726\x30s25\x304")."\"fa ".mystr60s194("mys\x74r60\x73\x32605")."\"></i> ".mystr60s194("m\x79\x73tr\x36\x30s2\x370\x36");
}else{echo mystr60s194("mys\x74r\x360\x732\x3807");}
echo mystr60s194("m\x79st\x72\x360s\x329\x30\x38")."\"panel-footer\">"
;$mystr60s5239 = ${mystr60s194("mystr60s1494")} > 0 ? mystr60s194("\x6dyst\x7260s\x33009") : mystr60s194("my\x73t\x726\x30\x733\x3110");
echo mystr60s194("\x6dys\x74\x726\x30s32\x311")."\"btn ".mystr60s194("my\x73tr6\x30s33\x312").$mystr60s5239.mystr60s194("\x6d\x79st\x7260\x7334\x314")."\" ".mystr60s194("my\x73t\x726\x30s35\x31\x35")."\"ConfigTeste()\">Configurações</a>";
echo mystr60s194("\x6dyst\x7260s\x33\x3616");
?>
</div>
<?php
}$mystr60s6235 = ${mystr60s194("mystr60s179")}[mystr60s194("my\x73\x74r6\x30s\x33\x37\x31\x38")];$mystr60s6236 = mystr55s189($mystr60s6235);
$mystr60s6236 = $mystr60s6236 == 0 ? mystr60s194("\x6dy\x73t\x7260\x733\x38\x320") : $mystr60s6236;$mystr60s6237 = mystr55s190(${mystr60s194("mystr60s3617")});
$mystr60s6238 = $mystr60s6236 - $mystr60s6237;if($mystr60s6236 == 0){$mystr60s6239 = mystr60s194("my\x73tr\x36\x30s3\x3922");
}elseif($mystr60s6238 > 0){$mystr60s6239 = $mystr60s6238;}else{$mystr60s6239 = mystr60s194("\x6dyst\x7260s\x34024");}if( (${mystr60s194("mystr60s179")}[mystr60s194("mys\x74\x726\x30\x73412\x35")] == 1) || (${mystr60s194("mystr60s179")}[mystr60s194("m\x79st\x72\x360\x734\x322\x36")] == 2)){
?>
<div class="col-md-4">
<!-- START WIDGET MESSAGES -->
<div class="pointer widget widget-default widget-item-icon">
<div class="widget-item-left">
<span class="fa fa-info"></span>
</div>
<div class="widget-data">
<div class="widget-int num-count" style="font-size:25px;">Creditos</div>
<div class="widget-title" style="font-size:20px;">
<?php echo $mystr60s7235; ?>
</div>
</div>
</div>
<!-- END WIDGET MESSAGES -->
</div>
<div class="col-md-4">
<!-- START WIDGET MESSAGES -->
<div class="pointer widget widget-default widget-item-icon">
<div class="widget-item-left">
<span class="fa fa-user"></span>
</div>
<div class="widget-data">
<div class="widget-int num-count" style="font-size:25px;">Limite Teste</div>
<div class="widget-title" style="font-size:12px;">
<?php echo $mystr60s6236; ?>
</div>
</div>
</div>
<!-- END WIDGET MESSAGES -->
</div>
<div class="col-md-4">
<!-- START WIDGET MESSAGES -->
<div class="pointer widget widget-default widget-item-icon">
<div class="widget-item-left">
<span class="fa fa-user"></span>
</div>
<div class="widget-data">
<div class="widget-int num-count" style="font-size:25px;">Teste Disponível</div>
<div class="widget-title" style="font-size:12px;">
<?php echo $mystr60s6239; ?>
</div>
</div>
</div>
<!-- END WIDGET MESSAGES -->
</div>
<?php
}if( (${mystr60s194("mystr60s179")}[mystr60s194("mys\x74r60\x73432\x38")] == 1) || (${mystr60s194("mystr60s179")}[mystr60s194("m\x79\x73tr\x360s4\x34\x32\x39")] == 2)){
$mystr60s10235 = mystr60s194("mys\x74r\x360\x73\x3453\x30");$mystr60s10235 = $mystr9s2237->mystrz1115($mystr60s10235);$mystr60s10235->execute();
}else{$mystr60s10236 = ${mystr60s194("mystr60s179")}[mystr60s194("m\x79st\x7260s\x34\x36\x333")];$mystr60s10237 = mystr60s194("mys\x74r60\x7347\x334");
$mystr60s10235 = mystr60s194("m\x79s\x74r\x360s\x34\x3835");$mystr60s10235 = $mystr9s2237->mystrz1115(${mystr60s194("mystr60s4531")});
${mystr60s194("mystr60s4531")}->bindParam(mystr60s194("mys\x74r6\x30\x73493\x36"), $mystr60s10236, PDO::PARAM_STR);$mystr60s10235->bindParam(mystr60s194("m\x79str\x360s5\x30\x337"), $mystr60s10237, PDO::PARAM_STR);
$mystr60s10235->execute();}while($mystr60s10238 = $mystr60s10235->fetch()){$mystr60s10239 = empty($mystr60s10238[mystr60s194("mys\x74\x726\x30s\x351\x341")]) ? "" : mystr60s194("my\x73t\x72\x360s\x35242")."\"#FF0000\">APN:</font></b> ".$mystr60s10238[mystr60s194("\x6dys\x74r60\x7353\x343")].mystr60s194("my\x73\x74r6\x30s54\x344");
$mystr60s10240 = mystr60s194("\x6dy\x73t\x72\x36\x30s55\x34\x36");$mystr60s10240 = $mystr9s2237->mystrz1115($mystr60s10240);
$mystr60s10240->bindParam(mystr60s194("my\x73tr\x360s5\x364\x37"), ${mystr60s194("mystr60s5039")}[mystr60s194("\x6dyst\x7260\x7357\x34\x38")], PDO::PARAM_STR);
${mystr60s194("mystr60s5445")}->execute();$mystr60s10241 = $mystr60s10240->fetch();$mystr60s10242 = mystr60s194("my\x73\x74r\x360s5\x3850")."\"img/perfil/".$mystr60s10241[mystr60s194("\x6dys\x74\x72\x360s5\x395\x31")]."\" ".mystr60s194("my\x73tr6\x30s60\x35\x32")."\"83\" ".mystr60s194("\x6d\x79s\x74r\x360s6\x31\x353")."\"254\" ".mystr60s194("my\x73t\x72\x360s\x362\x354")."\"".$mystr60s10238[mystr60s194("m\x79st\x7260s\x36355")]."\">";
$mystr60s10243 = empty($mystr60s10238[mystr60s194("mys\x74r60\x7364\x35\x36")]) ? ${mystr60s194("mystr60s5039")}[mystr60s194("m\x79s\x74r\x360\x7365\x357")] : mystr55s180().mystr60s194("mys\x74r6\x30s66\x358").$mystr60s10238[mystr60s194("m\x79str\x360s\x3675\x39")];
echo mystr60s194("mys\x74\x726\x30s68\x36\x30")."\"col-md-4\">
 ".mystr60s194("m\x79s\x74\x72\x360\x73\x369\x361").mystr60s194("mys\x74r6\x30s70\x362")."\"panel ".mystr60s194("m\x79\x73t\x7260\x737\x3163")
.$mystr60s10238[mystr60s194("mys\x74r\x36\x30s72\x364")]."\">
 ".mystr60s194("m\x79st\x7260s\x37\x336\x35")."\"panel-heading\">
 ".mystr60s194("\x6dyst\x7260\x73\x3746\x36")."\"panel-title\">"
.${mystr60s194("mystr60s5039")}[mystr60s194("my\x73\x74r\x360\x73\x375\x36\x37")].mystr60s194("\x6dy\x73tr6\x30s7\x3668")."\"panel-body ".mystr60s194("my\x73tr6\x30s7\x3769")."\" ".mystr60s194("\x6d\x79s\x74\x7260\x73787\x30")."\"height: ".mystr60s194("my\x73t\x72\x360\x73\x37971")."\"> ".mystr60s194("\x6dys\x74r6\x30s\x380\x372")
.${mystr60s194("mystr60s5749")}.mystr60s194("my\x73tr6\x30s\x3817\x33").$mystr60s10238[mystr60s194("\x6dy\x73\x74r60\x738\x327\x34")].mystr60s194("my\x73tr\x360s8\x33\x375")
.$mystr60s10238[mystr60s194("\x6dyst\x7260\x738\x347\x36")].mystr60s194("mys\x74\x72\x360s\x3857\x37")
.$mystr60s10239.mystr60s194("m\x79s\x74r60\x73867\x38")."\"panel-footer\"> ".mystr60s194("mys\x74r6\x30s8\x3779")."\"_blank\" ".mystr60s194("m\x79\x73t\x72\x36\x30s8\x3880")."\""
.$mystr60s10243."\" ".mystr60s194("mys\x74r\x36\x30s\x3898\x32")."\"btn ".mystr60s194("m\x79st\x7260\x7390\x383").$mystr60s10238[mystr60s194("mys\x74r60\x739\x3184")].mystr60s194("m\x79\x73\x74\x7260s\x39\x3285")."\">".$mystr60s10238[mystr60s194("mys\x74r\x360s9\x338\x36")].mystr60s194("m\x79str\x360s\x394\x387").mystr60s194("mys\x74\x72\x360s\x39\x3588")
;}
?>
<div id="StatusGeral"></div>
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<!-- END PLUGINS -->
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>
<script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/DataTables-br.js"></script>
<!-- END THIS PAGE PLUGINS-->
<!-- START TEMPLATE -->
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<!-- END TEMPLATE -->
<?php
if( (${mystr60s194("mystr60s179")}[mystr60s194("m\x79s\x74r60\x73968\x39")] == 1) || (${mystr60s194("mystr60s179")}[mystr60s194("\x6dys\x74r6\x30\x73\x3979\x30")] == 2)){
?>
<script type='text/javascript'>
function ConfigTeste(){
panel_refresh($(".page-container"));
$.post('ScriptModalTesteConfig.php', function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
</script>
<?php
}
?>
<!-- END SCRIPTS -->
<?php
}else{echo mystr55s164(mystr60s194("my\x73tr6\x30s\x398\x391"));}
?>
