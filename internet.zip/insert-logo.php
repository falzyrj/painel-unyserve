<?php
$diretorio = "img/fundo";
if (!file_exists($diretorio)){
    mkdir($diretorio, 0777, true);
}

if($_FILES['fotologo']['name'] != ''){           
    $extensao = strrchr($_FILES['fotologo']['name'],'.');
    $novonome = mb_strtolower(md5(uniqid(rand(), true)).$extensao);
    $arquivo_tmp = $_FILES['fotologo']['tmp_name']; 
    move_uploaded_file($arquivo_tmp, $diretorio.'/'.$novonome);

    //limpa sempre o arquivo
    $fp = fopen('img/arquivo-logo.txt', "w");
    //salva o nome novo
    file_put_contents('img/arquivo-logo.txt', $novonome,FILE_APPEND); 

    echo '<a class="btn btn-warning">Salvo com sucesso</a>'; 

}else{
    echo '<a class="btn btn-danger">Erro inesperado!!</a>'; 
}
?>