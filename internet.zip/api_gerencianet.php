<?php

function limpar2($valor){
    $valor = trim($valor);
    $valor = str_replace("<", "", $valor);
    $valor = str_replace(">", "", $valor);
    $valor = str_replace(".", "", $valor);
    $valor = str_replace(",", "", $valor);
    $valor = str_replace("-", "", $valor);
    $valor = str_replace("/", "", $valor);
    $valor = str_replace("(", "", $valor);
    $valor = str_replace(")", "", $valor);
    $valor = str_replace(" ", "", $valor);
    $valor = str_replace("_", "", $valor);
    $valor = str_replace("@", "", $valor);
    return $valor;
};


define("URL_API","https://api.gerencianet.com.br");
################################################# GERA BOLETO GNET ################################################
function gerar($id){
    include('conexao2.php');
    include_once("functions.php");
    $query = mysqli_query($conn,"SELECT * FROM compra_creditos WHERE id='$id'");
    $r = mysqli_fetch_array($query);
    $valor = Intval(limpar2($r['valor'])); //valor do boleto
    $cliente = $r['nome'];
    $cpf = $r['cpf'];
    $vencimento = date('Y-m-d',strtotime('+2 day', strtotime(date('Y-m-d'))));
    $urlAtual = UrlAtual();
    //alterar para o site do cliente se tiver dentro de pasta colocar sit/pasta
    $urldocliente = "https://panell.mkssh.site";
    $urlnotificacao = $urldocliente."/notificacao.php?customid=";
    $customid = $r['customid']; 

    //tratar e enviar dados
    $token = AcessoToken();
        $url = URL_API.'/v1/charge/one-step';
        $curl = curl_init();
        $item_1 = [
            "name" => "Compra de creditos",
            "amount" => 1,
            "value" => $valor,
        ];
        $items = [
            $item_1
        ];
        $metadata = array(
        "custom_id" => $customid,
        "notification_url"=> $urlnotificacao.$customid,
        );
        $customer = [
            "name" => $cliente,
            "cpf" => $cpf,
        ];
        $bankingBillet = [
            "expire_at" => $vencimento, // data de vencimento do titulo
            "customer" => $customer,
        ];
        $payment = [
            "banking_billet" => $bankingBillet, // forma de pagamento (banking_billet = boleto)
        ];
        $body = [
            "items" => $items,
            "metadata" =>$metadata,
            "payment" => $payment,
        ];
        curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($body),
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer $token",
            "Content-Type: application/json"
            ),
        ));    
        $response = curl_exec($curl);    
        curl_close($curl);
        $json = json_decode($response,true);    
        //print_r($response);
        if($json['code'] == 200){ 
            //status
            switch ($json['data']['status']) {
            case 'waiting':
                $situacao = 'PENDENTE';
                break;
            case 'unpaid':
                $situacao = 'PENDENTE';
                break;
            case 'paid':
                $situacao = 'RECEIBIDO';
                break;
            case 'settled':
                $situacao = 'RECEBIDO';
                break;
            case 'canceled':
                $situacao = 'CANCELADO';
            break;
            }     
            //$barcode = $json['data']['barcode'];
            //$qrcode_image = AspasBanco($json['data']['pix']['qrcode_image']);
            $link = $json['data']['link'];
            $chargeid = $json['data']['charge_id'];
            mysqli_query($conn,"update compra_creditos set chargeid='$chargeid',link='$link',vencimento='$vencimento' WHERE id='$id'")
            or die (mysqli_error($conn));
            
            echo "<script>history.back();</script>"; 

        }else{ 
            echo '<br/> Erro codigo: '.$json['code'].', <br />erro: '.$json['error'].'<br /> Descricao: '.$json['error_description'];
            //print_r($response);
        }
}
//echo gerarCobrancaGerencianet(15);
?>