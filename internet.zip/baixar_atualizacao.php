<?php
include("conexao.php");
include_once("functions.php");

$url = 'https://localhost/unyserve1.0.zip';
$arquivo = 'unyserve1.0.zip';

$opcoes = array(
    CURLOPT_FILE => fopen($arquivo, 'w'),
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_URL => $url
);

$ch = curl_init();
curl_setopt_array($ch, $opcoes);
curl_exec($ch);
curl_close($ch);

if (file_exists($arquivo)) {
    $zip = zip_open($arquivo);
    if ($zip) {
        $extrair_na_pasta = '../'; // extrair na raiz da hospedagem
        while ($entrada = zip_read($zip)) {
            $caminho = $extrair_na_pasta . zip_entry_name($entrada);
            if (zip_entry_open($zip, $entrada, "r")) {
                $conteudo = zip_entry_read($entrada, zip_entry_filesize($entrada));
                if (!is_dir(dirname($caminho))) {
                    mkdir(dirname($caminho), 0755, true); // cria diret贸rios caso n茫o existam
                }
                file_put_contents($caminho, $conteudo); // extrai o arquivo
                zip_entry_close($entrada);
            }
        }
        zip_close($zip);
        unlink($arquivo); // apaga o arquivo zip ap贸s extrair
        header("Location: atualizar/index1.php");
        exit;
    } else {
        header("Location: index1.php?erro_descompactar");
        exit;
    }
} else {
    header("Location: index1.php?download_falha");
    exit;
}
?>