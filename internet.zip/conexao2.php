<?php
//conexão com banco: servidor,usuario,senha,banco
$pass = 'suasenha';
$conn = mysqli_connect("localhost","root","","net");
/* check connection */
if (mysqli_connect_errno()) {
    //printf('Falha na conexão: %s\n', mysqli_connect_error());
    //exit();
}else{
$conn->set_charset("utf8");
    //print('Conectado com sucesso!');
    //printf("inicio caracter set: %s\n", $conexao->character_set_name());
}
?>