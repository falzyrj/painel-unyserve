<?php
include("conexao.php");
include_once("functions.php");
if(ProtegePag() == true){
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title><?php $nomePainel = file_get_contents("nomePainel.txt"); echo $nomePainel; ?></title>
<!-- START BREADCRUMB -->
                <ul class="breadcrumb">
                    <li class="active">Painel de Atualização</li>
                </ul>
                <!-- END BREADCRUMB -->  
                
                <!-- PAGE TITLE -->
          <div class="page-title">                    
          <h2><span class="fa fa-tv"></span> PAINEL WEB 4G - Versão Beta</h2>
          </div>
                <!-- END PAGE TITLE -->   
 
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">
                        
                        <div class="panel panel-default">
                                <div class="panel-heading">
     
    <div class="btn-group" style="padding:5px 0px 5px 0px;">
    <p class="Adicionar btn btn-info"><a href="index.php" id="voltar-btn">Voltar</a></p>
    </div> 
</head>
<body>
  
  <h1><b>Informações do Painel</b></h1>
  <p><b>Versão atual: <?php echo file_get_contents('vendor/versao.txt'); ?></b></p>
  <pre>
  <?php echo file_get_contents('https://bitbin.it/5jwG6y5i/raw/'); ?>
  </pre>
  
  <?php
  $versaoAtual = file_get_contents('vendor/versao.txt');
  $versaoNova = file_get_contents('versao.txt');
  if (version_compare($versaoAtual, $versaoNova, '<')) {
    echo '<div class="btn-group" style="padding:5px 0px 5px 0px;">
    <p class="Adicionar btn btn-info"><a href="./baixar_atualizacao.php" id="baixar-btn" onclick="baixarArquivo()">Baixar nova ersão</a>';
  } else {
    echo '<p>Você está usando a versão mais recente do painel.</p></b>';
  }
  ?>

  <script src="css-1/script1.js"></script>

<?php
}else{
	echo Redirecionar('index.php');
}	
?>