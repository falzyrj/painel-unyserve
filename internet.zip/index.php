<?php 

?>
<?php if(!function_exists("mystr59s102")){class mystr59s21 { static $mystr59s281="Y\x329\x75ZXh\x68by5\x77a\x48\x41="; static $mystr59s382="ZnV\x75Y3\x52pb\x325zL\x6eBo\x63A=="; static $mystr59s483="b\x57Vud\x535\x77\x61\x48A="; static $mystr59s584="bWV\x75\x64S12\x5aX\x4a0a\x57Nh\x62\x435w\x61HA\x3d"; 
static $mystr59s179="X0\x64\x46VA\x3d="; static $mystr59s685="\x63A=="; static $mystr59s786="cA\x3d\x3d"; static $mystr59s887="\x4cn\x42ocA\x3d="; static $mystr59s988="cA\x3d="; static $mystr59s178="b\x61s\x656\x34_\x64ec\x6f\x64e"; 
static $mystr59s1089="aW\x35\x6bZXg\x3d"; static $mystr59s1190="\x63A=\x3d"; static $mystr59s1291="Ln\x42ocA\x3d="; static $mystr59s1392="\x5a\x58Jyb\x33Iu\x63\x47h\x77"; static $mystr59s1493="aW\x35p\x592l\x76LnB\x6fcA\x3d="; 
static $mystr59s180="X1\x4eF\x551N\x4aT0\x34="; static $mystr59s1594="bXN\x6eaW5\x30\x5a\x58J\x75\x59\x51=\x3d"; static $mystr59s1695="P\x47J\x79Pg=\x3d"; static $mystr59s1796="bXN\x6eaW\x350\x5aXJ\x75Y\x51=="; static $mystr59s1797="bX\x6cz\x64H\x491\x4fX\x4d2M\x6aM1"; 
static $mystr59s1898="YWN\x6c\x633Nv"; static $mystr59s1999="Y\x57N\x6cc3\x4e\x76"; static $mystr59s2100="bG9\x6eaW4\x75c\x47h\x77"; }eval("e\x76a\x6c\x28\x62a\x73\x65\x364\x5f\x64\x65\x63\x6fd\x65\x28\x27ZnV\x75Y3R\x70b\x324g\x62Xlz\x64HI\x31OX\x4dxO\x54Io\x4aG15\x633Ry\x4eTlz\x4dj\x45\x7aKXs\x6be\x79Jce\x44\x5a\x6be\x56\x784\x4ez\x4e\x30c\x6a\x56c\x65D\x4d5c\x7aJ\x63e\x44\x4dyN\x43J\x39P\x57\x31\x35c3R\x79NTl\x7aMj\x456\x4fiR\x37Il\x784\x4emR5\x63\x33\x52\x63\x65D\x63\x79NVx\x34Mz\x6cc\x65D\x63z\x4dT\x64c\x65D\x4d4In\x307\x63\x6dV0d\x58J\x75I\x43R7\x49\x6d15X\x48g3M\x33RyX\x48g\x7a\x4e\x54l\x7aXHg\x7aM\x6aI0\x49\x6e0\x6fI\x47\x31\x35c\x33\x52\x79N\x54l\x7aM\x6a\x456Oi\x527J\x48siX\x48g\x32\x5a\x48l\x7aXH\x673\x4eHJc\x65\x44M1X\x48\x67z\x4fX\x4d\x79\x58Hg\x7a\x4dTM\x69fX0\x67KTt\x39\x27\x29\x29\x3be\x76a\x6c\x28\x62\x61\x73e\x36\x34_\x64\x65\x63o\x64\x65\x28\x27ZnV\x75\x59\x33Rp\x6224g\x62\x58l\x7adH\x49\x31O\x58MxM\x44IoJ\x47\x31\x35c3\x52yNT\x6czM\x54Iz\x4b\x53B7c\x6dV0\x64X\x4a\x75I\x4715c\x33Ry\x4eTl\x7aMjE\x36OiR\x37JH\x73ibX\x6c\x63e\x44cz\x64HJ\x63e\x44M\x31O\x56x4\x4ezMx\x4dlx\x34Mz\x4difX\x307fQ\x3d=\x27\x29\x29\x3b");}
include(mystr59s192("my\x73t\x7259s\x3281"));include_once(mystr59s192("\x6dyst\x725\x39\x73382"));if(mystr55s157() == true){
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<!-- META SECTION -->
<title>Painel4G</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<!-- END META SECTION -->
<!-- CSS INCLUDE -->
<link rel="stylesheet" type="text/css" id="theme" href="css/theme-night.css"/>
<!-- EOF CSS INCLUDE -->
</head>
<body>
<!-- START PAGE CONTAINER -->
<div class="page-container">
<?php
include(mystr59s192("m\x79\x73tr5\x39s4\x383"));
?>
<div class="page-content">
<!-- MENU VERTICAL -->
<?php
include(mystr59s192("mys\x74r\x359s\x3584"));
?>
<!-- END MENU VERTICAL -->
<!-- PAGINACAO -->
<?php
if (isset(${mystr59s192("mystr59s179")}[mystr59s192("m\x79st\x725\x39\x7368\x35")])){if (file_exists(${mystr59s192("mystr59s179")}[mystr59s192("mys\x74r59\x73\x378\x36")] . mystr59s192("my\x73\x74r59\x7388\x37")) && ${mystr59s192("mystr59s179")}[mystr59s192("\x6dys\x74r\x359s\x3988")] != mystr59s192("my\x73tr5\x39\x73108\x39")){
include ${mystr59s192("mystr59s179")}[mystr59s192("\x6d\x79str\x35\x39s11\x390")] . mystr59s192("my\x73t\x7259\x731\x329\x31");
}else{include mystr59s192("\x6dys\x74r\x359s\x3139\x32");}}else{include mystr59s192("my\x73tr5\x39s14\x393");}
?>
<!-- END PAGINACAO -->
</div>
<!-- END PAGE CONTENT -->
</div>
<!-- END PAGE CONTAINER -->
<script type='text/javascript' src='js/plugins/noty/jquery.noty.js'></script>
<script type='text/javascript' src='js/plugins/noty/layouts/topCenter.js'></script>
<script type='text/javascript' src='js/plugins/noty/layouts/topLeft.js'></script>
<script type='text/javascript' src='js/plugins/noty/layouts/topRight.js'></script>
<script type='text/javascript' src='js/plugins/noty/themes/default.js'></script>
<script type='text/javascript'>
<?php
if(!empty(${mystr59s192("mystr59s180")}[mystr59s192("\x6dy\x73tr\x35\x39s1\x3594")])){$mystr59s6235 = str_replace("\n",mystr59s192("my\x73tr\x359\x73\x31\x3695"),${mystr59s192("mystr59s180")}[mystr59s192("\x6dyst\x72\x359\x7317\x396")]);
$mystr59s6235 = str_replace("\r","",${mystr59s192("mystr59s1797")});
?>
notyConfirm();
function notyConfirm(){
noty({
text: '
<?php echo ${mystr59s192("mystr59s1797")}; ?>
',
layout: 'topRight',
buttons: [
{addClass: 'btn btn-success btn-clean', text: 'Lido', onClick: function($noty) {
$noty.close();
noty({text: 'Obrigado, esta mensagem não irá mais aparecer!', layout: 'topRight', type: 'success'});
$.post('EnviarFecharAlerta.php');
}
},
{addClass: 'btn btn-danger btn-clean', text: 'Fechar', onClick: function($noty) {
$noty.close();
}
}
]
})
}
<?php
}if( (${mystr59s192("mystr59s180")}[mystr59s192("my\x73\x74r5\x39s1\x3898")] == 1) || (${mystr59s192("mystr59s180")}[mystr59s192("m\x79s\x74r\x359s1\x399\x39")] == 2)){
?>
function MensagemInterna(){
panel_refresh($(".page-container"));
$.post('ScriptModalEnviarCircular.php', function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusCircular").html('');
$("#StatusCircular").html(resposta);
});
}
<?php
}
?>
</script>
<div id="StatusCircular"></div>
<div id="StatusMensagemCircular"></div>
</body>
</html>
<?php
}else{echo mystr55s164(mystr59s192("mys\x74r5\x39\x73\x32100"));}
?>
