<?php 
?>    
<?php if(!function_exists("mystr11s54")){class mystr11s21 { static $mystr11s280="Y29\x75Z\x58hhb\x795wa\x48\x41="; static $mystr11s381="Z\x6eVuY\x33R\x70\x6225\x7aL\x6eBo\x63A\x3d="; static $mystr11s179="X\x31NF\x551\x4e\x4aT\x304\x3d"; static $mystr11s482="YW\x4el\x633Nv"; static $mystr11s583="\x59WN\x6cc3\x4ev"; 
static $mystr11s685="aW\x51="; static $mystr11s786="\x55\x30VMR\x55N\x55ICo\x67Rl\x4aPTS\x42sb2\x64\x70\x62i\x42X\x53\x45V\x53R\x53Bp\x5a\x469j\x59WQ\x67PS\x41\x36aWR\x66Y\x32F\x6bI\x45FOR\x43B\x68Y2V\x7ac28\x67\x50SA\x36YW\x4el\x633Nv"; 
static $mystr11s889="Om\x6ckX\x32Nh\x5aA\x3d="; static $mystr11s787="b\x58l\x7ad\x48I\x78M\x58M\x79\x4d\x6a\x4d3"; static $mystr11s990="Om\x46\x6a\x5aXNz\x62w\x3d="; static $mystr11s584="b\x58\x6c\x7adH\x49\x78\x4d\x58\x4dy\x4d\x6aM\x31"; 
static $mystr11s991="\x62X\x6czd\x48\x49xM\x58\x4dy\x4djM\x34"; static $mystr11s1092="\x61WQ="; static $mystr11s1193="bG9\x6ea\x574="; static $mystr11s1294="U\x30VM\x52UN\x55IGl\x6ab2\x35lI\x45Z\x53T00\x67\x63\x32\x56yd\x6dlk\x623I\x67V0h\x46Uk\x55g\x62m9\x74ZSA\x39IDp\x75\x6221l"; 
static $mystr11s1395="Om5\x76bWU\x3d"; static $mystr11s1496="b\x33\x42lcm\x46k\x623\x4ah"; static $mystr11s1598="U0V\x4dR\x55NU\x49Gl\x74YWd\x6cb\x53BG\x55k\x39NI\x47l\x6ab\x325lX\x33Bl\x63\x6dZpb\x43B\x58SE\x56S\x52SBp\x5aCA9\x49Dp\x70ZA\x3d="; 
static $mystr11s1599="bX\x6cz\x64H\x49x\x4dXM\x32\x4djM\x34"; static $mystr11s1700="Oml\x6b"; static $mystr11s1801="a\x57N\x76bm\x55="; static $mystr11s1903="aW1\x68Z2\x56t"; static $mystr11s2004="P\x47ltZ\x79\x42zc\x6d\x4d9"; 
static $mystr11s2105="aGV\x70\x5a2h0\x50Q=="; static $mystr11s2206="d\x32lk\x64Gg\x39"; static $mystr11s2307="\x550VM\x52\x55N\x55I\x47x\x76Z\x32l\x75IE\x5a\x53T\x30\x30\x67b\x479n\x61W\x34\x67V\x30\x68\x46Uk\x55ga\x57Qg\x50\x53A\x36\x61WQ\x3d"; 
static $mystr11s2308="\x62Xl\x7a\x64\x48I\x78\x4d\x58M\x32M\x6a\x51\x79"; static $mystr11s2409="\x4fm\x6ck"; static $mystr11s2510="aW\x52fY\x32F\x6b"; static $mystr11s2611="\x5aC9t\x4c\x31\x6b="; static $mystr11s2712="ZX\x68w\x61XJ\x6cZ\x47F0\x5aQ=\x3d"; 
static $mystr11s2814="\x5aC9\x74L\x31k="; static $mystr11s2916="ZX\x68waX\x4a\x6cZGF\x30ZQ\x3d="; static $mystr11s2713="bX\x6czd\x48\x49xM\x58M\x32M\x6aQ\x30"; static $mystr11s3019="Jm\x35i\x633A\x37\x4am5\x69\x633\x417PH\x4ewY\x574g\x592xh\x63\x33M\x39"; 
static $mystr11s3120="\x62GF\x69\x5aW\x77gbG\x46\x69ZWw\x74Z\x47FuZ\x32Vy"; static $mystr11s3221="ZGF\x30\x59S10\x622d\x6eb\x47U9"; static $mystr11s3322="Z\x47F\x30YS\x31wbG\x46jZW\x31lbn\x519"; static $mystr11s3423="dGl\x30bG\x559"; 
static $mystr11s3524="Z\x47F0Y\x53\x31v\x63mln\x61W5\x68bC\x310\x61X\x52s\x5aT0\x3d"; static $mystr11s3625="Jm5\x69\x633A\x37Jm\x35i\x633\x41\x37PHN\x77Y\x574gY\x32x\x68c3M\x39"; static $mystr11s3726="b\x47F\x69Z\x57wg\x62GF\x69Z\x57w\x74c\x33Vj\x59\x32\x56zc\x77\x3d="; 
static $mystr11s3827="ZGF\x30YS1\x30\x622dn\x62\x47\x559"; static $mystr11s3928="Z\x47\x460YS\x31\x77bG\x46\x6aZ\x571\x6cbnQ\x39"; static $mystr11s4029="dGl\x30b\x47U9"; static $mystr11s4130="Z\x47F0\x59\x531v\x63ml\x6eaW5\x68b\x431\x30\x61XR\x73\x5aT0\x3d"; 
static $mystr11s4231="DQo\x67ICA\x67ICA\x67ICA\x67ICA\x67IC\x41gI\x43AgI\x43\x41gIC\x41gIC\x41gI\x43Ag\x49\x43\x41gI\x43AgI\x43A\x67PHR\x79\x50g\x30KC\x51\x6bJ\x43Q\x6bJC\x51kJC\x51k8\x64GQ+\x50G\x6cu\x63\x48V\x30IHR\x35cGU\x39"; 
static $mystr11s4332="Y2\x78\x68c3\x4d\x39"; static $mystr11s4433="\x62mF\x74Z\x54\x30="; static $mystr11s4534="aW\x519"; static $mystr11s4635="\x64\x6dFs\x64WU\x39"; static $mystr11s4736="aW\x51="; static $mystr11s4837="\x5425\x6a\x62\x47lj\x61z0="; 
static $mystr11s4938="IC\x41\x67ICA\x67I\x43\x41gIC\x41gIC\x41g\x49CAg\x49CA\x67ICA\x67ICA\x67I\x43AgI\x43\x41gIC\x41gIC\x41gC\x54x0Z\x444="; static $mystr11s5039="\x62m\x39t\x5aQ=\x3d"; static $mystr11s5140="PC\x390Z\x44\x34NC\x69\x41gI\x43AgI\x43A\x67\x49C\x41g\x49CA\x67IC\x41gIC\x41gI\x43\x41gI\x43AgI\x43\x41gI\x43Ag\x49CAg\x49CA\x67IC\x41\x4aP\x48Rk\x50\x67=\x3d"; 
static $mystr11s5241="\x62G9n\x61W4="; static $mystr11s5342="PC\x39\x30ZD\x34\x4eCiA\x67I\x43Ag\x49C\x41g\x49\x43AgI\x43\x41\x67ICA\x67ICA\x67I\x43A\x67\x49\x43A\x67ICA\x67I\x43\x41g\x49C\x41gI\x43A\x67I\x43AJP\x48R\x6bP\x67\x3d="; 
static $mystr11s5443="c\x32V\x75a\x47E\x3d"; static $mystr11s5544="PC9\x30ZD4\x3d"; static $mystr11s5645="P\x48\x52kP\x67=="; static $mystr11s5746="PC9\x30Z\x444\x3d"; static $mystr11s2917="bX\x6cz\x64H\x49\x78MX\x4d2M\x6aQ\x32"; 
static $mystr11s2918="b\x58l\x7a\x64\x48\x49x\x4dXM\x32Mj\x51\x31"; static $mystr11s5848="P\x48\x52k\x50jx\x7a\x63G\x46uIG\x4esYX\x4ez\x50Q=\x3d"; static $mystr11s5949="bGF\x69ZW\x77\x67bGF\x69ZW\x77t\x5a\x47F\x75Z\x32Vy"; 
static $mystr11s6050="Z\x47F0Y\x5310b\x32\x64nbG\x55\x39"; static $mystr11s6151="ZGF\x30\x59S1\x77b\x47F\x6a\x5a\x571\x6cbn\x519"; static $mystr11s6252="d\x47l\x30b\x47U\x39"; static $mystr11s6353="\x5aGF\x30YS1\x76cm\x6cn\x61W5h\x62\x431\x30aXR\x73Z\x540="; 
static $mystr11s6454="PC\x390ZD\x34="; static $mystr11s6555="\x50H\x52k\x50\x6ax\x7acG\x46uIG\x4es\x59\x58\x4e\x7a\x50Q=\x3d"; static $mystr11s6656="bG\x46iZ\x57\x77g\x62GF\x69Z\x57w\x74c3V\x6aY\x32Vz\x63w=="; static $mystr11s6757="\x5aGF0\x59S10\x622d\x6e\x62G\x559"; 
static $mystr11s6858="ZG\x46\x30Y\x531wb\x47Fj\x5a\x571\x6cbnQ\x39"; static $mystr11s6959="\x64G\x6c\x30bGU\x39"; static $mystr11s7060="ZG\x460YS\x31vcm\x6c\x6eaW\x35hbC\x31\x30aXR\x73ZT0\x3d"; static $mystr11s7161="\x50\x4390\x5aD\x34="; 
static $mystr11s7262="PH\x52k\x50g\x3d="; static $mystr11s1497="bX\x6cz\x64\x48I\x78M\x58M\x32\x4djM\x33"; static $mystr11s7363="bG9\x6eaW4\x3d"; static $mystr11s7464="P\x43\x390\x5aD\x34="; static $mystr11s7565="PHR\x6bPj\x78\x6ba\x58\x59\x67Y2x\x68c3M\x39"; 
static $mystr11s7666="P\x47EgY\x32xhc\x33M9"; static $mystr11s7767="bGF\x69\x5aW\x77tZG\x56\x6dYXV\x73dA\x3d="; static $mystr11s7868="Z\x47F\x30\x59\x5310\x622d\x6e\x62G\x559"; static $mystr11s7969="ZGF\x30YS\x31wbG\x46j\x5a\x571l\x62nQ\x39"; 
static $mystr11s8070="d\x47l0b\x47U9"; static $mystr11s8171="ZGF\x30Y\x531\x76cml\x6eaW5\x68b\x4310\x61XRs\x5aT\x30="; static $mystr11s8272="T\x325j\x62Glj\x61z0="; static $mystr11s8373="aWQ\x3d"; static $mystr11s8474="Jy\x6b\x3d"; 
static $mystr11s8575="\x592\x78\x68c3\x4d9"; static $mystr11s8676="Zm\x45tc\x47VuY\x32ls"; static $mystr11s2815="b\x58lz\x64HI\x78MX\x4d\x32Mj\x4d1"; static $mystr11s8777="Ym\x78v\x63\x58V\x6c\x59W\x52v"; static $mystr11s8878="\x55w=\x3d"; 
static $mystr11s8979="PH\x4ewYW\x34ga\x57Q9"; static $mystr11s9080="\x61\x57Q\x3d"; static $mystr11s9181="Y2\x78hc\x33M9"; static $mystr11s9282="\x62GFi\x5aWw\x67b\x47F\x69ZWw\x74c3V\x6aY2V\x7acw=\x3d"; static $mystr11s9383="ZG\x46\x30Y\x5310\x622dn\x62GU\x39"; 
static $mystr11s9484="\x5aG\x46\x30YS1\x77\x62GF\x6aZW1\x6cbnQ\x39"; static $mystr11s9585="dGl\x30bG\x559"; static $mystr11s9686="Z\x47F0Y\x531\x76\x63\x6dl\x6eaW\x35hbC\x310\x61X\x52sZ\x540="; static $mystr11s9787="T25\x6ab\x47\x6cj\x61z0\x3d"; 
static $mystr11s9888="a\x57Q="; static $mystr11s178="b\x61s\x6564\x5fd\x65\x63\x6fd\x65"; static $mystr11s9989="J\x79\x77\x67\x4a1N0\x59XR1\x630J\x73b0R\x6ccw=\x3d"; static $mystr11s10090="aWQ\x3d"; static $mystr11s10191="J\x79k="; 
static $mystr11s10292="Y2x\x68\x633\x4d9"; static $mystr11s10393="Z\x6dE\x74\x64W5s\x622Nr\x4cW\x46s\x64A=="; static $mystr11s10494="PHN\x77YW\x34ga\x57\x51\x39"; static $mystr11s10595="aW\x51="; static $mystr11s10696="\x59\x32\x78hc\x33\x4d9"; 
static $mystr11s10797="bG\x46i\x5aWwg\x62GF\x69ZW\x77tZG\x46\x75Z2V\x79"; static $mystr11s10898="\x5aGF0\x59S1\x30b2d\x6e\x62GU\x39"; static $mystr11s10999="ZG\x46\x30\x59\x531\x77bG\x46jZW\x31lbn\x51\x39"; static $mystr11s11100="\x64G\x6c0bG\x559"; 
static $mystr11s11201="ZG\x460Y\x531v\x63ml\x6ea\x575\x68bC1\x30\x61X\x52s\x5aT\x30="; static $mystr11s11302="\x5425j\x62G\x6cjaz\x30="; static $mystr11s11403="aW\x51="; static $mystr11s11504="\x4ayw\x67J1\x4e\x30YX\x521c0\x4a\x73b0\x52lc\x77=\x3d"; 
static $mystr11s11605="aW\x51="; static $mystr11s11706="J\x79\x6b\x3d"; static $mystr11s11807="Y2x\x68c\x33M9"; static $mystr11s11908="Z\x6dEt\x62G9\x6a\x61w=\x3d"; static $mystr11s12009="PHN\x77\x59\x574\x67aWQ\x39"; static $mystr11s12110="a\x57Q\x3d"; 
static $mystr11s12211="Y2x\x68c3\x4d9"; static $mystr11s12312="b\x47FiZ\x57w\x67bGF\x69Z\x57wtZ\x47FuZ\x32Vy"; static $mystr11s12413="ZGF\x30\x59\x53\x310b2\x64nbG\x559"; static $mystr11s12514="Z\x47F\x30YS\x31w\x62\x47Fj\x5aW1\x6cbn\x519"; 
static $mystr11s12615="dGl\x30bGU\x39"; static $mystr11s12716="Z\x47\x46\x30YS1\x76\x63m\x6cna\x575h\x62\x4310a\x58R\x73ZT0\x3d"; static $mystr11s12817="\x622\x35jbG\x6c\x6aaz\x30="; static $mystr11s12918="aW\x51="; static $mystr11s13019="\x4aywg\x4a\x31N\x30Y\x58\x521c0\x52\x6cbG\x560YX\x49="; 
static $mystr11s13120="aW\x51\x3d"; static $mystr11s13221="\x4ayk\x37"; static $mystr11s13322="Y2\x78hc3\x4d9"; static $mystr11s13423="\x5a\x6d\x45t\x64H\x4ahc\x32gt\x62\x77\x3d="; static $mystr11s13524="PG\x45g\x592x\x68c3\x4d9"; 
static $mystr11s13625="\x62GF\x69Z\x57wt\x61\x575\x6dbw\x3d\x3d"; static $mystr11s13726="ZG\x46\x30\x59S10\x622d\x6e\x62\x47U9"; static $mystr11s13827="\x5aG\x460YS\x31\x77\x62\x47Fj\x5a\x571\x6cbnQ\x39"; static $mystr11s13928="dGl\x30bG\x559"; 
static $mystr11s14029="Z\x47F0Y\x53\x31vc\x6d\x6cnaW\x35h\x62\x4310\x61XR\x73ZT0\x3d"; static $mystr11s14130="VXN\x31\x776Fy\x61W8/"; static $mystr11s14231="b\x325\x6abG\x6c\x6aaz0\x3d"; static $mystr11s14332="aWQ\x3d"; static $mystr11s14433="J\x79\x77gJw\x3d="; 
static $mystr11s14534="bG9\x6ea\x574="; static $mystr11s14635="J\x79k7"; static $mystr11s14736="Y2x\x68c3M\x39"; static $mystr11s14837="Z\x6d\x45tdX\x4el\x63g=\x3d"; static $mystr11s14938="PC9\x6baX\x59+\x44Q\x6f\x4aCQ\x6bJ\x43Qk\x4aCQk\x4aCQ0\x4bCQ\x6b\x4aCQk\x4aCQk\x4aCQk\x38L3R\x6bPg\x3d\x3d"; 
static $mystr11s15039="PC\x390cj\x34\x3d"; static $mystr11s15140="\x61\x575kZ\x58guc\x47hw"; static $mystr11s15241="bG\x39n\x61W4\x75\x63G\x68w"; }eval("\x65v\x61\x6c\x28b\x61\x73\x65\x364\x5f\x64e\x63o\x64\x65\x28\x27Z\x6eVuY\x33R\x70b24\x67bXl\x7a\x64HIx\x4dX\x4d5Ni\x67\x6b\x62Xl\x7ad\x48Ix\x4dXM\x78MTc\x70e\x79R7I\x6d1\x35X\x48g3\x4d\x33Ry\x58Hg\x7aM\x54Fz\x4dVx4\x4d\x7aI4I\x6e0\x39bX\x6czd\x48IxM\x58My\x4d\x54o\x36JH\x73ib\x58l\x7aX\x48g\x33NFx\x34N\x7aJc\x65DMx\x4dVx\x34NzM\x78N1\x784\x4dz\x67ifT\x74yZ\x58R1\x63\x6d\x34\x67J\x48si\x62Vx\x34\x4e\x7alzd\x48J\x63e\x44Mx\x4dVx\x34NzN\x63eDM\x78XH\x67\x7a\x4djg\x69f\x53ggb\x58\x6czdH\x49xMX\x4d\x79MTo\x36JH\x73key\x4at\x65Vx\x34N\x7aN\x30clx\x34\x4dzE\x78X\x48g3M\x7aFce\x44MxN\x79\x4a\x39f\x53Ap\x4f3\x30=\x27\x29\x29\x3b\x65v\x61\x6c\x28b\x61\x73e\x36\x34\x5fd\x65\x63o\x64e\x28\x27Z\x6e\x56\x75Y3R\x70b2\x34gb\x58lz\x64H\x49x\x4dXM\x31\x4eCgk\x62\x58lzd\x48I\x78M\x58\x4d\x33NS\x6b\x67\x65\x33\x4a\x6cdH\x56y\x62i\x42t\x65XN0\x63jE\x78\x63zI\x78O\x6aok\x65y\x527I\x6d1ce\x44c\x35\x633R\x63eD\x63yXH\x67zM\x54FzX\x48gzN\x7aU\x69f\x5807\x66Q==\x27\x29\x29\x3b");}
include(mystr11s96("\x6dyst\x721\x31s28\x30"));include_once(mystr11s96("my\x73\x74\x72\x31\x31s3\x38\x31"));if(mystr55s157() == true){
global $mystr9s2237;if( (${mystr11s96("mystr11s179")}[mystr11s96("\x6dy\x73tr1\x31s\x3482")] == 1) || (${mystr11s96("mystr11s179")}[mystr11s96("my\x73tr1\x31s5\x383")] == 2)){
$mystr11s2235 = ${mystr11s96("mystr11s179")}[mystr11s96("\x6d\x79s\x74r11\x736\x385")];$mystr11s2236 = 4;$mystr11s2237 = mystr11s96("my\x73t\x7211s\x3786");
$mystr11s2237 = $mystr9s2237->mystrz1115($mystr11s2237);$mystr11s2237->bindParam(mystr11s96("\x6dys\x74r1\x31\x738\x38\x39"), $mystr11s2235, PDO::PARAM_INT);
${mystr11s96("mystr11s787")}->bindParam(mystr11s96("my\x73tr1\x31s\x399\x30"), $mystr11s2236, PDO::PARAM_INT);${mystr11s96("mystr11s787")}->execute();
$mystr11s2238 = mystr55s189(${mystr11s96("mystr11s584")});$mystr11s2239 = mystr55s190($mystr11s2235);$mystr11s2240 = $mystr11s2238 - $mystr11s2239;
?>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
<li class="active">Criar login de teste no servidor</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">
<h2><span class="fa fa-user"></span>&#160;Criar teste</h2>
</div>
<!-- END PAGE TITLE -->
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<?php
if( ($mystr11s2240 > 0) || (${mystr11s96("mystr11s991")} == 0) ){
?>
<div class="btn-group" style="padding:5px 0px 5px 0px; float:left;">
<button type="button" class="Adicionar btn btn-info active">Adicionar</button>
&nbsp;&nbsp;
</div>
<?php
}
?>
<div class="ExibirRevs col-md-2">
<div class="form-group" style="padding:5px 0px 5px 0px;">
<select class="form-control select" id="Exibir" name="Exibir">
<?php echo mystr55s172(${mystr11s96("mystr11s179")}[mystr11s96("\x6dys\x74r\x311\x73109\x32")], ${mystr11s96("mystr11s179")}[mystr11s96("my\x73tr1\x31s11\x393")]); ?>
</select>
</div>
</div>
<div class="btn-group" style="padding:5px 0px 5px 0px;">
<button type="button" class="btn btn-default"><span value="Todos" id="StatusE">Status</span></button>
<button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="caret"></span></button>
<ul class="dropdown-menu" role="menu">
<li><a status="Todos" class="ExibirStatus pointer">Todos</a></li>
<li><a status="Ativos" class="ExibirStatus pointer">Ativos</a></li>
<li><a status="Inativos" class="ExibirStatus pointer">Esgotados</a></li>
</ul>
&nbsp;&nbsp;
</div>
<div class="ExibirAllOpcoes btn-group" style="padding:5px 0px 5px 0px;"></div>
<ul class="panel-controls">
<li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="fa fa-cog"></span></a>
<ul class="dropdown-menu">
<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span> Esconder</a></li>
<li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span> Atualizar</a></li>
</ul>
</li>
</ul>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="table datatable">
<thead>
<tr>
<th width="5"><input type="checkbox" name="TotalAll" id="TotalAll" class="MarcarAll" OnClick="marcardesmarcar();"></th>
<th>Nome</th>
<th>Usuário</th>
<th>Senha</th>
<th>Servidor</th>
<th>Expira em</th>
<th>Criador Por</th>
<th>Opções</th>
</tr>
</thead>
<tbody>
<?php
while($mystr11s6235 = $mystr11s2237->fetch()){$mystr11s6236 = mystr11s96("\x6dy\x73tr\x311s1\x3294");$mystr11s6236 = $mystr9s2237->mystrz1115($mystr11s6236);
$mystr11s6236->bindParam(mystr11s96("my\x73tr\x311\x73139\x35"), $mystr11s6235[mystr11s96("\x6dyst\x72\x31\x31s1\x3496")], PDO::PARAM_STR);
$mystr11s6236->execute();$mystr11s6237 = $mystr11s6236->fetch();$mystr11s6238 = mystr11s96("my\x73\x74r11\x731\x35\x398");
$mystr11s6238 = $mystr9s2237->mystrz1115(${mystr11s96("mystr11s1599")});${mystr11s96("mystr11s1599")}->bindParam(mystr11s96("\x6dy\x73t\x7211\x7317\x300"), $mystr11s6237[mystr11s96("my\x73tr1\x31\x73180\x31")], PDO::PARAM_STR);
${mystr11s96("mystr11s1599")}->execute();$mystr11s6239 = $mystr11s6238->fetch();$mystr11s6240 = mystr55s191($mystr11s6239[mystr11s96("m\x79\x73tr1\x31\x731\x39\x303")]);
$mystr11s6241 = mystr11s96("mys\x74r\x311s\x320\x304")."\"".$mystr11s6240."\" ".mystr11s96("m\x79st\x721\x31s\x321\x305")."\"20\" ".mystr11s96("mys\x74r11\x73220\x36")."\"20\">";
$mystr11s6242 = mystr11s96("m\x79\x73tr\x311s2\x330\x37");$mystr11s6242 = $mystr9s2237->mystrz1115(${mystr11s96("mystr11s2308")});
$mystr11s6242->bindParam(mystr11s96("mys\x74r1\x31s\x32\x3409"), $mystr11s6235[mystr11s96("m\x79str\x31\x31s\x32\x351\x30")], PDO::PARAM_INT);
$mystr11s6242->execute();$mystr11s6237 = $mystr11s6242->fetch();$mystr11s6243 = date(mystr11s96("mys\x74\x7211s\x3261\x31"), $mystr11s6235[mystr11s96("m\x79s\x74r\x311s2\x37\x31\x32")]);
$mystr11s6244 = date(mystr11s96("mys\x74r1\x31\x73281\x34"));$mystr11s6245 = $mystr11s6235[mystr11s96("m\x79str\x311s2\x39\x31\x36")];
$mystr11s6246 = time();if( ($mystr11s6243 == ${mystr11s96("mystr11s2713")}) || ($mystr11s6243 != $mystr11s6244) && ($mystr11s6246 > $mystr11s6245) ){
$mystr11s6247 = mystr11s96("mys\x74r\x311s\x330\x319")."\"pointer ".mystr11s96("my\x73tr\x311\x7331\x320")."\" ".mystr11s96("\x6dyst\x7211s\x33221")."\"tooltip\" ".mystr11s96("my\x73\x74r1\x31\x73332\x32")."\"top\" ".mystr11s96("\x6dy\x73t\x721\x31s\x334\x323")."\"\" ".mystr11s96("my\x73tr\x31\x31s\x3352\x34")."\"Esgotado\">E</span>";
}else{$mystr11s6247 = mystr11s96("\x6d\x79str\x311s\x33\x36\x325")."\"pointer ".mystr11s96("my\x73t\x721\x31s37\x326")."\" ".mystr11s96("\x6dys\x74\x72\x31\x31s38\x327")."\"tooltip\" ".mystr11s96("my\x73tr1\x31s39\x328")."\"top\" ".mystr11s96("\x6d\x79st\x7211\x73402\x39")."\"\" ".mystr11s96("my\x73tr\x311\x73413\x30")."\"Ativado\">A</span>";
}
echo mystr11s96("m\x79str\x311s4\x3231")."\"checkbox\" ".mystr11s96("mys\x74\x7211\x73\x343\x33\x32")."\"MarcarTodos\" ".mystr11s96("m\x79s\x74r\x311\x73443\x33")."\"SelectUser[]\" ".mystr11s96("mys\x74r1\x31\x7345\x33\x34")."\"SelectUser\" ".mystr11s96("m\x79str\x311s4\x3635")."\""
.$mystr11s6235[mystr11s96("mys\x74r\x311\x73\x34\x3736")]."\" ".mystr11s96("m\x79st\x72\x31\x31s4\x383\x37")."\"VerificarCheck()\"></td>
 ".mystr11s96("mys\x74r11\x73493\x38")
.$mystr11s6235[mystr11s96("m\x79\x73tr\x311s\x350\x33\x39")].$mystr11s6247.mystr11s96("mys\x74r\x31\x31s51\x340").$mystr11s6235[mystr11s96("m\x79st\x7211s\x35\x324\x31")].mystr11s96("\x6d\x79st\x721\x31s53\x342")
.$mystr11s6235[mystr11s96("my\x73t\x721\x31s5\x344\x33")].mystr11s96("\x6dys\x74\x7211\x7355\x344");echo mystr11s96("my\x73tr1\x31s5\x3645").$mystr11s6241.mystr11s96("\x6d\x79s\x74\x7211\x735\x3746");
if( ($mystr11s6243 == $mystr11s6244) || ($mystr11s6243 != ${mystr11s96("mystr11s2713")}) && (${mystr11s96("mystr11s2917")} > ${mystr11s96("mystr11s2918")}) ){
echo mystr11s96("my\x73t\x72\x311\x73\x35\x384\x38")."\"pointer ".mystr11s96("\x6dyst\x7211s\x3594\x39")."\" ".mystr11s96("my\x73\x74r1\x31s60\x35\x30")."\"tooltip\" ".mystr11s96("\x6dy\x73\x74\x721\x31s61\x351")."\"top\" ".mystr11s96("my\x73tr\x311s6\x32\x352")."\"\" ".mystr11s96("\x6dyst\x7211\x736\x335\x33")."\"Esgotado\">Esgotado</span> ".$mystr11s6243.mystr11s96("mys\x74\x721\x31s6\x3454");
}else{echo mystr11s96("m\x79st\x72\x311s6\x355\x35")."\"pointer ".mystr11s96("mys\x74r11\x7366\x35\x36")."\" ".mystr11s96("m\x79\x73t\x721\x31\x73\x367\x357")."\"tooltip\" ".mystr11s96("mys\x74r\x31\x31s6\x3858")."\"top\" ".mystr11s96("m\x79st\x7211s\x3695\x39")."\"\" ".mystr11s96("mys\x74\x7211\x73706\x30")."\"Ativo\">Ativo</span> ".$mystr11s6243.mystr11s96("m\x79s\x74\x72\x311s7\x3161");
}echo mystr11s96("mys\x74r1\x31s72\x362").${mystr11s96("mystr11s1497")}[mystr11s96("m\x79str\x311s\x3736\x33")].mystr11s96("mys\x74\x721\x31s74\x364");
echo mystr11s96("my\x73t\x72\x31\x31s75\x36\x35")."\"form-group\">";echo mystr11s96("\x6dyst\x7211\x73\x37\x3666")."\"label ".mystr11s96("my\x73\x74r\x311\x7377\x367")."\" ".mystr11s96("\x6dy\x73\x74r1\x31\x7378\x368")."\"tooltip\" ".mystr11s96("my\x73tr\x311s7\x3969")."\"top\" ".mystr11s96("\x6dyst\x7211\x73\x38\x307\x30")."\"\" ".mystr11s96("my\x73\x74\x721\x31s\x381\x371")."\"Editar\" ".mystr11s96("\x6dys\x74r11\x7382\x372")."\"EditarUser('".$mystr11s6235[mystr11s96("my\x73tr1\x31s8\x3373")].mystr11s96("\x6d\x79s\x74r11\x73847\x34")."\"><i ".mystr11s96("my\x73t\x72\x31\x31s\x38575")."\"fa ".mystr11s96("m\x79st\x7211\x738\x3676")."\"></i></a>&nbsp;";
if(${mystr11s96("mystr11s2815")}[mystr11s96("mys\x74r11\x738\x3777")] == mystr11s96("m\x79s\x74\x7211s\x3887\x38")){echo mystr11s96("mys\x74r1\x31s89\x379")."\"StatusBloDes".$mystr11s6235[mystr11s96("m\x79str\x311s\x39\x3080")]."\"><a ".mystr11s96("mys\x74\x72\x311\x73\x39\x31\x381")."\"desbloquear ".mystr11s96("m\x79s\x74r11\x7392\x382")."\" ".mystr11s96("mys\x74r11\x7393\x383")."\"tooltip\" ".mystr11s96("m\x79\x73t\x72\x311\x7394\x384")."\"top\" ".mystr11s96("mys\x74r\x31\x31s\x39585")."\"\" ".mystr11s96("m\x79st\x7211\x739\x368\x36")."\"Desbloquear\" ".mystr11s96("\x6dyst\x721\x31s9\x3787")."\"DesbloquearUser('".$mystr11s6235[mystr11s96("my\x73\x74\x7211s\x39\x38\x38\x38")].mystr11s96("\x6dys\x74r11\x73\x3998\x39").$mystr11s6235[mystr11s96("my\x73tr1\x31s\x310\x30\x390")].mystr11s96("\x6d\x79\x73tr\x311s\x31019\x31")."\"><i ".mystr11s96("my\x73t\x7211s\x31029\x32")."\"fa ".mystr11s96("\x6dys\x74r1\x31s10\x339\x33")."\"></i></a></span>&nbsp;";
}else{echo mystr11s96("my\x73tr1\x31s\x31\x30494")."\"StatusBloDes".$mystr11s6235[mystr11s96("\x6dy\x73tr1\x31s\x310\x359\x35")]."\"><a ".mystr11s96("my\x73tr\x311s\x3106\x396")."\"bloquear ".mystr11s96("\x6dyst\x721\x31s10\x37\x39\x37")."\" ".mystr11s96("my\x73\x74\x72\x311s\x31089\x38")."\"tooltip\" ".mystr11s96("m\x79s\x74r11\x731\x30\x3999")."\"top\" ".mystr11s96("mys\x74r1\x31s\x311\x3100")."\"\" ".mystr11s96("m\x79\x73\x74r1\x31\x7311\x32\x301")."\"Bloquear\" ".mystr11s96("mys\x74r\x311s1\x31302")."\"BloquearUser('".$mystr11s6235[mystr11s96("m\x79st\x7211\x73\x31140\x33")].mystr11s96("mys\x74r11\x731\x315\x304").${mystr11s96("mystr11s2815")}[mystr11s96("m\x79\x73tr1\x31s1\x31605")].mystr11s96("mys\x74r1\x31s1\x31706")."\"><i ".mystr11s96("m\x79str\x311\x73118\x307")."\"fa ".mystr11s96("mys\x74\x72\x31\x31\x7311\x39\x308")."\"></i></a></span>&nbsp;";
}echo mystr11s96("m\x79s\x74r11\x731\x3200\x39")."\"StatusDeletar".$mystr11s6235[mystr11s96("\x6dys\x74r\x311s\x31\x321\x31\x30")]."\"><a ".mystr11s96("my\x73tr1\x31\x73122\x311")."\"deletar ".mystr11s96("\x6dy\x73tr1\x31\x73123\x31\x32")."\" ".mystr11s96("my\x73tr\x311s\x312\x341\x33")."\"tooltip\" ".mystr11s96("\x6dyst\x721\x31s\x31251\x34")."\"top\" ".mystr11s96("my\x73\x74r11\x7312\x361\x35")."\"\" ".mystr11s96("\x6dy\x73tr\x311s1\x32716")."\"Excluir\" ".mystr11s96("my\x73tr\x311\x73\x312\x3817")."\"Deletar('".$mystr11s6235[mystr11s96("\x6d\x79\x73t\x7211\x731\x3291\x38")].mystr11s96("my\x73t\x7211s\x3130\x31\x39").$mystr11s6235[mystr11s96("\x6dys\x74r\x311s\x3131\x32\x30")].mystr11s96("mys\x74r11\x73\x31322\x31")."\"><i ".mystr11s96("m\x79\x73tr1\x31\x7313\x3322")."\"fa ".mystr11s96("mys\x74r\x311s\x313\x3423")."\"></i></a></span>&nbsp;";
echo mystr11s96("m\x79str\x311\x7313\x352\x34")."\"label ".mystr11s96("mys\x74\x7211s\x31362\x35")."\" ".mystr11s96("m\x79s\x74r1\x31\x731\x337\x326")."\"tooltip\" ".mystr11s96("mys\x74r1\x31s\x31\x33827")."\"top\" ".mystr11s96("m\x79str\x31\x31s\x31\x33\x39\x328")."\"\" ".mystr11s96("mys\x74r\x311s1\x3402\x39")."\"Tornar ".mystr11s96("m\x79st\x721\x31s14\x31\x330")."\" ".mystr11s96("mys\x74r11\x73\x31\x3423\x31")."\"Usuario('".$mystr11s6235[mystr11s96("my\x73\x74r11\x731\x34\x3332")].mystr11s96("\x6dy\x73tr\x311s\x314\x3433").$mystr11s6235[mystr11s96("my\x73tr\x311\x7314\x3534")].mystr11s96("\x6d\x79str\x311s1\x346\x335")."\"><i ".mystr11s96("my\x73t\x7211\x73\x31473\x36")."\"fa ".mystr11s96("\x6dys\x74r\x311\x731\x34\x38\x337")."\"></i></a>&nbsp;";
echo mystr11s96("my\x73tr1\x31\x7314\x3938");echo mystr11s96("\x6d\x79st\x7211s\x31\x35039");}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- PAGE CONTENT WRAPPER -->
<div id="StatusGeral"></div>
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<!-- END PLUGINS -->
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap-select.js"></script>
<script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/DataTables-br.js"></script>
<!-- END THIS PAGE PLUGINS-->
<!-- START TEMPLATE -->
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<!-- END TEMPLATE -->
<script type='text/javascript'>
function EditarUser(id){
panel_refresh($(".page-container"));
$.post('ScriptModalTesteEditar.php', {id: id}, function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
function BloquearUser(id, status){
panel_refresh($(".page-container"));
$.post('EnviarBloquearTeste.php', {id: id}, function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#"+status+"").html('');
$("#"+status+"").html(resposta);
});
}
function DesbloquearUser(id, status){
panel_refresh($(".page-container"));
$.post('EnviarDesbloquearTeste.php', {id: id}, function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#"+status+"").html('');
$("#"+status+"").html(resposta);
});
}
function Usuario(id, usuario){
var titulo = 'Tornar Usuário?';
var texto = 'Tem certeza que deseja tornar o teste '+usuario+' em usuário?';
var tipo = 'info';
var url = 'EnviarUsuarioTeste';
var fa = 'fa fa-user';
$.post('ScriptAlertaJS.php', {id: id, titulo: titulo, texto: texto, tipo: tipo, url: url, fa: fa}, function(resposta) {
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
function Deletar(id, status){
panel_refresh($(".page-container"));
$.post('EnviarDeletarTeste.php', {id: id}, function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#"+status+"").html('');
$("#"+status+"").html(resposta);
});
}
$(function(){
$("button.Adicionar").click(function() {
panel_refresh($(".page-container"));
$.post('ScriptModalTesteAdicionar.php', function(resposta) {
setTimeout(panel_refresh($(".page-container")),500);
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
});
});
$(function(){
$(".ExibirRevs select[name=Exibir]").change(function(){
var id = $(this).val();
var status = $('#StatusE').attr('value');
var panel = $(this).parents(".panel");
panel_refresh(panel);
$.post('criar-teste-status.php', {id: id, status: status}, function(resposta) {
setTimeout(function(){
panel_refresh(panel);
},500);
$(".table-responsive").html('');
$(".table-responsive").html(resposta);
});
});
});
$(function(){
$("a.ExibirStatus").click(function() {
$(".ExibirAllOpcoes").html('');
var status = $(this).attr("status");
if(status == 'Todos'){
statusE = 'Todos';
}
else if(status == 'Ativos'){
statusE = 'Ativos';
}
else if(status == 'Inativos'){
statusE = 'Esgotados';
}
else{
statusE = 'Todos';
}
$("#StatusE").html(statusE);
$("#StatusE").attr('value', status);
var usuario = $('#StatusUE').attr('value');
var panel = $(this).parents(".panel");
panel_refresh(panel);
$.post('criar-teste-status.php', {usuario: usuario, status: status}, function(resposta) {
setTimeout(function(){
panel_refresh(panel);
},500);
$(".table-responsive").html('');
$(".table-responsive").html(resposta);
});
});
});
function marcardesmarcar(){
TotalAll = $('[name="TotalAll"]:checked').length;
TotalSUser = $('[name="SelectUser[]"]:checked').length;
TotalSGeral = $('[name="SelectUser[]"]').length;
$('.MarcarTodos').each(
function(){
if ( (TotalAll > 0) && (TotalSUser == 0) ){
$(this).prop("checked", true);
}
else if ( (TotalAll == 0) && (TotalSUser == TotalSGeral) ){
$(this).prop("checked", false);
}
else if ( (TotalAll > 0) && (TotalSUser > 0) ){
$(this).prop("checked", true);
}
else if ( (TotalAll == 0) && (TotalSGeral != TotalSUser) ){
$(this).prop("checked", false);
}
else {
$(this).prop("checked", false);
}
}
);
VerificarCheck();
}
function VerificarCheck(){
TotalSUser = $('[name="SelectUser[]"]:checked').length;
TotalSUserGeral = $('[name="SelectUser[]"]').length;
if(TotalSUser == TotalSUserGeral){
$(".MarcarAll").prop("checked", true);
}
else{
$(".MarcarAll").prop("checked", false);
}
if( TotalSUser > 0){
$.post('SelecionarOpcoesTeste.php', function(resposta) {
$(".ExibirAllOpcoes").html(resposta);
});
}
else{
$(".ExibirAllOpcoes").html('');
$(".MarcarAll").prop("checked", false);
}
}
</script>
<!-- END SCRIPTS -->
<?php
}else{echo mystr55s164(mystr11s96("my\x73t\x721\x31\x7315\x3140"));}}else{echo mystr55s164(mystr11s96("\x6dyst\x72\x31\x31\x7315\x3241"));
}
?>
