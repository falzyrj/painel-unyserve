<?php
include('conexao2.php');
include('funcoes.php');

$id_cad	= 1; //codigo de quem cadastrou
$acesso	= 2; //codigo de revenda
$nome = $_POST['nome'];
$login= $_POST['login'];
$senha = $_POST['senha'];	
$bloqueado = 'S';
//aqui tu manda salvar na tabela

mysqli_query($conn,"insert into login (id_cad,acesso,nome,login,senha,bloqueado) 
values('$id_cad','$acesso','$nome','$login','$senha','$bloqueado')") or die (mysqli_error($conn));

echo("Cadastro criado com sucesso");

header("location:login.php?msg=Cadastro criado com sucesso.");


?>