function baixarArquivo() {
    // Lógica para baixar o arquivo
  }
  