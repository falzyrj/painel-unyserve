<?php

    //limpa sempre o arquivo
    $fp = fopen('img/arquivo-nome.txt', "w");
    //salva o nome novo
    file_put_contents('img/arquivo-nome.txt', $_POST['novonome'],FILE_APPEND); 

    echo '<a class="btn btn-warning">Nome alterado com sucesso</a>'; 


?>