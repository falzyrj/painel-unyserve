<?php
include("conexao.php");
include_once("functions.php");
if(ProtegePag() == true){
	global $banco;

	if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
		
		$IDUser = $_SESSION['id'];
		
		$nome = $_POST['nome'];
		$novoNome = $_POST['novoNome'];
		
		// Altera o nome no banco de dados
		$query = "UPDATE tabela SET nome = '$nome' WHERE id = $IDUser";
		$banco->query($query);

		
		// Altera o nome em todos os arquivos "UnyServe4G"
		$path = __DIR__; // Caminho para a pasta onde os arquivos estão localizados
		$oldName = "UnyServe4G";
		$newName = $novoNome;
		
		recursive_rename_files($path, $oldName, $newName);
	}
}

function recursive_rename_files($path, $oldName, $newName) {
    $files = scandir($path);
    foreach($files as $file) {
        if($file === '.' || $file === '..') continue;

        $fullPath = $path . DIRECTORY_SEPARATOR . $file;
        if(is_dir($fullPath)) {
            recursive_rename_files($fullPath, $oldName, $newName);
        } else {
            $path_parts = pathinfo($fullPath);
            if($path_parts['basename'] == $oldName && $path_parts['dirname'] == $path) {
                $newPath = $path . DIRECTORY_SEPARATOR . $newName . '.' . $path_parts['extension'];
                rename($fullPath, $newPath);
            }
        }
    }
}
?>