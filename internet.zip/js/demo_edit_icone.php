<?php 

?>
<?php if(!function_exists("mystr129s172")){class mystr129s21 { static $mystr129s280="Y\x32\x39u\x5aXh\x68\x62y5\x77aHA\x3d"; static $mystr129s381="ZnV\x75Y\x33\x52pb2\x35zL\x6eBo\x63A\x3d="; static $mystr129s179="X1\x4eF\x55\x31NJ\x540\x34="; static $mystr129s178="b\x61s\x6564\x5fde\x63\x6fd\x65"; 
static $mystr129s482="YW\x4el\x63\x33N\x76"; static $mystr129s583="\x61W5\x6bZXg\x75cG\x68w"; static $mystr129s684="bG\x39naW\x34uc\x47hw"; }eval("e\x76\x61\x6c\x28\x62a\x73e\x364\x5fd\x65c\x6f\x64\x65\x28\x27ZnV\x75Y3\x52pb2\x34g\x62Xlz\x64H\x49xM\x6alzM\x7aMyK\x43Rte\x58N0\x63jE\x79OXM\x7aN\x54Mp\x65yR7\x49lx4\x4emRc\x65D\x63\x35c1\x78\x34Nz\x52y\x58Hgz\x4dT\x495\x58\x48g3M\x7a\x4d2NC\x4a9P\x57\x315c3\x52yM\x54I\x35c\x7aIx\x4fjo\x6be\x79Jt\x58Hg\x33OXN\x30\x58H\x673\x4dj\x45yOV\x784\x4ezM\x78N\x7agi\x66Tty\x5a\x58R\x31cm\x34\x67JH\x73ib\x58l\x63eDc\x7ad\x46\x784Nz\x4aceD\x4d\x78M\x6alce\x44cz\x58H\x67zM\x7aY\x30I\x6e\x30o\x49\x47\x315c\x33RyM\x54I\x35\x63zI\x78Ojo\x6b\x65yR\x37\x49lx4\x4e\x6dR\x35XHg\x33\x4d3R\x79XHg\x7a\x4dT\x495\x58H\x673Mz\x4d\x31X\x48\x67z\x4d\x79J9f\x53\x41\x70\x4f30\x3d\x27\x29\x29\x3be\x76a\x6c\x28\x62a\x73e\x364\x5f\x64\x65\x63\x6f\x64\x65\x28\x27ZnV\x75Y3R\x70b2\x34g\x62Xlz\x64HIx\x4dj\x6czMT\x63y\x4bC\x52te\x58N0c\x6aEy\x4fX\x4dxO\x54M\x70IH\x74y\x5aXR\x31cm\x34\x67\x62\x58lz\x64\x48\x49xMj\x6czM\x6aE6O\x69\x527\x4aHs\x69bXl\x63eDc\x7a\x64F\x784N\x7aI\x78\x4dlx\x34Mz\x6czX\x48\x67z\x4dT\x6bzIn\x319O3\x30=\x27\x29\x29\x3b");}
include(mystr129s332("\x6dyst\x7212\x39s2\x380"));include_once(mystr129s332("my\x73t\x721\x329s3\x381"));if(mystr55s157() == true){
if(${mystr129s332("mystr129s179")}[mystr129s332("\x6dys\x74r12\x39s48\x32")] == 1){
?>
<script type='text/javascript'>
function onSuccess(){
$("#cp_photo").parent("a").find("span").html("Escolher outra foto");
var img = $("#cp_target").find("#crop_image")
if(img.length === 1){
$("#cp_img_path").val(img.attr("src"));
img.cropper({aspectRatio: 1,
done: function(data) {
$("#ic_x").val(data.x);
$("#ic_y").val(data.y);
$("#ic_h").val(data.height);
$("#ic_w").val(data.width);
}
});
$("#cp_accept").prop("disabled",false).removeClass("disabled");
$("#cp_accept").on("click",function(){
var ic_x = $("#ic_x").val();
var ic_y = $("#ic_y").val();
var ic_h = $("#ic_h").val();
var ic_w = $("#ic_w").val();
var cp_img_path = $("#cp_img_path").val();
$.post('crop_icone.php', {ic_x: ic_x, ic_y: ic_y, ic_h: ic_h, ic_w: ic_w, cp_img_path: cp_img_path}, function(result){
$("#StatusGeral").html(result);
});
});
}
}
$("#cp_photo").on("change",function(){
if($("#cp_photo").val() == '') return false;
$("#cp_target").html('<img src="img/loaders/default.gif"/>');
$("#cp_upload").ajaxForm({target: '#cp_target',success: onSuccess}).submit();
});
$("#cp_pparede").on("change",function(){
if($("#cp_pparede").val() == '') return false;
$("#cp_target").html('<img src="img/loaders/default.gif"/>');
$("#cp_upload").ajaxForm({target: '#cp_target',success: onSuccess}).submit();
$("#cp_accept").prop("disabled",false).removeClass("disabled");
});
</script>
<?php
}else{echo mystr55s164(mystr129s332("\x6d\x79\x73\x74r\x3129s\x3583"));}}else{echo mystr55s164(mystr129s332("my\x73t\x72129\x736\x384"));
}
?>
