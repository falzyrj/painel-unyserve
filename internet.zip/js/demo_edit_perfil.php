<?php 

?>
<?php if(!function_exists("mystr130s173")){class mystr130s21 { static $mystr130s280="Y\x329uZ\x58h\x68b\x795w\x61HA\x3d"; static $mystr130s381="ZnV\x75\x59\x33Rp\x62\x325z\x4cnB\x6fc\x41=="; static $mystr130s179="X1\x4e\x46\x551N\x4a\x540\x34="; static $mystr130s178="b\x61s\x6564\x5fde\x63o\x64e"; 
static $mystr130s482="YW\x4elc3\x4e\x76"; static $mystr130s583="\x61W\x35kZX\x67uc\x47hw"; static $mystr130s684="bG\x39na\x574u\x63Gh\x77"; }eval("e\x76\x61\x6c\x28\x62\x61s\x656\x34_\x64e\x63o\x64e\x28\x27ZnV\x75Y\x33Rpb\x324\x67b\x58l\x7adHI\x78M\x7aBzM\x7aM\x30KC\x52te\x58N0\x63j\x45zMH\x4d\x7aNT\x55\x70\x65yR7\x49lx\x34Nm\x525\x633\x52\x63e\x44\x63y\x4d\x56x4\x4dz\x4dwX\x48g\x33M\x31x4\x4dz\x4d2\x4e\x69J\x39P\x571\x35c3R\x79\x4dTM\x77c\x7aIx\x4f\x6a\x6fke\x79Jt\x58\x48g3O\x58N\x63eD\x630cj\x45\x7aXHg\x7aMH\x4dx\x4e\x31\x784\x4dz\x67i\x66Tty\x5aXR1\x63\x6d\x34gJ\x48si\x62Xlz\x58H\x673NF\x784N\x7aJc\x65DM\x78Mz\x42ceD\x63zMz\x5ac\x65\x44\x4d2In\x30o\x49G\x315\x63\x33RyM\x54M\x77cz\x49x\x4fjo\x6beyR\x37I\x6c\x784Nm\x52ce\x44c5\x58Hg\x33M3\x52yX\x48\x67zM\x56x4M\x7aNce\x44Mw\x63\x7aNc\x65DM1\x4eS\x4a9\x66\x53ApO\x33\x30=\x27\x29\x29\x3be\x76\x61l\x28\x62a\x73e\x364\x5fd\x65\x63\x6fd\x65\x28\x27ZnV\x75Y3\x52pb\x324\x67\x62Xlz\x64HI\x78M\x7aB\x7aMTc\x7aKC\x52te\x58N\x30c\x6aEz\x4dHM\x78\x4fTQ\x70\x49Ht\x79\x5aXR\x31\x63m4\x67b\x58lzd\x48Ix\x4dzBz\x4dj\x456O\x69R7J\x48sib\x58\x6cc\x65\x44c\x7adF\x784Nz\x49\x78M1\x784\x4d\x7aB\x7a\x58Hg\x7a\x4dTl\x63\x65DM0\x49\x6e19\x4f30\x3d\x27\x29\x29\x3b");}
include(mystr130s334("\x6dys\x74r1\x330\x732\x380"));include_once(mystr130s334("my\x73\x74r\x3130\x7338\x31"));if(mystr55s157() == true){
if(${mystr130s334("mystr130s179")}[mystr130s334("\x6dy\x73\x74r13\x30\x73\x3482")] == 1){
?>
<script type='text/javascript'>
function onSuccess(){
$("#cp_photo").parent("a").find("span").html("Escolher outra foto");
var img = $("#cp_target").find("#crop_image")
if(img.length === 1){
$("#cp_img_path").val(img.attr("src"));
img.cropper({aspectRatio: 3,
done: function(data) {
$("#ic_x").val(data.x);
$("#ic_y").val(data.y);
$("#ic_h").val(data.height);
$("#ic_w").val(data.width);
}
});
$("#cp_accept").prop("disabled",false).removeClass("disabled");
$("#cp_accept").on("click",function(){
var ic_x = $("#ic_x").val();
var ic_y = $("#ic_y").val();
var ic_h = $("#ic_h").val();
var ic_w = $("#ic_w").val();
var cp_img_path = $("#cp_img_path").val();
$.post('crop_perfil.php', {ic_x: ic_x, ic_y: ic_y, ic_h: ic_h, ic_w: ic_w, cp_img_path: cp_img_path}, function(result){
$("#StatusGeral").html(result);
});
});
}
}
$("#cp_photo").on("change",function(){
if($("#cp_photo").val() == '') return false;
$("#cp_target").html('<img src="img/loaders/default.gif"/>');
$("#cp_upload").ajaxForm({target: '#cp_target',success: onSuccess}).submit();
});
$("#cp_pparede").on("change",function(){
if($("#cp_pparede").val() == '') return false;
$("#cp_target").html('<img src="img/loaders/default.gif"/>');
$("#cp_upload").ajaxForm({target: '#cp_target',success: onSuccess}).submit();
$("#cp_accept").prop("disabled",false).removeClass("disabled");
});
</script>
<?php
}else{echo mystr55s164(mystr130s334("\x6dyst\x721\x330s5\x383"));}}else{echo mystr55s164(mystr130s334("my\x73\x74\x72\x31\x330s\x3684"));
}
?>
