<?php
include("conexao.php");
include("conexao2.php");
include('funcoes.php');
include_once("functions.php");
@$iduser = @$_SESSION['id'];
if(ProtegePag() == true){
global $banco;
?>

<ul class="breadcrumb">
                    <li class="active"></span>&#160;Olá&#160;<strong><?php echo $_SESSION['nome']?></strong>&#160;Aqui você faz as configuração do Painel</li>
                </ul>
                <!-- END BREADCRUMB --> 
                
                <!-- PAGE TITLE -->
          <div class="page-title">                    
          
          </div>
                <!-- END PAGE TITLE -->   
 
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">                    
                        <div class="panel panel-default">
                                <div class="panel-heading">
     
    <h2><span class="fa fa-align-left"></span>&nbsp; Configuração do Painel</h2>
    </div> 

          <?php
				if($iduser == 1){
            echo "<div class=\"panel panel-default\">
            <div class=\"panel-heading\">
            <h3 class=\"panel-title\">Nome do Painel</h3>
            </div>
            <div class=\"panel-body\">
            <form method=\"post\" id=\"formAddNome\" autocomplete=\"off\" enctype=\"multipart/form-data\">
            <label class=\"col-xs-12 col-lg-6 col-md-6 col-sm-12\">
             <input type=\"text\" class=\"form-control\" name=\"novonome\" required/>
            </label>                    
            </div>      
            <div class=\"panel-footer\">
            <div id=\"retornoNome\"></div> 
            <button type=\"submit\" class=\"btn btn-primary pull-right\">Salvar</button>                        
            </div>  
            </form>                          
            </div>";
                            
            echo "<div class=\"panel panel-default\">
            <div class=\"panel-heading\">
            <h3 class=\"panel-title\">background (JPG/JPEG/PNG)</h3>
            </div>
            <div class=\"panel-body\">
            <form method=\"post\" id=\"formAddLog\" autocomplete=\"off\" enctype=\"multipart/form-data\">
            <label class=\"col-xs-12 col-lg-6 col-md-6 col-sm-12\">
            <input type=\"file\" class=\"form-control\" name=\"foto\" accept=\"image/png, image/jpg, image/jpeg\"/>
            </label>                    
            </div>      
            <div class=\"panel-footer\">
            <div id=\"retorno\"></div> 
            <button type=\"submit\" class=\"btn btn-primary pull-right\">Salvar</button>                        
            </div>  
            </form>                          
            </div>";

            echo "<div class=\"panel panel-default\">
            <div class=\"panel-heading\">
            <h3 class=\"panel-title\">Logo Marca (JPG/JPEG/PNG)</h3>
            </div>
            <div class=\"panel-body\">
            <form method=\"post\" id=\"formAddLogo\" autocomplete=\"off\" enctype=\"multipart/form-data\">
            <label class=\"col-xs-12 col-lg-6 col-md-6 col-sm-12\">
            <input type=\"file\" class=\"form-control\" name=\"fotologo\" accept=\"image/png, image/jpg, image/jpeg\"/>
            </label>                    
            </div>      
            <div class=\"panel-footer\">
            <div id=\"retornoLogo\"></div> 
            <button type=\"submit\" class=\"btn btn-primary pull-right\">Salvar</button>                        
            </div>  
            </form>                          
            </div>";
                }
				?>
                 <!-- troca a imagem de fundo da tela inicial -->

                <!-- END PAGE TITLE --> 
                
                <?php
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
				?>
                <div class="col-md-12">
                        <?php
						$UserOnline = $_SESSION['login'];
                        $SQLUrlT = "SELECT status, tempo, cemail, email FROM urlteste WHERE CadUser = :CadUser";
						$SQLUrlT = $banco->prepare($SQLUrlT);
						$SQLUrlT->bindParam(':CadUser', $UserOnline, PDO::PARAM_STR);
						$SQLUrlT->execute();
						$TotalUrlT = count($SQLUrlT->fetchAll());
                        

                                            
                            
                         ?>
                            
                        </div>
                            
                
                

						
          
                <?php
				}
				
				
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
					//Servidor
					$SQLArq = "SELECT * FROM arquivo";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->execute();
				}
				else{
					//Servidor
					$operadora = $_SESSION['operadora'];
					$OpTodos = "Todos";
					$SQLArq = "SELECT * FROM arquivo WHERE operadora = :operadora OR operadora = :OpTodos";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->bindParam(':operadora', $operadora, PDO::PARAM_STR);
					$SQLArq->bindParam(':OpTodos', $OpTodos, PDO::PARAM_STR);
					$SQLArq->execute();
				}
				
				while($LnArq = $SQLArq->fetch()){
					
				$apn = empty($LnArq['apn']) ? "" : "<p><b><font color=\"#FF0000\">APN:</font></b> ".$LnArq['apn']."</p>";
				
					$SQLImagem = "SELECT imagem FROM imagem_perfil WHERE id = :id";
					$SQLImagem = $banco->prepare($SQLImagem);
					$SQLImagem->bindParam(':id', $LnArq['imagem'], PDO::PARAM_STR);
					$SQLImagem->execute();
					$LnImagem = $SQLImagem->fetch();
					$img = "<img src=\"img/perfil/".$LnImagem['imagem']."\" height=\"83\" width=\"254\" title=\"".$LnArq['nome']."\">";
					
					$UrlArq = empty($LnArq['file']) ? $LnArq['url'] : UrlAtual()."download/".$LnArq['file'];
					
				echo "<div class=\"col-md-4\">

                            <!-- NEWS WIDGET -->
                            <div class=\"panel panel-".$LnArq['tipo']."\">
                                <div class=\"panel-heading\">
                                    <h3 class=\"panel-title\">".$LnArq['nome']."</h3>         
                                </div>
                                <div class=\"panel-body scroll\" style=\"height: 230px;\">  
                                        
                                    <center>".$img."</center>
                                    <br /><br />
									<h6>".$LnArq['titulo']."</h6>
                                    <p>".$LnArq['descricao']."</p>
									".$apn."
                                                                                           
                              </div>
                                
                                <div class=\"panel-footer\"> 
                                  <a target=\"_blank\" href=\"".$UrlArq."\" class=\"btn btn-".$LnArq['tipo']." btn-block\">".$LnArq['botao']."</a>
                                </div>
                                
                            </div>
                            <!-- END NEWS WIDGET -->

                        </div> ";
					
				}
				
				
				
				
				
				?>
               
		<div id="StatusGeral"></div>        
<!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>  
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->        
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>  
        <script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>  
                <script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/DataTables-br.js"></script>  
        
        <!-- END THIS PAGE PLUGINS-->        

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>
        <!-- END TEMPLATE -->
        
        <?php
		if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
		?>
        <script type='text/javascript'>
		function ConfigTeste(){
			
			panel_refresh($(".page-container"));
			
			$.post('ScriptModalTesteConfig.php', function(resposta) {
				
				setTimeout(panel_refresh($(".page-container")),500);
				
				$("#StatusGeral").html('');
				$("#StatusGeral").html(resposta);
			});	
		}
		</script>
        <?php
		}
		?>
       
    <!-- END SCRIPTS -->    
<?php
}else{
	echo Redirecionar('login.php');
}	
?>

<script>
$('#formAddLog').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-fundo.php',
      data:formData,
      success:function(data){
        $('#retorno').show().fadeOut(2500).html(data);
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddLogo').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-logo.php',
      data:formData,
      success:function(data){
        $('#retornoLogo').show().fadeOut(2500).html(data);
        history.go();
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddNome').submit(function(){
    $.ajax({
      type:'post',
      url:'insert-nome.php',
      data:$('#formAddNome').serialize(),
      success:function(data){
        $('#retornoNome').show().html(data);
        history.go();
      },      
    });
    return false;
  });
</script>