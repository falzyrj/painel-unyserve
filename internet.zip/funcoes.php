<?php
//limpar
function limpar($valor){
    $valor = trim($valor);
    $valor = str_replace("<", "", $valor);
    $valor = str_replace(">", "", $valor);
    $valor = str_replace(".", "", $valor);
    $valor = str_replace(",", "", $valor);
    $valor = str_replace("-", "", $valor);
    $valor = str_replace("/", "", $valor);
    $valor = str_replace("(", "", $valor);
    $valor = str_replace(")", "", $valor);
    $valor = str_replace(" ", "", $valor);
    $valor = str_replace("_", "", $valor);
    $valor = str_replace("@", "", $valor);
    return $valor;
};

function Moeda($get_valor) {
$source = array('.', ',');
$replace = array('', '.');
$valor = str_replace($source, $replace, $get_valor); //remove os pontos e substitui a virgula pelo ponto
if(empty($valor)){return 0;}else{return $valor;} //retorna o valor formatado para gravar no banco
};//moeda

function Moeda2($valor) {
$valor = number_format($valor,2);
$source = array('', '.');
$replace = array('.', '');
$valor = str_replace($source, $replace, $valor);
return $valor;
};//moeda2

function Real($valor){ if($valor==true){ return number_format($valor,2,',','.');} else { return '0,00';}};


function AspasForm($string){
	$string = str_replace('"',chr(146).chr(146), $string);
	$string = str_replace("'",chr(146), $string);
	return $string;
};

function AspasBanco($string){
	$string = str_replace(chr(146).chr(146),'"', $string);
	$string = str_replace(chr(146),"'",$string);
	return addslashes($string);
};


//data form
function dataForm($valor){
    if($valor != 0000-00-00){
        $valor = date('d-m-Y',strtotime($valor));
        return $valor;
    }
}
//data certa
function dataBanco($valor){
    if($valor != 0000-00-00){
        $valor = date('Y-m-d',strtotime($valor));
        return $valor;
    }
}

function gerarToken($entropy){
    $s=uniqid("",$entropy);
    $num= hexdec(str_replace(".","",(string)$s));
    $index = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $base= strlen($index);
    $out = '';
        for($t = floor(log10($num) / log10($base)); $t >= 0; $t--) {
            $a = floor($num / pow($base,$t));
            $out = $out.substr($index,$a,1);
            $num = $num-($a*pow($base,$t));
        }
    return $out;
}

function AcessoToken(){
    //alterar para as chaves do cliente do gernecianet
    $cliente_id = 'Client_Id_ae7030438e5e3e7af68f12cba72596f9687c8f1f';
    $cliente_secret = 'Client_Secret_7eb0622e3ee7942be58699b2d117f0e17e0c198e';
    
    $url = URL_API.'/v1/authorize';
    $base64 = base64_encode($cliente_id.':'.$cliente_secret);
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS =>'{"grant_type": "client_credentials"}',
        CURLOPT_HTTPHEADER => array(
        'Authorization: Basic '.$base64,
        'Content-Type: application/json'
        ),
    ));
    $response = curl_exec($curl);
    curl_close($curl);
    $json = json_decode($response);
    //print_r($response);
        return $json->access_token;
    //}
}
?>