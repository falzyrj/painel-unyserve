<?php
$diretorio = "img/fundo";
if (!file_exists($diretorio)){
    mkdir($diretorio, 0777, true);
}

if($_FILES['foto']['name'] != ''){           
    $extensao = strrchr($_FILES['foto']['name'],'.');
    $novonome = mb_strtolower(md5(uniqid(rand(), true)).$extensao);
    $arquivo_tmp = $_FILES['foto']['tmp_name']; 
    move_uploaded_file($arquivo_tmp, $diretorio.'/'.$novonome);

    //limpa sempre o arquivo
    $fp = fopen('img/arquivo-fundo.txt', "w");
    //salva o nome novo
    file_put_contents('img/arquivo-fundo.txt', $novonome,FILE_APPEND); 

    echo '<a class="btn btn-warning">Salvo com sucesso</a>'; 

}else{
    echo '<a class="btn btn-danger">Erro inesperado!!</a>'; 
}
?>