<?php 

?>
<?php if(!function_exists("mystr56s99")){class mystr56s21 { static $mystr56s280="Y29\x75ZXh\x68b\x79\x35waH\x41\x3d"; static $mystr56s178="ba\x73e6\x34_\x64\x65co\x64\x65"; static $mystr56s381="ZnV\x75Y3\x52pb2\x35z\x4cnBo\x63A=="; static $mystr56s179="X1\x4eF\x551N\x4aT\x304="; static $mystr56s482="YWN\x6c\x63\x33Nv"; 
static $mystr56s584="U\x30V\x4dRUN\x55\x49\x43o\x67R\x6cJ\x50T\x53\x42pY2\x39u\x5aV9\x77\x5aX\x4a\x6daW\x77="; static $mystr56s685="\x50Gl\x74Zy\x42z\x63mM\x39"; static $mystr56s786="aW\x31hZ2\x56t"; static $mystr56s887="\x61G\x56\x70Z2h\x30PQ\x3d\x3d"; 
static $mystr56s988="d2\x6ckd\x47g9"; static $mystr56s1089="\x49C8+"; static $mystr56s1190="DQ\x6f\x67\x49C\x41gIC\x41gI\x43\x41g\x49\x43A\x67\x49CAg\x49CAg\x49C\x41gI\x43AgI\x43\x41\x67I\x43A\x67\x49C\x41g\x49C\x41g\x49CAg\x50\x48Ry\x50g0\x4bICA\x67ICA\x67IC\x41gI\x43AgI\x43Ag\x49CAg\x49C\x41gIC\x41gI\x43\x41g\x49\x43A\x67I\x43AgI\x43\x41gI\x43\x41g\x49Ak\x38dG\x51+"; 
static $mystr56s1291="\x50C\x390ZD\x34NC\x67k\x4aC\x51k\x4aCQk\x4a\x43QkJ"; static $mystr56s1392="PH\x52kPj\x78ka\x58YgY\x32xhc\x33M\x39"; static $mystr56s1493="\x50\x47\x45\x67\x62\x325\x6abGl\x6aa\x7a0="; static $mystr56s1595="aW\x51="; 
static $mystr56s1696="\x4ayk\x3d"; static $mystr56s1797="Y2x\x68c3M\x39"; static $mystr56s1898="b\x47\x46\x69ZWw\x74\x5aGF\x75\x5a2Vy"; static $mystr56s1999="ZGF\x30YS\x310b\x32\x64nb\x47U9"; static $mystr56s2100="Z\x47F0Y\x531\x77b\x47FjZ\x571\x6c\x62nQ9"; 
static $mystr56s2201="dGl\x30\x62\x47U9"; static $mystr56s2302="Z\x47F\x30YS1\x76cm\x6cnaW\x35\x68bC1\x30aXR\x73Z\x540="; static $mystr56s2403="Y2x\x68c3\x4d9"; static $mystr56s2504="Z\x6dEtd\x48\x4a\x68c2g\x74bw=\x3d"; static $mystr56s2605="PC9\x6ba\x58Y+D\x51o\x4a\x43QkJ\x43Q\x6bJC\x51kJC\x510K\x43Qk\x4aCQk\x4aC\x51kJ\x43Q\x6b8L\x33\x52kP\x67=="; 
static $mystr56s2706="P\x4390\x63j4\x3d"; static $mystr56s2807="anM\x76ZGV\x74b\x319lZ\x47\x6c0X\x32\x6cjb\x32\x35l\x4cnBo\x63A\x3d="; static $mystr56s2908="aW\x35\x6b\x5a\x58gu\x63G\x68w"; static $mystr56s3009="\x62G\x39na\x57\x34\x75c\x47\x68w"; 
}eval("\x65\x76\x61\x6c\x28b\x61s\x656\x34\x5f\x64\x65\x63o\x64e\x28\x27Z\x6eV\x75Y3R\x70b24\x67bX\x6czd\x48I1N\x6eM\x78\x4fDY\x6fJ\x471\x35c3R\x79NTZ\x7aM\x6aA3K\x58s\x6b\x65yJt\x65\x56\x784N\x7aNce\x44c0c\x6cx4M\x7aU2\x63z\x4ace\x44\x4d\x78\x4fC\x4a\x39PW\x31\x35\x63\x33\x52yNT\x5azMj\x45\x36Oi\x52\x37Im\x315\x58Hg3\x4d3\x52yXH\x67zNT\x5azM\x56x4M\x7ac4\x49n07\x63\x6dV0\x64XJ\x75IC\x52\x37\x49\x6c\x784\x4em\x525XH\x673M\x31x4N\x7aR\x63e\x44cyN\x54\x5azX\x48g\x7aM\x6cx4M\x7aFce\x44M\x34I\x6e\x30o\x49G15\x63\x33Ry\x4eTZz\x4dj\x456\x4fi\x527J\x48\x73ibV\x784\x4ezl\x7a\x58\x48g3\x4eFx4\x4ezI1\x58H\x67\x7a\x4enN\x63eD\x4dyMF\x784Mz\x63if\x58\x30g\x4bT\x749\x27\x29\x29\x3b\x65\x76a\x6c\x28b\x61s\x656\x34\x5f\x64e\x63\x6fd\x65\x28\x27Z\x6eVu\x593R\x70b24\x67b\x58\x6czd\x48I\x31Nn\x4d\x35O\x53gk\x62Xl\x7a\x64\x48I\x31\x4enM\x78MjA\x70IH\x74yZ\x58R1\x63m\x34g\x62X\x6c\x7adHI\x31\x4e\x6eM\x79M\x54o6\x4aHsk\x65yJ\x63eD\x5ak\x65Vx\x34NzN\x30cl\x78\x34M\x7aU2c\x31x4\x4d\x7aEy\x58H\x67zM\x43J9f\x54\x74\x39\x27\x29\x29\x3b");}
include(mystr56s186("\x6dys\x74r56\x73280"));include_once(mystr56s186("my\x73tr5\x36s3\x38\x31"));if(mystr55s157() == true){
global $mystr9s2237;if(${mystr56s186("mystr56s179")}[mystr56s186("\x6d\x79s\x74r\x35\x36s4\x382")] == 1){$mystr56s2235 = mystr56s186("my\x73t\x72\x356\x7358\x34");
$mystr56s2235 = $mystr9s2237->mystrz1115($mystr56s2235);$mystr56s2235->execute();
?>
<link rel="stylesheet" type="text/css" href="css/cropper/cropper.min.css"/>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
<li class="active">Configurações</li>
</ul>
<!-- END BREADCRUMB -->
<!-- PAGE TITLE -->
<div class="page-title">
<h2><span class="fa fa-plus-square-o"></span> Ícone de Perfil</h2>
</div>
<!-- END PAGE TITLE -->
<!-- PAGE CONTENT WRAPPER -->
<div class="page-content-wrap">
<div class="row">
<div class="col-md-12">
<div class="panel panel-default">
<div class="panel-heading">
<div class="btn-group" style="padding:5px 0px 5px 0px;">
<button type="button" class="Adicionar btn btn-info active" data-toggle="modal" data-target="#modal_change_photo">Adicionar</button>
&nbsp;&nbsp;
</div>
<div class="ExibirAllOpcoes btn-group" style="padding:5px 0px 5px 0px;"></div>
<ul class="panel-controls">
<li><a href="#" class="panel-fullscreen"><span class="fa fa-expand"></span></a></li>
<li class="dropdown">
<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><span class="fa fa-cog"></span></a>
<ul class="dropdown-menu">
<li><a href="#" class="panel-collapse"><span class="fa fa-angle-down"></span> Esconder</a></li>
<li><a href="#" class="panel-refresh"><span class="fa fa-refresh"></span> Atualizar</a></li>
</ul>
</li>
</ul>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="table datatable">
<thead>
<tr>
<th>Imagem</th>
<th>Opções</th>
</tr>
</thead>
<tbody>
<?php
while($mystr56s3235 = $mystr56s2235->fetch()){$mystr56s3236 = mystr56s186("my\x73tr\x356\x736\x385")."\"img/icone/".$mystr56s3235[mystr56s186("\x6d\x79\x73tr\x356s7\x38\x36")]."\" ".mystr56s186("my\x73t\x7256s\x3887")."\"20\" ".mystr56s186("\x6dys\x74r5\x36\x73988")."\"20\" ".mystr56s186("my\x73tr5\x36\x731\x308\x39");
echo mystr56s186("\x6d\x79str\x356s\x3119\x30").$mystr56s3236.mystr56s186("my\x73tr\x356s\x3129\x31");echo mystr56s186("\x6dyst\x725\x36s13\x392")."\"form-group\">";
echo mystr56s186("my\x73\x74\x72\x35\x36\x73\x31\x349\x33")."\"Deletar('".$mystr56s3235[mystr56s186("\x6dy\x73tr\x356\x7315\x39\x35")].mystr56s186("mys\x74r5\x36s\x3169\x36")."\" ".mystr56s186("m\x79str\x35\x36s17\x397")."\"label ".mystr56s186("mys\x74r\x356s1\x38\x398")."\" ".mystr56s186("m\x79st\x7256\x73\x319\x399")."\"tooltip\" ".mystr56s186("mys\x74r56\x73\x321\x300")."\"top\" ".mystr56s186("m\x79\x73tr5\x36s2\x32\x301")."\"\" ".mystr56s186("mys\x74r\x356s\x32302")."\"Excluir\"><i ".mystr56s186("m\x79st\x725\x36\x73\x32\x34\x303")."\"fa ".mystr56s186("mys\x74\x7256s\x325\x304")."\"></i></a>&nbsp;";
echo mystr56s186("m\x79s\x74r5\x36s2\x36\x305");echo mystr56s186("mys\x74r5\x36s\x3270\x36");}
?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<!-- PAGE CONTENT WRAPPER -->
<div class="modal animated fadeIn" id="modal_change_photo" tabindex="-1" role="dialog" aria-labelledby="smallModalHead" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Fechar</span></button>
<h4 class="modal-title" id="smallModalHead">Adicionar Ícone de Perfil</h4>
</div>
<form id="cp_crop" method="post" action="javascript:MDouglasMS();">
<div class="modal-body">
<div class="text-center" id="cp_target">Formatos permitidos: jpg, png e gif.</div>
<input type="hidden" name="cp_img_path" id="cp_img_path"/>
<input type="hidden" name="ic_x" id="ic_x"/>
<input type="hidden" name="ic_y" id="ic_y"/>
<input type="hidden" name="ic_w" id="ic_w"/>
<input type="hidden" name="ic_h" id="ic_h"/>
</div>
</form>
<form id="cp_upload" method="post" enctype="multipart/form-data" action="upload_icone.php">
<div class="modal-body form-horizontal form-group-separated">
<div class="form-group">
<label class="col-md-4 control-label">Nova Imagem</label>
<div class="col-md-4">
<input type="file" class="fileinput btn-info" name="file" id="cp_photo" data-filename-placement="inside" title="Selecionar Imagem"/>
</div>
</div>
</div>
</form>
<div class="modal-footer">
<button type="button" class="btn btn-success disabled" id="cp_accept">Aceitar</button>
<button type="button" class="btn btn-default" data-dismiss="modal">Fechar</button>
</div>
</div>
</div>
</div>
<div id="StatusGeral"></div>
<!-- START SCRIPTS -->
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-migrate.min.js"></script>
<!-- END PLUGINS -->
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap-file-input.js"></script>
<script type="text/javascript" src="js/plugins/form/jquery.form.js"></script>
<script type="text/javascript" src="js/plugins/cropper/cropper.min.js"></script>
<script type='text/javascript' src='js/plugins/validationengine/languages/jquery.validationEngine-br.js'></script>
<script type='text/javascript' src='js/plugins/validationengine/jquery.validationEngine.js'></script>
<script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>
<script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/DataTables-br.js"></script>
<!-- END THIS PAGE PLUGINS-->
<!-- START TEMPLATE -->
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<?php include_once(mystr56s186("my\x73tr5\x36\x73280\x37")); ?>
<!-- END TEMPLATE -->
<script type='text/javascript'>
function Deletar(id){
var titulo = 'Excluir?';
var texto = 'Tem certeza que deseja excluir esta imagem?';
var tipo = 'danger';
var url = 'EnviarDeletarIconePerfil';
var fa = 'fa fa-trash-o';
$.post('ScriptAlertaJS.php', {id: id, titulo: titulo, texto: texto, tipo: tipo, url: url, fa: fa}, function(resposta) {
$("#StatusGeral").html('');
$("#StatusGeral").html(resposta);
});
}
</script>
<!-- END SCRIPTS -->
<?php
}else{echo mystr55s164(mystr56s186("\x6d\x79str\x35\x36s\x329\x308"));}}else{echo mystr55s164(mystr56s186("my\x73t\x725\x36s\x33009"));
}
?>
