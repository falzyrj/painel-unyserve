<?php 
?>    
<?php if(!function_exists("mystr8s51")){class mystr8s21 { static $mystr8s280="Y2\x39\x75Z\x58hh\x62y5w\x61HA\x3d"; static $mystr8s381="\x5anV\x75Y3R\x70b25\x7aL\x6eB\x6fcA=\x3d"; static $mystr8s179="\x580\x64FV\x41=="; static $mystr8s482="\x63\x67=\x3d"; static $mystr8s583="cg=\x3d"; 
static $mystr8s686="U\x30VM\x52UNU\x49Gxv\x5a\x32luI\x45ZS\x54\x300gb\x479n\x61W4\x67V\x30hFU\x6bUg\x62G9\x6e\x61W4g\x50\x53A6b\x47\x39naW\x34="; static $mystr8s787="Omx\x76Z2l\x75"; static $mystr8s585="bX\x6czd\x48I\x34cz\x49y\x4dzc\x3d"; 
static $mystr8s178="\x62\x61\x73\x65\x364_\x64e\x63\x6f\x64e"; static $mystr8s789="bX\x6cz\x64HI\x34c\x7aI\x79N\x44A="; static $mystr8s890="ZGl\x68\x63w\x3d="; static $mystr8s991="Z\x47l\x68"; static $mystr8s1092="IA=\x3d"; 
static $mystr8s1193="b\x47\x39n\x61W\x34ucG\x68w"; }eval("e\x76a\x6c\x28\x62a\x73e\x36\x34\x5fd\x65c\x6fd\x65\x28\x27\x5anVu\x593Rp\x6224\x67bX\x6c\x7a\x64\x48I4c\x7a\x6bw\x4bCR\x74\x65X\x4e0c\x6ahzM\x54Ex\x4bXsk\x65yJ\x74X\x48g3\x4f\x58Nc\x65Dc0\x63l\x784M\x7a\x68\x7a\x4dV\x78\x34Mz\x49\x79In\x309\x62X\x6czd\x48I4c\x7aIx\x4fj\x6fkey\x4at\x58H\x67\x33O\x58N0c\x6c\x784Mz\x68zM\x56x4\x4d\x7adc\x65\x44\x4d4I\x6e\x30\x37cmV\x30\x64XJu\x49CR7\x49m15\x631x4\x4ez\x52yOF\x784N\x7aN\x63e\x44MxM\x6aI\x69f\x53ggb\x58l\x7ad\x48I\x34c\x7aIx\x4fjo\x6bey\x527I\x6d1\x63e\x44c5\x633R\x63\x65Dc\x79OH\x4eceD\x4d\x78X\x48g\x7aMT\x45if\x580g\x4bT\x74\x39\x27\x29\x29\x3b\x65v\x61l\x28b\x61\x73\x656\x34\x5f\x64e\x63o\x64e\x28\x27\x5anVu\x593R\x70b\x324\x67bX\x6czdH\x49\x34\x63z\x55\x78KC\x52teX\x4e0\x63j\x68z\x4ez\x49p\x49Ht\x79ZXR\x31\x63m4g\x62X\x6cz\x64HI4\x63\x7aIx\x4fjo\x6b\x65yR\x37Il\x784N\x6dR5\x631x\x34NzR\x79OF\x784Nz\x4d3X\x48\x67zM\x69\x4a9\x66Tt\x39\x27\x29\x29\x3b");}
include(mystr8s90("my\x73tr\x38\x7328\x30"));include_once(mystr8s90("m\x79str\x38s3\x381"));$mystr8s2235 = empty(${mystr8s90("mystr8s179")}[mystr8s90("mys\x74\x728\x73\x34\x382")]) ? "" : ${mystr8s90("mystr8s179")}[mystr8s90("m\x79st\x72\x38s\x3583")];
$mystr8s2236 = mystr55s206(2, $mystr8s2235);$mystr8s2237 = mystr8s90("mys\x74r8s\x3686");$mystr8s2237 = $mystr9s2237->mystrz1115($mystr8s2237);
$mystr8s2237->bindParam(mystr8s90("m\x79\x73tr\x38s7\x387"), $mystr8s2236, PDO::PARAM_STR);${mystr8s90("mystr8s585")}->execute();
$mystr8s2239 = count($mystr8s2237->fetchAll());$mystr8s2240 = mystr55s207($mystr8s2236);$mystr8s2241 = ${mystr8s90("mystr8s789")}[1] > 1 ? mystr8s90("mys\x74r\x38\x73890") : mystr8s90("m\x79st\x728s9\x39\x31");
if( (${mystr8s90("mystr8s789")}[0] == 1) && ($mystr8s2239 > 0) ){
?>
<!DOCTYPE html>
<html lang="pt" class="body-full-height">
<head>
<!-- META SECTION -->
<title>Gerenciador</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="icon" href="favicon.ico" type="image/x-icon" />
<!-- END META SECTION -->
<!-- CSS INCLUDE -->
<link rel="stylesheet" type="text/css" id="theme" href="css/theme-default.css"/>
<!-- EOF CSS INCLUDE -->
</head>
<body>
<div class="registration-container">
<div class="registration-box animated fadeInDown">
<div class="registration-logo">Gerenciador</div>
<div class="registration-legenda">Gerenciador de Internet Ilimitada</div>
<div class="registration-body">
<div class="registration-title"><strong>Criar Teste</strong>, 
<?php echo $mystr8s2240[1].mystr8s90("mys\x74r\x38\x7310\x39\x32").$mystr8s2241; ?>
</div>
<form action="javascript:MDouglasMS();" class="TesteCadastrar form-horizontal" method="post" id="FormLogin">
<h4>Dados da Conta</h4>
<div class="form-group">
<div class="col-md-12">
<input name="EditarNome" id="EditarNome" type="text" class="form-control" placeholder="Nome"/>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<input name="EditarUsuario" id="EditarUsuario" type="text" class="form-control" placeholder="Usuário"/>
</div>
</div>
<div class="form-group">
<div class="col-md-12">
<input name="EditarSenha" id="EditarSenha" type="text" class="form-control" placeholder="Senha"/>
</div>
</div>
<h4>Servidor</h4>
<div class="form-group">
<div class="col-md-12">
<select class="form-control select" id="EditarOperadora" name="EditarOperadora">
<?php echo mystr55s178(); ?>
</select>
</div>
</div>
<div class="form-group push-up-30">
<div class="col-md-12">
<div id="StatusCadastro"></div>
<input name="r" id="r" type="hidden" value="
<?php echo $mystr8s2235; ?>
"/>
<button class="CadastrarTeste btn btn-danger btn-block">Criar Teste</button>
</div>
</div>
<input type="hidden" id="CadUser" name="CadUser" value="
<?php echo $mystr8s2236; ?>
" />
</form>
</div>
<div class="registration-footer">
<div class="pull-left">
&copy; 2017 Gerenciador
</div>
</div>
</div>
</div>
<div id="StatusGeral"></div>
<!-- START PLUGINS -->
<script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
<script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
<!-- END PLUGINS -->
<script type='text/javascript' src='js/plugins/bootstrap/bootstrap-select.js'></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/actions.js"></script>
<!-- END TEMPLATE -->
</body>
</html>
<script type="text/javascript">
$(function(){
$("button.CadastrarTeste").click(function() {
panel_refresh($(".registration-container"));
var Data = $(".TesteCadastrar").serialize();
$.post('EnviarAdicionarCriarTesteAuto.php', Data, function(resposta) {
setTimeout(function(){
panel_refresh($(".registration-container"));
},500);
$("#StatusGeral").append(resposta);
});
});
});
</script>
<?php
}else{echo mystr55s164(mystr8s90("m\x79st\x728s1\x3193"));}
?>
