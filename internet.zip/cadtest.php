<?php
include("conexao.php");
include_once("functions.php");

//verifica logo
$filelogo = file_get_contents('img/arquivo-logo.txt');
//verifica se o arquivo existe
if (file_exists('img/fundo/'.$filelogo)) { $logo = 'img/fundo/'.$filelogo; } else { $logo = ''; }
###### ler o nome do arquivo de fundo
$filefundo = file_get_contents('img/arquivo-fundo.txt');
//verifica se o arquivo existe
if (file_exists('img/fundo/'.$filefundo)) { $fundo = 'img/fundo/'.$filefundo; } else { $fundo = ''; }
################################# fundo
//verifica se o arquivo existe
if (file_exists('img/arquivo-nome.txt')) { 
    $nomepainel = file_get_contents('img/arquivo-nome.txt');
} else { 
    $nomepainel = 'Painel'; 
}


$GET = empty($_GET['r']) ? "" : $_GET['r'];
$CadUser = UrlTeste(2, $GET);

//Verificar se o revendedor existe
$SQLUrlT = "SELECT login FROM login WHERE login = :login";
$SQLUrlT = $banco->prepare($SQLUrlT);
$SQLUrlT->bindParam(':login', $CadUser, PDO::PARAM_STR);
$SQLUrlT->execute();
$TotalUrldeTeste = count($SQLUrlT->fetchAll());

$VerTeste = VerTeste($CadUser);
$TempoDias = $VerTeste[1] > 1 ? "dias" : "dia";

if( ($VerTeste[0] == 1) && ($TotalUrldeTeste > 0) ){
?>

<!DOCTYPE html>
<html lang="pt" class="body-full-height">
    <head>        
        <!-- META SECTION -->
        <title><?php echo $nomepainel; ?></title>            
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        
        <link rel="icon" href="<?php echo $logo; ?>" type="image/x-icon" />
        <!-- END META SECTION -->
        
        <!-- CSS INCLUDE -->        
        <link rel="stylesheet" type="text/css" id="theme" href="css/theme-dark.css"/>
        <!-- EOF CSS INCLUDE -->  
        <style>
            .registration-container{                
                display: -ms-flexbox;
                display: flex;
                flex-direction: column;
                height: 100vh;                
                justify-content: center;
                background: url(<?php echo $fundo ;?>) no-repeat center center fixed;
                -webkit-background-size: cover;
                -moz-background-size: cover;
                -o-background-size: cover;
                -ms-flex-direction: column;
                -ms-flex-align: center;
                -ms-flex-pack: center;
                background-size: cover;
                overflow: hidden;
            }       
        </style>                             
    </head>
    <body>        
        <div class="registration-container">            
            <div class="registration-box animated fadeInDown">
                <div class="registration-body">
                <center><img src="<?php echo $logo; ?>" width="150px"><br />
                    <div class="registration-title"><strong>Criar Teste</strong>, <?php echo $VerTeste[1]." ".$TempoDias; ?></div></center>
                                        
                    <form action="javascript:MDouglasMS();" class="TesteCadastrar form-horizontal" method="post" id="FormLogin">
                    
                    <div class="form-group">
                        <div class="col-md-12">
                            <input name="EditarNome" id="EditarNome" type="text" class="form-control" placeholder="Nome"/>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-12">
                            <input name="EditarUsuario" id="EditarUsuario" type="text" class="form-control" placeholder="Usuário"/>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-12">
                            <input name="EditarSenha" id="EditarSenha" type="text" class="form-control" placeholder="Senha"/>
                        </div>
                    </div>
                    
                    <h4><center>Servidor</center></h4>
                    
                    <div class="form-group">
                    	<div class="col-md-12">                                        
                        	<select class="form-control select" id="EditarOperadora" name="EditarOperadora">
							<?php echo PerfilAdminEditarTeste(); ?>
                            </select>
                         </div>
                    </div>
                                         
                    <div class="form-group push-up-30">
                        <div class="col-md-12">
                        	<div id="StatusCadastro"></div>
                            <input name="r" id="r" type="hidden" value="<?php echo $GET; ?>"/>
                            <button class="CadastrarTeste btn btn-primary btn-block btn-lg">Criar Teste</button>
                        </div>
                    </div>
                    
                    <input type="hidden" id="CadUser" name="CadUser" value="<?php echo $CadUser; ?>" />
                    
                    </form>
                </div>
                
                </div>
            </div>
            
        </div>
        
        <div id="StatusGeral"></div>  
        
 		 <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>
        <!-- END PLUGINS -->
  
        <script type='text/javascript' src='js/plugins/bootstrap/bootstrap-select.js'></script>        

        
        <script type="text/javascript" src="js/plugins.js"></script>
        <script type="text/javascript" src="js/actions.js"></script>
        <!-- END TEMPLATE -->
      
    </body>
</html>

<script type="text/javascript">
$(function(){  
 $("button.CadastrarTeste").click(function() {
	 
	 	panel_refresh($(".registration-container")); 
  
 		var Data = $(".TesteCadastrar").serialize();
				
		$.post('EnviarAdicionarCriarTesteAuto.php', Data, function(resposta) {
			
				setTimeout(function(){
            		panel_refresh($(".registration-container")); 
        		},500);	
			
				$("#StatusGeral").append(resposta);
		});
	});
});
</script>

<?php
}else{
	echo Redirecionar('login.php');
}
?>





