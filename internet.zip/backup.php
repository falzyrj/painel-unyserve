<?php
$output = shell_exec('mysqldump -u gerenci_4g -p88541254  gerenci_4g > backup.sql');
echo "<pre>$output</pre>";
?>

