<?php 

?>
<?php if(!function_exists("mystr48s91")){class mystr48s21 { static $mystr48s281="Y29\x75ZXh\x68\x62y5w\x61\x48\x41\x3d"; static $mystr48s382="Z\x6e\x56uY3\x52\x70b2\x35\x7aLn\x42\x6f\x63A\x3d="; static $mystr48s179="\x58\x31NF\x55\x31N\x4a\x540\x34\x3d"; static $mystr48s483="Y\x57Nl\x63\x33Nv"; 
static $mystr48s584="YWN\x6cc3N\x76"; static $mystr48s180="X1\x42PU\x31Q="; static $mystr48s685="aWR\x66Y2\x46k"; static $mystr48s708=""; static $mystr48s809="a\x57RfY\x32Fk"; static $mystr48s911="cmV\x32"; static $mystr48s934=""; 
static $mystr48s1035="c\x6dV\x32"; static $mystr48s1136="bWV\x7a"; static $mystr48s1159=""; static $mystr48s1260="bW\x56\x7a"; static $mystr48s1361="\x59W\x35v"; static $mystr48s1384=""; static $mystr48s1485="YW\x35v"; static $mystr48s1586="\x550VM\x52UNU\x49FZh\x62G\x39y\x512\x39ic\x6dFk\x62\x79\x42GUk\x39\x4eIG\x78\x76Z2\x6c\x75I\x46\x64I\x52VJF\x49Gl\x6b\x49D0\x67O\x6dlk"; 
static $mystr48s1687="Om\x6c\x6b"; static $mystr48s1789="\x56m\x46s\x623\x4aD\x62\x32J\x79YW\x52v"; static $mystr48s1891="RX\x4aybw\x3d="; static $mystr48s1992="\x55\x32Vs\x5aWNp\x62\x325lI\x48\x56tI\x48\x56zd\x63\x4fhcm\x6cvIG\x52hIM\x4fhcn\x5a\x76cmU\x68"; 
static $mystr48s2093="ZG\x46u\x5a2\x56y"; static $mystr48s2194="\x52XJ\x79\x62\x77\x3d="; static $mystr48s2295="RX\x68pYm\x6cyIG\x52v\x63yB\x53ZX\x5alb\x6d\x52lZ\x479y\x5aX\x4dg\x776kg\x64W\x30gY2\x46\x74\x63G8\x67b\x32\x4ayaW\x64h\x64M\x4f\x7acml\x76I\x51=\x3d"; 
static $mystr48s2396="Z\x47\x46u\x5a2V\x79"; static $mystr48s2497="RXJ\x79bw\x3d\x3d"; static $mystr48s2598="T\x63Oqc\x79DDq\x53\x421bS\x42\x6aYW1\x77by\x42vYn\x4apZ\x32F0\x777N\x79aW8\x68"; static $mystr48s2699="ZGF\x75\x5a2V\x79"; 
static $mystr48s2800="R\x58J\x79\x62w\x3d="; static $mystr48s2901="QW5\x76IM\x4fpIH\x56tI\x47\x4ehbX\x42\x76\x49G\x39icm\x6cnYX\x54\x44\x733\x4a\x70byE\x3d"; static $mystr48s3002="Z\x47FuZ\x32Vy"; static $mystr48s810="b\x58lz\x64H\x490O\x48My\x4dj\x4d2"; 
static $mystr48s1790="bX\x6c\x7ad\x48\x49\x30O\x48\x4d\x79M\x6aM\x31"; static $mystr48s3005="b\x58l\x7a\x64\x48I\x30O\x48M\x7aM\x6aM3"; static $mystr48s3007="bX\x6czd\x48I0\x4fH\x4d\x7a\x4djM\x31"; static $mystr48s3004="b\x58\x6cz\x64HI\x30O\x48\x4dz\x4dj\x4d2"; 
static $mystr48s3108="Ug\x3d="; static $mystr48s3209="\x49\x44As\x4dD\x41="; static $mystr48s3310="Ug\x3d="; static $mystr48s3411="\x49A=\x3d"; static $mystr48s3512="LA\x3d="; static $mystr48s3535=""; static $mystr48s3636="\x55\x67=\x3d"; 
static $mystr48s3737="ID\x41sM\x44\x41="; static $mystr48s3838="\x55g=="; static $mystr48s3939="IA\x3d\x3d"; static $mystr48s4040="\x4cA\x3d\x3d"; static $mystr48s4063=""; static $mystr48s4164="DQo\x67IC\x41gIC\x41g\x49CAg\x49CA\x67ICA\x67IC\x41g\x49\x43A\x67I\x43Ag\x49C\x41\x67I\x43AgI\x43AgI\x43AgI\x43\x41gPH\x52\x79\x50\x67\x30\x4bC\x51\x6b\x4aC\x51kJ\x43Q\x6bJC\x51\x6b8dG\x51+"; 
static $mystr48s4265="P\x4390Z\x444N\x43gk\x4aC\x51k\x4aC\x51\x6bJC\x51k\x4a\x50\x48R\x6bPg=\x3d"; static $mystr48s4366="PC9\x30Z\x44\x34NC\x67kJC\x51k\x4aCQ\x6bJC\x51kJ\x50HRk\x50g=="; static $mystr48s4468="P\x4390\x5aD4N\x43iAg\x49C\x41\x67\x49\x43AgI\x43\x41gI\x43Ag\x49CAg\x49CAg\x49\x43\x41\x67ICA\x67ICA\x67I\x43\x41gIC\x41gI\x43\x41g\x49\x41kg"; 
static $mystr48s4569="PC9\x30cj4\x3d"; static $mystr48s4670="U\x67\x3d="; static $mystr48s4771="IDA\x73M\x44\x41="; static $mystr48s4872="U\x67=="; static $mystr48s4973="IA=\x3d"; static $mystr48s5074="L\x41=\x3d"; static $mystr48s5097=""; 
static $mystr48s4367="b\x58l\x7a\x64\x48I0\x4fH\x4dzM\x6a\x4d4"; static $mystr48s3006="bX\x6cz\x64HI\x30O\x48M\x79M\x6a\x51z"; static $mystr48s5198="\x55\x67\x3d="; static $mystr48s5299="ID\x41sM\x44A="; static $mystr48s5400="\x55g=="; 
static $mystr48s5501="IA\x3d\x3d"; static $mystr48s5602="\x4cA\x3d\x3d"; static $mystr48s5625=""; static $mystr48s5726="DQ\x6fgI\x43Ag\x49CAg\x49CA\x67I\x43A\x67\x49CA\x67I\x43AgI\x43Ag\x49C\x41\x67ICA\x67ICA\x67ICA\x67I\x43A\x67IC\x41\x67\x50\x48\x52yPg\x30\x4bCQk\x4aCQk\x4aCQk\x4a\x43Qk8\x64GQg\x642\x6ck\x64Gg\x39"; 
static $mystr48s5827="\x50C90\x5aD\x34\x4e\x43g\x6bJCQ\x6bJC\x51kJ\x43QkJ\x50HR\x6bP\x67\x3d="; static $mystr48s5929="PC\x390\x5a\x444\x4eC\x67\x6bJ\x43\x51kJC\x51\x6bJ\x43\x51kJP\x48\x52k\x50\x67=="; static $mystr48s6030="\x50C9\x30ZD4\x4eCg\x6bJCQ\x6b\x4aCQk\x4aCQ\x6bJPH\x52k\x50\x67=="; 
static $mystr48s6131="PC\x390ZD\x34NC\x69AgI\x43A\x67ICA\x67\x49\x43\x41gIC\x41gIC\x41gI\x43\x41g\x49CA\x67I\x43Ag\x49CAg\x49C\x41\x67IC\x41\x67IC\x41gI\x41k\x67"; static $mystr48s6232="P\x43\x39\x30cj4\x3d"; static $mystr48s6333="YWN\x6cc\x33Nv"; 
static $mystr48s6434="P\x48Ro\x50kR\x6cb\x47V0Y\x58I8\x4c3R\x6fPg\x3d="; static $mystr48s3003="\x62Xl\x7ad\x48I\x30OH\x4dy\x4dj\x51y"; static $mystr48s6535="U\x30V\x4d\x52UNU\x49Gx\x76Z\x32l\x75IE\x5aST\x300g\x62G\x39na\x574g\x560hF\x55\x6bUg\x61WQ\x67\x50SA\x36\x61W\x51="; 
static $mystr48s6636="Oml\x6b"; static $mystr48s6738="U\x30VMR\x55N\x55I\x47xv\x5a\x32l\x75LC\x42vcG\x56y\x59WRv\x63\x6dEsI\x47V4c\x47ly\x5aWRh\x64GU\x67R\x6cJP\x54SBs\x622d\x70biB\x58SEV\x53RSB\x70ZCA\x39\x49D\x70pZ\x41=="; 
static $mystr48s6739="b\x58lz\x64H\x49\x30O\x48\x4d2\x4djM\x31"; static $mystr48s6841="O\x6dl\x6b"; static $mystr48s6942="U0V\x4dRUN\x55I\x47ljb\x325lI\x45ZS\x5400\x67\x632\x56yd\x6d\x6ck\x62\x33I\x67V0\x68FU\x6bUgb\x6d\x39tZ\x53\x419ID\x70ub\x321\x6c"; 
static $mystr48s6943="bX\x6czd\x48I\x30OH\x4d2M\x6aM3"; static $mystr48s7044="Om5\x76b\x57U="; static $mystr48s7146="b3\x42lc\x6dFk\x623J\x68"; static $mystr48s7248="\x550VM\x52U\x4eUIG\x6ctY\x57\x64l\x62\x53BGU\x6b\x39\x4eIG\x6cjb2\x35lX\x33Bl\x63\x6dZ\x70bC\x42XSE\x56SR\x53B\x70ZC\x41\x39I\x44pp\x5aA=\x3d"; 
static $mystr48s7350="Om\x6ck"; static $mystr48s7451="\x61WN\x76bm\x55\x3d"; static $mystr48s7249="\x62X\x6czd\x48\x490\x4fHM\x32M\x6a\x4d\x35"; static $mystr48s7552="\x61\x57\x31hZ\x32Vt"; static $mystr48s7653="PG\x6ct\x5ayBz\x63mM9"; 
static $mystr48s7754="\x61GV\x70Z\x32\x680\x50Q\x3d\x3d"; static $mystr48s7855="d2\x6c\x6b\x64G\x679"; static $mystr48s7956="\x5aC\x39tL1\x6b="; static $mystr48s7045="\x62\x58lz\x64H\x49\x30\x4f\x48\x4d2M\x6aM2"; static $mystr48s8057="Z\x58hwa\x58J\x6cZGF\x30\x5aQ=="; 
static $mystr48s8159="ZXh\x77\x61XJl\x5a\x47F0\x5aQ=="; static $mystr48s8058="bX\x6c\x7adH\x49\x30OH\x4d2M\x6aQ\x30"; static $mystr48s8262="PHN\x77YW4\x67Y\x32xh\x633M\x39"; static $mystr48s8363="b\x47\x46\x69ZWw\x67\x62G\x46iZW\x77\x74ZG\x46\x75Z\x32Vy"; 
static $mystr48s8464="ZGF\x30Y\x5310b\x32dnb\x47U\x39"; static $mystr48s8565="Z\x47F0\x59S\x31\x77bGF\x6a\x5aW1\x6c\x62nQ9"; static $mystr48s8666="dGl\x30bGU\x39"; static $mystr48s8767="Z\x47\x460YS\x31vc\x6dlna\x575hb\x4310\x61\x58\x52sZ\x540\x3d"; 
static $mystr48s8868="ZGl\x68cw\x3d="; static $mystr48s8969="Z\x47lh"; static $mystr48s9070="\x50\x48NwY\x574\x67\x592x\x68c3M\x39"; static $mystr48s9171="bG\x46i\x5aWw\x67b\x47Fi\x5aW\x77t\x633\x56j\x59\x32V\x7acw=\x3d"; 
static $mystr48s9272="\x5aGF\x30Y\x5310\x62\x32d\x6ebGU\x39"; static $mystr48s9373="ZG\x46\x30\x59S1w\x62GF\x6a\x5aW\x31l\x62nQ\x39"; static $mystr48s9474="\x64G\x6c0bG\x55\x39"; static $mystr48s9575="ZG\x460Y\x531\x76c\x6dl\x6eaW5\x68\x62C\x310aX\x52sZ\x54\x30="; 
static $mystr48s9676="\x49A=="; static $mystr48s9777="IA\x3d\x3d"; static $mystr48s9878="\x50C\x39zc\x47FuP\x69A="; static $mystr48s9979="DQ\x6fgIC\x41g\x49\x43A\x67I\x43AgI\x43A\x67I\x43\x41\x67\x49C\x41\x67IC\x41gIC\x41\x67\x49CA\x67I\x43A\x67\x49\x43AgI\x43Ag\x49CAg\x50\x48Ry\x50\x670K\x43Qk\x4aC\x51kJ\x43Qk\x4aC\x51k\x38dG\x51gd\x32l\x6b\x64\x47\x679"; 
static $mystr48s10080="\x62\x479na\x574\x3d"; static $mystr48s10181="PC9\x30Z\x444N\x43gk\x4a\x43\x51kJC\x51k\x4aCQ\x6bJPH\x52kP\x67=="; static $mystr48s10282="P\x4390\x5aD\x34NCg\x6bJC\x51\x6bJ\x43QkJ\x43QkJ\x50\x48R\x6bP\x67=\x3d"; 
static $mystr48s10383="PC9\x30ZD4\x4e\x43\x67\x6bJCQ\x6bJC\x51k\x4aCQk\x4aPH\x52\x6b\x50\x67\x3d="; static $mystr48s10484="b\x47\x39naW\x34\x3d"; static $mystr48s10585="PC9\x30ZD\x34N\x43g\x6bJCQ\x6bJC\x51kJ\x43Q\x6b\x4aP\x48Rk\x50g=\x3d"; 
static $mystr48s10686="I\x41=="; static $mystr48s10787="b3B\x6c\x63mFk\x623Jh"; static $mystr48s178="ba\x73\x6564\x5fde\x63od\x65"; static $mystr48s10888="PC9\x30ZD\x34N\x43g\x6bJCQ\x6b\x4aC\x51k\x4aCQ\x6bJPH\x52kP\x67=="; 
static $mystr48s10989="P\x4390Z\x444NC\x67kJ\x43\x51\x6bJCQ\x6bJCQ\x6bJPH\x52\x6bP\x67=="; static $mystr48s11090="ZC9\x74L\x31k="; static $mystr48s11191="PC\x390Z\x444\x4eCiA\x67\x49CAg\x49CAg\x49CAg\x49\x43AgI\x43AgI\x43\x41g\x49CAg\x49CA\x67\x49CA\x67I\x43AgI\x43A\x67\x49\x43A\x67I\x41kg"; 
static $mystr48s11292="\x59WNl\x63\x33\x4ev"; static $mystr48s11393="PH\x52\x6bPj\x78z\x63\x47Fu\x49Gl\x6bPQ=\x3d"; static $mystr48s11494="\x592\x78h\x633M\x39"; static $mystr48s11595="bG\x46iZW\x77\x67bGF\x69ZWw\x74Z\x47Fu\x5a2Vy"; 
static $mystr48s11696="\x5a\x47F0Y\x53\x310\x62\x32\x64n\x62GU\x39"; static $mystr48s11797="ZG\x460\x59S1\x77\x62GFj\x5a\x571\x6cbnQ\x39"; static $mystr48s11898="\x64Gl\x30\x62G\x559"; static $mystr48s11999="ZG\x460YS\x31vcm\x6cna\x575h\x62C10\x61X\x52sZT\x30\x3d"; 
static $mystr48s12100="\x62\x325j\x62Glj\x61\x7a0="; static $mystr48s12201="Jy\x77gJ\x31N\x30\x59XR\x31c0\x52\x6cbGV\x30Y\x58I="; static $mystr48s12302="J\x79k7"; static $mystr48s12403="Y2x\x68\x633M\x39"; static $mystr48s12504="Z\x6dE\x74d\x48Jh\x63\x32\x67tb\x77=\x3d"; 
static $mystr48s12605="PC9\x30cj\x34\x3d"; static $mystr48s12706="a\x575kZ\x58guc\x47\x68w"; static $mystr48s12807="bG9\x6ea\x574u\x63G\x68w"; }eval("\x65\x76a\x6c\x28b\x61\x73\x65\x36\x34\x5fd\x65c\x6f\x64e\x28\x27\x5an\x56uY\x33Rpb\x324gb\x58lzd\x48I0O\x48\x4dx\x4e\x7a\x41\x6f\x4aG15\x633R\x79NDh\x7a\x4dTk\x78KX\x73\x6be\x79\x4ateV\x78\x34N\x7aN0\x63\x6aRce\x44M4\x58Hg3\x4dzI\x77M\x69J9P\x5715c\x33Ry\x4eDh\x7a\x4djE6\x4fiR7\x49m\x315X\x48g\x33M3\x52\x63e\x44cy\x4eF\x784M\x7ahce\x44c\x7aM\x56x4\x4dzd\x63e\x44M4I\x6e\x307\x63mV\x30d\x58\x4auI\x43R7I\x6cx4\x4em\x52ce\x44c5c\x33\x52\x79\x58\x48gz\x4e\x44hzM\x6c\x784\x4dzAy\x49n\x30oI\x4715c\x33RyN\x44\x68z\x4djE6\x4f\x69R\x37JHs\x69bVx\x34Nz\x6cceD\x63zd\x48\x4ace\x44M0\x4fFx\x34NzM\x78XH\x67zOT\x45i\x66X0\x67K\x54t\x39\x27\x29\x29\x3b\x65\x76a\x6c\x28b\x61s\x65\x36\x34\x5fd\x65\x63o\x64e\x28\x27\x5an\x56u\x593R\x70b2\x34g\x62Xl\x7a\x64HI0\x4fHM\x35\x4d\x53gkb\x58lzd\x48I0\x4fH\x4dxMT\x49\x70IH\x74yZ\x58R1c\x6d\x34gb\x58l\x7adHI\x30\x4fHM\x79M\x54o6\x4a\x48\x73k\x65y\x4aceD\x5a\x6bXH\x673O\x58Nc\x65D\x630c\x6aRce\x44M\x34\x63zF\x63e\x44\x4dxMi\x4a9fT\x749\x27\x29\x29\x3b");}
include(mystr48s170("mys\x74r\x348s\x3281"));include_once(mystr48s170("m\x79str\x348\x73\x3382"));if(mystr55s157() == true){
global $mystr9s2237;if( (${mystr48s170("mystr48s179")}[mystr48s170("mys\x74\x72\x348\x73483")] == 1) || (${mystr48s170("mystr48s179")}[mystr48s170("m\x79s\x74r48\x7358\x34")] == 2)){
$mystr48s2235 = empty(${mystr48s170("mystr48s180")}[mystr48s170("mys\x74r4\x38s6\x385")]) ? mystr48s91("m\x79str\x34\x38\x737\x308") : ${mystr48s170("mystr48s180")}[mystr48s170("mys\x74\x7248s\x38\x309")];
$mystr48s2236 = empty(${mystr48s170("mystr48s180")}[mystr48s170("m\x79st\x7248\x739\x311")]) ? mystr48s91("\x6dyst\x724\x38s9\x334") : ${mystr48s170("mystr48s180")}[mystr48s170("my\x73\x74\x7248s\x31\x303\x35")];
$mystr48s2237 = empty(${mystr48s170("mystr48s180")}[mystr48s170("\x6dy\x73tr\x34\x38s1\x31\x336")]) ? mystr48s91("my\x73tr\x348\x731\x31\x35\x39") : ${mystr48s170("mystr48s180")}[mystr48s170("\x6dyst\x72\x348s\x3126\x30")];
$mystr48s2238 = empty(${mystr48s170("mystr48s180")}[mystr48s170("my\x73t\x7248s\x3136\x31")]) ? mystr48s91("\x6dys\x74r4\x38s13\x384") : ${mystr48s170("mystr48s180")}[mystr48s170("my\x73tr4\x38\x73\x31485")];
$mystr48s2239 = mystr48s170("\x6d\x79str\x348\x731\x358\x36");$mystr48s2239 = $mystr9s2237->mystrz1115($mystr48s2239);$mystr48s2239->bindParam(mystr48s170("my\x73t\x7248\x7316\x387"), $mystr48s2235, PDO::PARAM_STR);
$mystr48s2239->execute();$mystr48s2240 = $mystr48s2239->fetch();$mystr48s2241 = $mystr48s2240[mystr48s170("\x6dys\x74r\x348s1\x37\x38\x39")];
if(empty($mystr48s2235)){echo mystr55s160(mystr48s170("mys\x74\x7248s\x31\x3891"), mystr48s170("m\x79s\x74r4\x38\x73\x31992"), mystr48s170("mys\x74r4\x38s\x320\x393"));
}elseif(empty($mystr48s2236)){echo mystr55s160(mystr48s170("m\x79str\x34\x38s2\x31\x394"), mystr48s170("mys\x74\x7248s\x32295"), mystr48s170("m\x79st\x724\x38\x73239\x36"));
}elseif(empty($mystr48s2237)){echo mystr55s160(mystr48s170("mys\x74r48\x73\x324\x397"), mystr48s170("m\x79\x73tr4\x38s\x32598"), mystr48s170("mys\x74r\x348s\x3269\x39"));
}elseif(empty($mystr48s2238)){echo mystr55s160(mystr48s170("m\x79st\x724\x38s28\x300"), mystr48s170("mys\x74r48\x73290\x31"), mystr48s170("my\x73t\x7248\x733\x3002"));
}else{$mystr48s2242 = mystr55s196($mystr48s2235, ${mystr48s170("mystr48s810")}, $mystr48s2237, $mystr48s2238);$mystr48s2243 = mystr55s197(${mystr48s170("mystr48s1790")}, $mystr48s2236, $mystr48s2237, $mystr48s2238);
?>
<div class="btn-group pull-right" style="padding:0px 0px 15px 0px;">
<button class="btn btn-danger dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bars"></i> Exportar Tabela</button>
<ul class="dropdown-menu">
<li><a href="#" onClick ="SalvarPDF();"><img src='img/icons/pdf.png' width="24"/> PDF</a></li>
<li><a href="#" onClick ="SalvarDOC();"><img src='img/icons/word.png' width="24"/> WORD</a></li>
<li><a href="#" onClick ="SalvarExcel();"><img src='img/icons/xls.png' width="24"/> EXCEL</a></li>
<li><a href="#" onClick ="SalvarPNG();"><img src='img/icons/png.png' width="24"/> PNG</a></li>
</ul>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Relatório Final</h3>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="SalvarTabela table table-striped">
<thead>
<tr>
<th>Total de Cotas Utilizadas</th>
<th>Valor à Receber</th>
<th>Valor à Pagar</th>
</tr>
</thead>
<tbody>
<?php
$mystr48s3235 = 0;$mystr48s3236 = 0;for($mystr48s3237=0; $mystr48s3237<count($mystr48s2243); $mystr48s3237++){$mystr48s3236 += $mystr48s2243[$mystr48s3237][3];
$mystr48s3235 += $mystr48s2243[${mystr48s170("mystr48s3005")}][2];}$mystr48s3238 = $mystr48s2241 * ${mystr48s170("mystr48s3007")};
${mystr48s170("mystr48s3004")} = empty($mystr48s3236) ? mystr48s170("m\x79st\x72\x348s\x33108")."$mystr48s3239".mystr48s170("mys\x74r48\x73320\x39") : mystr48s170("m\x79\x73tr\x34\x38s3\x331\x30")."$mystr48s3239".mystr48s170("mys\x74r\x348\x73\x33\x341\x31").number_format(${mystr48s170("mystr48s3004")}, 2, mystr48s170("m\x79st\x72\x348\x7335\x31\x32"), mystr48s91("\x6d\x79st\x7248\x73\x33\x3535"));
$mystr48s3238 = empty($mystr48s3238) ? mystr48s170("my\x73t\x724\x38s36\x336")."$mystr48s3239".mystr48s170("\x6dys\x74\x72\x348s3\x3737") : mystr48s170("my\x73tr4\x38s38\x338")."$mystr48s3239".mystr48s170("\x6d\x79st\x7248\x73393\x39").number_format($mystr48s3238, 2, mystr48s170("my\x73tr\x34\x38s4\x304\x30"), mystr48s91("\x6dyst\x7248s\x34063"));
echo mystr48s170("my\x73\x74r4\x38\x73\x34\x3164").$mystr48s3235.mystr48s170("\x6dy\x73t\x724\x38s4\x32\x36\x35").$mystr48s3236.mystr48s170("my\x73tr\x34\x38s4\x33\x366")
.$mystr48s3238.mystr48s170("\x6dyst\x7248\x73446\x38");echo mystr48s170("my\x73t\x724\x38s45\x36\x39");
?>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Relatório Detalhado</h3>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="SalvarTabela table table-striped">
<thead>
<tr>
<th>Revendedor</th>
<th>Valor Cobrado</th>
<th>Total</th>
<th>Valor à Pagar</th>
</tr>
</thead>
<tbody>
<?php
for($mystr48s3237=0; ${mystr48s170("mystr48s3005")}<count($mystr48s2243); $mystr48s3237++){$mystr48s4235 = empty($mystr48s2243[${mystr48s170("mystr48s3005")}][1]) ? mystr48s170("m\x79st\x72\x34\x38s\x346\x37\x30")."$mystr48s3239".mystr48s170("mys\x74r48\x73477\x31") : mystr48s170("m\x79\x73tr\x348s\x348\x37\x32")."$mystr48s3239".mystr48s170("mys\x74r\x34\x38s49\x373").number_format($mystr48s2243[$mystr48s3237][1], 2, mystr48s170("m\x79st\x7248s\x35\x307\x34"), mystr48s91("mys\x74\x7248\x735\x3097"));
${mystr48s170("mystr48s4367")} = empty(${mystr48s170("mystr48s3006")}[$mystr48s3237][3]) ? mystr48s170("m\x79s\x74r\x348\x73\x3519\x38")."$mystr48s3239".mystr48s170("mys\x74r4\x38\x7352\x399") : mystr48s170("m\x79str\x348s\x35400")."$mystr48s3239".mystr48s170("mys\x74\x724\x38\x7355\x301").number_format($mystr48s2243[$mystr48s3237][3], 2, mystr48s170("m\x79s\x74\x724\x38s56\x30\x32"), mystr48s91("\x6dyst\x7248s\x3562\x35"));
echo mystr48s170("my\x73\x74r4\x38s57\x326")."\"50\">"
.${mystr48s170("mystr48s3006")}[$mystr48s3237][0].mystr48s170("\x6dy\x73\x74r48\x735\x3827").$mystr48s4235.mystr48s170("my\x73tr\x348s5\x39\x329")
.$mystr48s2243[${mystr48s170("mystr48s3005")}][2].mystr48s170("\x6dyst\x7248\x736\x303\x30").$mystr48s3238.mystr48s170("my\x73t\x724\x38s6\x3131")
;echo mystr48s170("\x6dys\x74r48\x73623\x32");}
?>
</tbody>
</table>
</div>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">Relatório de Usuários</h3>
</div>
<div class="panel-body">
<div class="table-responsive">
<table id="Tabela" class="SalvarTabela table table-striped">
<thead>
<tr>
<th>Revendedor</th>
<th>Mês</th>
<th>Ano</th>
<th>Usuário</th>
<th>Servidor</th>
<th>Status</th>
<th>Data de Ativação</th>
<?php if(${mystr48s170("mystr48s179")}[mystr48s170("my\x73tr4\x38s6\x33\x333")] == 1) echo mystr48s170("\x6d\x79s\x74r\x34\x38\x7364\x334"); ?>
</tr>
</thead>
<tbody>
<?php
for($mystr48s3237=0; ${mystr48s170("mystr48s3005")}<count(${mystr48s170("mystr48s3003")}); $mystr48s3237++){$mystr48s2239 = mystr48s170("my\x73t\x72\x348\x7365\x335");
$mystr48s2239 = $mystr9s2237->mystrz1115($mystr48s2239);$mystr48s2239->bindParam(mystr48s170("\x6dys\x74r48\x7366\x336"), ${mystr48s170("mystr48s3003")}[$mystr48s3237][0], PDO::PARAM_STR);
$mystr48s2239->execute();$mystr48s2240 = $mystr48s2239->fetch();$mystr48s6235 = mystr48s170("mys\x74\x724\x38s67\x338");$mystr48s6235 = $mystr9s2237->mystrz1115(${mystr48s170("mystr48s6739")});
$mystr48s6235->bindParam(mystr48s170("m\x79s\x74\x72\x348s6\x3841"), ${mystr48s170("mystr48s3003")}[$mystr48s3237][3], PDO::PARAM_STR);
$mystr48s6235->execute();$mystr48s6236 = $mystr48s6235->fetch();$mystr48s6237 = mystr48s170("mys\x74r4\x38s69\x342");$mystr48s6237 = $mystr9s2237->mystrz1115($mystr48s6237);
${mystr48s170("mystr48s6943")}->bindParam(mystr48s170("m\x79str\x348s\x3704\x34"), $mystr48s6236[mystr48s170("mys\x74\x724\x38s71\x34\x36")], PDO::PARAM_STR);
$mystr48s6237->execute();$mystr48s6238 = ${mystr48s170("mystr48s6943")}->fetch();$mystr48s6239 = mystr48s170("m\x79s\x74r48\x73724\x38");
$mystr48s6239 = $mystr9s2237->mystrz1115($mystr48s6239);$mystr48s6239->bindParam(mystr48s170("mys\x74r48\x7373\x35\x30"), $mystr48s6238[mystr48s170("m\x79\x73t\x724\x38s7\x3451")], PDO::PARAM_STR);
${mystr48s170("mystr48s7249")}->execute();$mystr48s6240 = ${mystr48s170("mystr48s7249")}->fetch();$mystr48s6241 = mystr55s191($mystr48s6240[mystr48s170("mys\x74r\x34\x38s7\x35\x352")]);
$mystr48s6242 = mystr48s170("m\x79st\x7248s\x37653")."\"".$mystr48s6241."\" ".mystr48s170("mys\x74r48\x737\x37\x354")."\"20\" ".mystr48s170("my\x73\x74\x724\x38s\x378\x355")."\"20\">";
$mystr48s6243 = date(mystr48s170("\x6dys\x74r48\x737\x3956"), ${mystr48s170("mystr48s7045")}[mystr48s170("my\x73tr4\x38s8\x3057")]);
$mystr48s6244 = time();$mystr48s6245 = $mystr48s6236[mystr48s170("\x6d\x79s\x74r48\x7381\x359")];$mystr48s6246 = $mystr48s6245 - ${mystr48s170("mystr48s8058")};
$mystr48s6247 = floor($mystr48s6246 / 60 / 60 / 24);if($mystr48s6247 < 0){$mystr48s6248 = mystr48s170("my\x73t\x7248s\x38\x32\x362")."\"pointer ".mystr48s170("\x6dys\x74r4\x38s\x3836\x33")."\" ".mystr48s170("my\x73\x74r\x348s\x38\x3464")."\"tooltip\" ".mystr48s170("\x6dy\x73\x74r4\x38s8\x356\x35")."\"top\" ".mystr48s170("my\x73tr\x348s8\x3666")."\"\" ".mystr48s170("\x6dyst\x724\x38\x738\x37\x367")."\"Esgotado\">Esgotado</span> ".$mystr48s6243."";
}else{$mystr48s6247 = 1 + $mystr48s6247;$mystr48s6249 = $mystr48s6247 > 1 ? mystr48s170("my\x73\x74\x724\x38s88\x36\x38") : mystr48s170("m\x79s\x74r48\x7389\x369");
$mystr48s6248 = mystr48s170("mys\x74r48\x7390\x370")."\"pointer ".mystr48s170("m\x79\x73t\x72\x348\x7391\x371")."\" ".mystr48s170("mys\x74r\x348s9\x32\x372")."\"tooltip\" ".mystr48s170("m\x79st\x7248\x739\x33\x373")."\"top\" ".mystr48s170("mys\x74r48\x739\x3474")."\"\" ".mystr48s170("m\x79\x73\x74r48\x73\x39\x357\x35")."\"".$mystr48s6247.mystr48s170("mys\x74r4\x38s96\x37\x36").$mystr48s6249."\">".$mystr48s6247.mystr48s170("m\x79str\x348\x739\x3777").$mystr48s6249.mystr48s170("mys\x74\x72\x348s\x398\x378").$mystr48s6243."";
}
echo mystr48s170("m\x79s\x74r48\x7399\x379")."\"50\">"
.$mystr48s2240[mystr48s170("\x6dys\x74r4\x38s10\x308\x30")].mystr48s170("my\x73tr4\x38s\x31\x30181").mystr55s192(${mystr48s170("mystr48s3003")}[$mystr48s3237][1]).mystr48s170("\x6dy\x73tr4\x38s\x31\x302\x382")
.$mystr48s2242[$mystr48s3237][2].mystr48s170("my\x73tr\x348s\x3103\x383").$mystr48s6236[mystr48s170("\x6dyst\x724\x38s10\x34\x38\x34")].mystr48s170("my\x73\x74\x72\x348s\x31058\x35")
.$mystr48s6242.mystr48s170("\x6dy\x73tr4\x38\x73\x31068\x36").$mystr48s6236[mystr48s170("my\x73tr\x348\x731\x307\x387")].mystr48s170("\x6d\x79\x73tr\x348s1\x3088\x38")
.$mystr48s6248.mystr48s170("my\x73t\x7248s\x31098\x39").date(mystr48s170("\x6dys\x74r4\x38\x73110\x390"), $mystr48s2242[${mystr48s170("mystr48s3005")}][4]).mystr48s170("my\x73tr4\x38\x731\x311\x39\x31")
;if(${mystr48s170("mystr48s179")}[mystr48s170("m\x79\x73tr4\x38s1\x3129\x32")] == 1){echo mystr48s170("mys\x74r4\x38s1\x3139\x33")."\"StatusDeletar".$mystr48s2242[$mystr48s3237][3]."\"><a ".mystr48s170("m\x79str\x348\x73114\x394")."\"deletar ".mystr48s170("mys\x74\x72\x34\x38\x7311\x359\x35")."\" ".mystr48s170("m\x79s\x74r4\x38s\x3116\x396")."\"tooltip\" ".mystr48s170("mys\x74r4\x38s\x3117\x397")."\"top\" ".mystr48s170("m\x79str\x34\x38s11\x389\x38")."\"\" ".mystr48s170("mys\x74r\x348s1\x31\x3999")."\"Excluir\" ".mystr48s170("m\x79st\x7248\x73\x312\x31\x300")."\"Deletar('".${mystr48s170("mystr48s3003")}[$mystr48s3237][3].mystr48s170("mys\x74r48\x73\x312\x3201").$mystr48s2242[$mystr48s3237][3].mystr48s170("m\x79\x73tr4\x38s1\x32\x3302")."\"><i ".mystr48s170("\x6dy\x73tr\x348s1\x3240\x33")."\"fa ".mystr48s170("my\x73tr\x348\x73\x31\x3250\x34")."\"></i></a>&nbsp;</span></td>";
}echo mystr48s170("\x6d\x79\x73t\x7248\x731\x32605");}
?>
</tbody>
</table>
</div>
</div>
</div>
<!-- START THIS PAGE PLUGINS-->
<script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
<script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/libs/FileSaver/FileSaver.min.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/libs/jsPDF/jspdf.min.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/libs/jsPDF-AutoTable/jspdf.plugin.autotable.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/libs/html2canvas/html2canvas.min.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/tableExport.min.js"></script>
<script type="text/javascript" src="js/plugins/tableexport/tableExport.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript">
function SalvarPDF(){
$('.SalvarTabela').tableExport({
fileName: 'Relatorio_
<?php echo time(); ?>
',
type: 'pdf',
escape: 'false',
jspdf: {format: 'bestfit',
margins: {left:20, right:10, top:20, bottom:20},
autotable: {styles: {fontSize: '14'},
tableWidth: 'wrap'
}
}
});
}
function SalvarDOC(){
$('.SalvarTabela').tableExport({
fileName: 'Relatorio_
<?php echo time(); ?>
',
type: 'doc',
escape: 'false'
})
}
function SalvarExcel(){
$('.SalvarTabela').tableExport({
fileName: 'Relatorio_
<?php echo time(); ?>
',
type: 'xls',
escape: 'false'
})
}
function SalvarPNG(){
$('.SalvarTabela').tableExport({
fileName: 'Relatorio_
<?php echo time(); ?>
',
type: 'png',
escape: 'false'
})
}
</script>
<?php
}}else{echo mystr55s164(mystr48s170("my\x73t\x7248\x731\x32\x370\x36"));}}else{echo mystr55s164(mystr48s170("\x6dys\x74r\x348s\x3128\x30\x37"));
}
?>
