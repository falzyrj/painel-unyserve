<?php
include("conexao.php");
include_once("functions.php");
if(ProtegePag() == true)
global $banco;
?>
<!-- START BREADCRUMB -->
<ul class="breadcrumb">
                    <li class="active"></span>&#160;Olá&#160;<strong><?php echo $_SESSION['nome']?></strong>&#160; Você estar no painel de atualização</li>
                </ul>
                <!-- END BREADCRUMB --> 
                
                <!-- PAGE TITLE -->
          <div class="page-title">                    
          
          </div>
                <!-- END PAGE TITLE -->   
 
                <!-- PAGE CONTENT WRAPPER -->
                <div class="page-content-wrap">                
                
                    <div class="row">
                        <div class="col-md-12">                    
                        <div class="panel panel-default">
                                <div class="panel-heading">
     
    <h2><span class="fa fa-align-left"></span>&nbsp; Painel de atualização</h2>
    </div> 
    <iframe style="border: none;" src="update" width="100%" height="900px"  frameborder="0"></iframe>
<!-- PAGE CONTENT WRAPPER -->      
		<div id="StatusGeral"></div>        
<!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>  
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->        
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>  
        <script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>  
                <script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/DataTables-br.js"></script>  
        
        <!-- END THIS PAGE PLUGINS-->        

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>
        <!-- END TEMPLATE -->