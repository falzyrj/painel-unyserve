<?php
include("conexao.php");
include("conexao2.php");
include('funcoes.php');
include_once("functions.php");
@$iduser = @$_SESSION['id'];
if(ProtegePag() == true){
global $banco;
?>
                <ul class="breadcrumb">
                    <li class="active"></span>&#160;Olá&#160;<strong><?php echo $_SESSION['nome']?></strong>&#160;Bem-vindo(a) Ao Painel de Controle</li>
                </ul>
          <div class="page-title">                    
          </div>
                
                <?php
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
				?>
                <div class="col-md-12">
                        <?php
						$UserOnline = $_SESSION['login'];
                        $SQLUrlT = "SELECT status, tempo, cemail, email FROM urlteste WHERE CadUser = :CadUser";
						$SQLUrlT = $banco->prepare($SQLUrlT);
						$SQLUrlT->bindParam(':CadUser', $UserOnline, PDO::PARAM_STR);
						$SQLUrlT->execute();
						$TotalUrlT = count($SQLUrlT->fetchAll());

                                             /* script compra de crédito*/
                                             /* COLOCAR O TIPO DE ID DO CRIADOR */

                                             if($_SESSION['id_cad'] == 1){
                                             echo "
                                             <div class=\"panel panel-default\">
                                                 <div class=\"panel-heading\">
                                                     <h3 class=\"panel-title\">Compra de crédito</h3>
                                                 </div>
                                                 <div class=\"panel-body\">                                
                                                     <form action=\"reservar-credito.php\" method=\"post\">
                                                         <input type=\"hidden\" name=\"iduser\" value=\"".$iduser."\"/>
                                                         <div class=\"col-md-2 col-sm-12\">
                                                         <label>Quantidade:</label>
                                                         <select type=\"number\" class=\"form-control\" name=\"quantidade\" required>
                                                             <option value=\"10\">10</option>
                                                             <option value=\"15\">15</option>
                                                             <option value=\"20\">20</option>
                                                             <option value=\"30\">30</option>
                                                             <option value=\"40\">40</option>
                                                         </select>
                                                         </div>
                 
                                                         <div class=\"col-md-4 col-sm-12\">
                                                         <label>Nome:</label>
                                                         <input type=\"text\" class=\"form-control\" name=\"nome\" placeholder=\"Nome e sobrenome\" required/>
                                                         </div>
                 
                                                         <div class=\"col-md-4 col-sm-12\">
                                                         <label>CPF:</label>
                                                         <input type=\"text\" class=\"form-control\" name=\"cpf\" placeholder=\"Apenas números\" required/>
                                                         </div>
                 
                                                         <div><br />
                                                         <button type=\"submit\" class=\"btn btn-primary\" pull-right\">Comprar</button>
                                                         </div>                                    
                                                     </form>                                                                
                                                 </div>      
                                                 <div class=\"panel-footer\">
                                                 <h3>Table de compra de créditos</h3>
                                                 <div class=\"table-responsive\">



                                                 <table class=\"table\">
                                                 <thead>
                                                   <tr>
                                                   <th>ID</th>
                                                   <th>NOME</th>
                                                   <th>QTD</th>
                                                   <th>Valor</th>
                                                   <th>Cota/Atualiza</th>
                                                   <th>Venc/Atualiza</th>
                                                   <th>Situação</th>
                                                   <th>Ação</th>
                                                   </tr>
                                                 </thead>
                                                 <tbody>
   
                                                 ";                        
                                                 $query = mysqli_query($conn,"SELECT * FROM compra_creditos WHERE iduser='$iduser' ORDER BY id DESC LIMIT 1") or die (mysqli_error($conn));   
                                                 if(mysqli_num_rows($query) >= 1){
                                                 while($r = mysqli_fetch_array($query)){
                                                     echo'
                                                     <tr>
                                                         <td>'.$r['id'].'</td>
                                                         <td>'.$r['nome'].'</td>
                                                         <td>'.$r['quantidadecomprada'].'</td>
                                                         <td>'.Real($r['valor']).'</td>
                                                         <td>'.$r['quantidadeatualiza'].'</td>
                                                         <th>'.$r['dataatualiza'].'</th>
                                                         <td>';
                                                            if($r['link'] == ''){ echo 'deu erro';}else{ echo $r['situacao']; }
                                                         echo'</td>
                                                         <td>';
                                                         if($r['situacao'] == 'PENDENTE' AND $r['link'] != ''){echo'
                                                             <a href="'.$r['link'].'" class="btn btn-primary" target=\"_blank\"><i class="fa fa-dollar"></i> Pagar</a>
                                                             <a href="reservar-credito-excluir.php?id='.$r['id'].'" class="btn btn-danger"><i class="fa fa-trash"></i> Excluir</a>';
                                                         }elseif($r['situacao'] == 'RECEBIDO'){ echo '
                                                                RECEBIDO
                                                            ';
                                                         
                                                        }else{
                                                            echo'<a href="reservar-credito-excluir.php?id='.$r['id'].'" class="btn btn-danger"><i class="fa fa-trash"></i> Excluir</a>';
                                                         }
                                                         
                                                         
                                                         echo'
                                                             
                                                         </td>
                                                     </tr>';
                                                     }
                                                 }else{ echo'<tr><td colspan="7">sem registro</td></tr>'; }  
                                                 echo"
                                                 </tbody>
                                               </table>
                                                   
                                                 </div>                
                                             </div>";}
                            
                         ?>
                            
                        </div>
                            
                
                <?php
				}
				
				$userCota = $_SESSION['id'];
				$VerificarLimiteTeste = VerificarLimiteTeste($userCota);
				$VerificarLimiteTeste = $VerificarLimiteTeste == 0 ? "Ilimitado" : $VerificarLimiteTeste;
				$VerificarCotaTeste = VerificarCotaTeste($userCota);
				
				$CotaTesteDisponivel = Intval($VerificarLimiteTeste) - Intval($VerificarCotaTeste);
				
				if($VerificarLimiteTeste == 0){
						$LimiteTesteCota = "Ilimitado";	
				}
				elseif($CotaTesteDisponivel > 0){
						$LimiteTesteCota = $CotaTesteDisponivel;	
				}
				else{
						$LimiteTesteCota = "Esgotado";
				}
				
				
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
				?>
                <?php
				}
				
				
				if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
					//Servidor
					$SQLArq = "SELECT * FROM arquivo";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->execute();
				}
				else{
					//Servidor
					$operadora = $_SESSION['operadora'];
					$OpTodos = "Todos";
					$SQLArq = "SELECT * FROM arquivo WHERE operadora = :operadora OR operadora = :OpTodos";
					$SQLArq = $banco->prepare($SQLArq);
					$SQLArq->bindParam(':operadora', $operadora, PDO::PARAM_STR);
					$SQLArq->bindParam(':OpTodos', $OpTodos, PDO::PARAM_STR);
					$SQLArq->execute();
				}
				
				while($LnArq = $SQLArq->fetch()){
					
				$apn = empty($LnArq['apn']) ? "" : "<p><b><font color=\"#FF0000\">APN:</font></b> ".$LnArq['apn']."</p>";
				
					$SQLImagem = "SELECT imagem FROM imagem_perfil WHERE id = :id";
					$SQLImagem = $banco->prepare($SQLImagem);
					$SQLImagem->bindParam(':id', $LnArq['imagem'], PDO::PARAM_STR);
					$SQLImagem->execute();
					$LnImagem = $SQLImagem->fetch();
					$img = "<img src=\"img/perfil/".$LnImagem['imagem']."\" height=\"83\" width=\"254\" title=\"".$LnArq['nome']."\">";
					
					$UrlArq = empty($LnArq['file']) ? $LnArq['url'] : UrlAtual()."download/".$LnArq['file'];
					
				echo "<div class=\"col-md-4\">

                            <!-- NEWS WIDGET -->
                            <div class=\"panel panel-".$LnArq['tipo']."\">
                                <div class=\"panel-heading\">
                                    <h3 class=\"panel-title\">".$LnArq['nome']."</h3>         
                                </div>
                                <div class=\"panel-body scroll\" style=\"height: 230px;\">  
                                        
                                    <center>".$img."</center>
                                    <br /><br />
									<h6>".$LnArq['titulo']."</h6>
                                    <p>".$LnArq['descricao']."</p>
									".$apn."
                                                                                           
                              </div>
                                
                                <div class=\"panel-footer\"> 
                                  <a target=\"_blank\" href=\"".$UrlArq."\" class=\"btn btn-".$LnArq['tipo']." btn-block\">".$LnArq['botao']."</a>
                                </div>
                                
                            </div>
                            <!-- END NEWS WIDGET -->

                        </div> ";
					
				}
				
				
				
				
				
				?>
               
		<div id="StatusGeral"></div>        
<!-- START SCRIPTS -->
        <!-- START PLUGINS -->
        <script type="text/javascript" src="js/plugins/jquery/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins/jquery/jquery-ui.min.js"></script>
        <script type="text/javascript" src="js/plugins/bootstrap/bootstrap.min.js"></script>  
        <!-- END PLUGINS -->

        <!-- START THIS PAGE PLUGINS-->        
        <script type='text/javascript' src='js/plugins/icheck/icheck.min.js'></script>
        <script type="text/javascript" src="js/plugins/mcustomscrollbar/jquery.mCustomScrollbar.min.js"></script>  
        <script type='text/javascript' src='js/plugins/maskedinput/jquery.maskedinput.min.js'></script>  
                <script type="text/javascript" src="js/plugins/datatables/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/DataTables-br.js"></script>  
        
        <!-- END THIS PAGE PLUGINS-->        

        <!-- START TEMPLATE -->
        <script type="text/javascript" src="js/plugins.js"></script>        
        <script type="text/javascript" src="js/actions.js"></script>
        <!-- END TEMPLATE -->
        
        <?php
		if( ($_SESSION['acesso'] == 1) || ($_SESSION['acesso'] == 2)){
		?>
        <script type='text/javascript'>
		function ConfigTeste(){
			
			panel_refresh($(".page-container"));
			
			$.post('ScriptModalTesteConfig.php', function(resposta) {
				
				setTimeout(panel_refresh($(".page-container")),500);
				
				$("#StatusGeral").html('');
				$("#StatusGeral").html(resposta);
			});	
		}
		</script>
        <?php
		}
		?>
       
    <!-- END SCRIPTS -->    
<?php
}else{
	echo Redirecionar('login.php');
}	
?>

<script>
$('#formAddLog').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-fundo.php',
      data:formData,
      success:function(data){
        $('#retorno').show().fadeOut(2500).html(data);
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddLogo').submit(function(){
    var formData = new FormData(this);
    $.ajax({
      type:'post',
      url:'insert-logo.php',
      data:formData,
      success:function(data){
        $('#retornoLogo').show().fadeOut(2500).html(data);
        history.go();
      },
       cache: false,
          contentType: false,
          processData: false,
    });
    return false;
  });

  $('#formAddNome').submit(function(){
    $.ajax({
      type:'post',
      url:'insert-nome.php',
      data:$('#formAddNome').serialize(),
      success:function(data){
        $('#retornoNome').show().html(data);
        history.go();
      },      
    });
    return false;
  });
</script>